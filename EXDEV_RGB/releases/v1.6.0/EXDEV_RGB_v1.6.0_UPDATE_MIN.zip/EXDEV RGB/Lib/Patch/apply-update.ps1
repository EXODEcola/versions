param([Parameter(Mandatory=$true)][string]$PackageRoot)
$ErrorActionPreference='Stop'; $TargetVersion='1.6.0'; Add-Type -AssemblyName System.Windows.Forms
function Fail([string]$m){try{[Windows.Forms.MessageBox]::Show($m,'EXDEV RGB - Mise à jour','OK','Error')|Out-Null}catch{};exit 1}
function RV($p,$n){try{return [string](Get-ItemProperty -LiteralPath $p -Name $n -ErrorAction Stop).$n}catch{return ''}}
function FindRoot{
 $c=New-Object 'System.Collections.Generic.List[string]'
 foreach($p in @('HKLM:\Software\EXDEV\EXDEV RGB','HKCU:\Software\EXDEV\EXDEV RGB')){$v=RV $p 'InstallLocation';if($v){$c.Add($v)}}
 foreach($p in @('Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB','Registry::HKEY_LOCAL_MACHINE\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB','Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB')){$v=RV $p 'InstallLocation';if($v){$c.Add($v)}}
 foreach($b in @([Environment]::GetFolderPath('ProgramFiles'),[Environment]::GetFolderPath('ProgramFilesX86'))){if($b){$c.Add((Join-Path $b 'EXDEV RGB'))}}
 foreach($x in $c){if($x -and (Test-Path (Join-Path $x 'EXDEV RGB.exe')) -and (Test-Path (Join-Path $x 'Lib\Source'))){return $x}};return $null
}
function Verify($p){$m=Get-Content (Join-Path $p 'payload-manifest.json') -Raw -Encoding UTF8|ConvertFrom-Json;foreach($q in $m.files.PSObject.Properties){$r=[string]$q.Name;if($r.Contains('..') -or [IO.Path]::IsPathRooted($r)){throw 'Chemin interdit'};$f=Join-Path $p ($r-replace '/','\');if(!(Test-Path $f)){throw "Fichier absent: $r"};if((Get-FileHash $f -Algorithm SHA256).Hash -ne ([string]$q.Value).ToUpper()){throw "Integrite invalide: $r"}}}
try{
 $P=Join-Path $PackageRoot 'Lib\Patch';Verify $P;$R=FindRoot;if(!$R){throw 'Installation EXDEV RGB introuvable.'};$S=Join-Path $R 'Lib\Source';$Q=Join-Path $P 'Payload\Source'
 Get-Process -Name 'EXDEV RGB' -ErrorAction SilentlyContinue|Stop-Process -Force -ErrorAction SilentlyContinue;Start-Sleep -Milliseconds 600
 $rb=Join-Path $R 'Lib\Rollback\1.6.0';New-Item -ItemType Directory -Force $rb|Out-Null;if(Test-Path (Join-Path $R 'EXDEV RGB.exe')){Copy-Item (Join-Path $R 'EXDEV RGB.exe') (Join-Path $rb 'EXDEV RGB.previous.exe') -Force}
 Get-ChildItem $Q -Recurse -File|ForEach-Object{$rel=$_.FullName.Substring($Q.Length).TrimStart('\');$dst=Join-Path $S $rel;New-Item -ItemType Directory -Force (Split-Path $dst -Parent)|Out-Null;Copy-Item $_.FullName $dst -Force}
 $prep=Join-Path $R 'Lib\Installer\prepare-runtime.ps1';if(!(Test-Path $prep)){throw 'prepare-runtime.ps1 introuvable.'};$ld=Join-Path $R 'Lib\Logs';New-Item -ItemType Directory -Force $ld|Out-Null;& powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $prep -RootDir $R -SourceDir $S -LogFile (Join-Path $ld 'update-1.6.0.log');if($LASTEXITCODE -ne 0){throw "Compilation echouee: $LASTEXITCODE"}
 $b=Join-Path $S 'dist\EXDEV RGB.exe';if(!(Test-Path $b)){throw 'Executable compile introuvable.'};$rt=Join-Path $R 'Lib\AppRuntime';New-Item -ItemType Directory -Force $rt|Out-Null;Copy-Item $b (Join-Path $rt 'EXDEV RGB.exe') -Force;Copy-Item $b (Join-Path $R 'EXDEV RGB.exe') -Force
 foreach($f in @((Join-Path $rt 'version.txt'),(Join-Path $R 'Lib\installed-version.txt'),(Join-Path $R 'Lib\version.txt'))){[IO.File]::WriteAllText($f,$TargetVersion+"`r`n",[Text.UTF8Encoding]::new($false))}
 foreach($p in @('HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB','HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB')){try{if(Test-Path $p){Set-ItemProperty $p DisplayVersion $TargetVersion -Force}}catch{}};Start-Process (Join-Path $R 'EXDEV RGB.exe') -WorkingDirectory $R;exit 0
}catch{Fail("La mise a jour EXDEV RGB 1.6.0 a echoue.`r`n`r`n"+$_.Exception.Message)}
