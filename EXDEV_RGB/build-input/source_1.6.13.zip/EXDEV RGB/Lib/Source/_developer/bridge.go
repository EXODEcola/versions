//go:build windows

package main

import (
	"crypto/subtle"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"
)

type Resp map[string]interface{}

func emit(v Resp) {
	b, _ := json.Marshal(v)
	fmt.Println(string(b))
}

var (
	hidDLL             = syscall.NewLazyDLL("hid.dll")
	setupDLL           = syscall.NewLazyDLL("setupapi.dll")
	kernelDLL          = syscall.NewLazyDLL("kernel32.dll")
	procHidGuid        = hidDLL.NewProc("HidD_GetHidGuid")
	procHidAttr        = hidDLL.NewProc("HidD_GetAttributes")
	procHidPreparsed   = hidDLL.NewProc("HidD_GetPreparsedData")
	procHidFreePrep    = hidDLL.NewProc("HidD_FreePreparsedData")
	procHidCaps        = hidDLL.NewProc("HidP_GetCaps")
	procSetFeat        = hidDLL.NewProc("HidD_SetFeature")
	procGetFeat        = hidDLL.NewProc("HidD_GetFeature")
	procGetClass       = setupDLL.NewProc("SetupDiGetClassDevsW")
	procEnumIf         = setupDLL.NewProc("SetupDiEnumDeviceInterfaces")
	procGetDetail      = setupDLL.NewProc("SetupDiGetDeviceInterfaceDetailW")
	procDestroy        = setupDLL.NewProc("SetupDiDestroyDeviceInfoList")
	procCreateFile     = kernelDLL.NewProc("CreateFileW")
	procClose          = kernelDLL.NewProc("CloseHandle")
	procDevIo          = kernelDLL.NewProc("DeviceIoControl")
	procCreateMutex    = kernelDLL.NewProc("CreateMutexW")
	procWait           = kernelDLL.NewProc("WaitForSingleObject")
	procReleaseMutex   = kernelDLL.NewProc("ReleaseMutex")
	procGetProcessHeap = kernelDLL.NewProc("GetProcessHeap")
	procHeapAlloc      = kernelDLL.NewProc("HeapAlloc")
)

type GUID struct {
	Data1 uint32
	Data2 uint16
	Data3 uint16
	Data4 [8]byte
}
type SPDeviceInterfaceData struct {
	CbSize             uint32
	InterfaceClassGuid GUID
	Flags              uint32
	Reserved           uintptr
}
type HIDDAttributes struct {
	Size          uint32
	VendorID      uint16
	ProductID     uint16
	VersionNumber uint16
}
type HIDPCaps struct {
	Usage                     uint16
	UsagePage                 uint16
	InputReportByteLength     uint16
	OutputReportByteLength    uint16
	FeatureReportByteLength   uint16
	Reserved                  [17]uint16
	NumberLinkCollectionNodes uint16
	NumberInputButtonCaps     uint16
	NumberInputValueCaps      uint16
	NumberInputDataIndices    uint16
	NumberOutputButtonCaps    uint16
	NumberOutputValueCaps     uint16
	NumberOutputDataIndices   uint16
	NumberFeatureButtonCaps   uint16
	NumberFeatureValueCaps    uint16
	NumberFeatureDataIndices  uint16
}

// AMD ADL structures used only for the allowlisted AORUS RX 9070 XT RGB controller.
// No clock, voltage, temperature, fan or PWM API is loaded anywhere in EXDEV.
type ADLAdapterInfo struct {
	Size           int32
	AdapterIndex   int32
	UDID           [256]byte
	BusNumber      int32
	DeviceNumber   int32
	FunctionNumber int32
	VendorID       int32
	AdapterName    [256]byte
	DisplayName    [256]byte
	Present        int32
	Exist          int32
	DriverPath     [256]byte
	DriverPathExt  [256]byte
	PNPString      [256]byte
	OSDisplayIndex int32
}

// AdapterInfoX2 extends AdapterInfo with the two capability fields.
// EXDEV prefers AMD's X4 enumeration on recent Radeon drivers.
type ADLAdapterInfoX2 struct {
	ADLAdapterInfo
	InfoMask  int32
	InfoValue int32
}

type ADLI2C struct {
	Size     int32
	Line     int32
	Address  int32
	Offset   int32
	Action   int32
	Speed    int32
	DataSize int32
	Data     uintptr
}

const (
	digcfPresent         = 0x00000002
	digcfDeviceInterface = 0x00000010
	genericRead          = 0x80000000
	genericWrite         = 0x40000000
	fileShareRead        = 0x00000001
	fileShareWrite       = 0x00000002
	fileShareDelete      = 0x00000004
	openExisting         = 3
	fileAttributeNormal  = 0x00000080
	invalidHandleValue   = ^uintptr(0)
	waitObject0          = 0x00000000
	waitAbandoned        = 0x00000080
	waitTimeout          = 0x00000102

	pawnIODeviceType = uint32(41394)
	pawnLoadFunction = uint32(0x821)
	pawnExecFunction = uint32(0x841)

	smbusRead      = uint64(1)
	smbusWrite     = uint64(0)
	smbusByteData  = uint64(2)
	smbusWordData  = uint64(3)
	smbusBlockData = uint64(5)

	corsairVID            = uint16(0x1B1C)
	regResetBuffer        = byte(0x0B)
	regSetBinaryData      = byte(0x20)
	regEffectSelect       = byte(0x26)
	regBinaryStart        = byte(0x21)
	regStatus             = byte(0x30)
	regEffectReady        = byte(0x41)
	regColorBlock1        = byte(0x31)
	regColorBlock2        = byte(0x32)
	regGetBinaryData      = byte(0x40)
	regChecksum           = byte(0x42)
	regSignatureA         = byte(0x43)
	regSignatureB         = byte(0x44)
	regGetDeviceInfo      = byte(0x61)
	regWriteConfiguration = byte(0x82)
	corsairEffectConfigID = byte(0x01)
)

var corsairVengeanceDDR5PIDs = map[uint16]bool{
	0x0700: true, 0x0701: true, 0x0900: true, 0x0901: true, 0x0910: true, 0x0911: true,
}

func parseArgs(args []string) map[string]string {
	out := map[string]string{}
	for i := 0; i < len(args); i++ {
		if !strings.HasPrefix(args[i], "--") {
			continue
		}
		key := strings.TrimPrefix(args[i], "--")
		if i+1 < len(args) && !strings.HasPrefix(args[i+1], "--") {
			out[key] = args[i+1]
			i++
		} else {
			out[key] = "true"
		}
	}
	return out
}

// -----------------------------------------------------------------------------
// Gigabyte RGB Fusion 2 / ITE HID - board ARGB only.
// No PCI display adapter, GPU I2C, PWM, NZXT, fan or pump path exists here.
// -----------------------------------------------------------------------------
func utf16PathFromDetail(buf []byte) string {
	if len(buf) <= 4 {
		return ""
	}
	p := unsafe.Pointer(&buf[4])
	n := (len(buf) - 4) / 2
	return syscall.UTF16ToString(unsafe.Slice((*uint16)(p), n))
}

func hidUsageMatches(h syscall.Handle) bool {
	var prep uintptr
	r, _, _ := procHidPreparsed.Call(uintptr(h), uintptr(unsafe.Pointer(&prep)))
	if r == 0 || prep == 0 {
		return false
	}
	defer procHidFreePrep.Call(prep)
	var caps HIDPCaps
	status, _, _ := procHidCaps.Call(prep, uintptr(unsafe.Pointer(&caps)))
	// HIDP_STATUS_SUCCESS is non-negative (0x00110000).
	if int32(status) < 0 {
		return false
	}
	return caps.UsagePage == 0xFF89 && caps.Usage == 0x00CC && caps.FeatureReportByteLength >= 64
}

func findGigabyteController() (syscall.Handle, uint16, string, error) {
	var hidGuid GUID
	procHidGuid.Call(uintptr(unsafe.Pointer(&hidGuid)))
	hdev, _, err := procGetClass.Call(uintptr(unsafe.Pointer(&hidGuid)), 0, 0, uintptr(digcfPresent|digcfDeviceInterface))
	if hdev == invalidHandleValue || hdev == 0 {
		return 0, 0, "", fmt.Errorf("SetupDiGetClassDevsW: %v", err)
	}
	defer procDestroy.Call(hdev)
	allowed := map[uint16]bool{0x5702: true, 0x8297: true, 0x5711: true, 0x8950: true}
	for i := uint32(0); ; i++ {
		data := SPDeviceInterfaceData{CbSize: uint32(unsafe.Sizeof(SPDeviceInterfaceData{}))}
		r, _, enumErr := procEnumIf.Call(hdev, 0, uintptr(unsafe.Pointer(&hidGuid)), uintptr(i), uintptr(unsafe.Pointer(&data)))
		if r == 0 {
			if errno, ok := enumErr.(syscall.Errno); ok && errno == 259 {
				break
			}
			break
		}
		var required uint32
		procGetDetail.Call(hdev, uintptr(unsafe.Pointer(&data)), 0, 0, uintptr(unsafe.Pointer(&required)), 0)
		if required < 8 {
			continue
		}
		detail := make([]byte, required)
		*(*uint32)(unsafe.Pointer(&detail[0])) = 8
		r, _, _ = procGetDetail.Call(hdev, uintptr(unsafe.Pointer(&data)), uintptr(unsafe.Pointer(&detail[0])), uintptr(required), uintptr(unsafe.Pointer(&required)), 0)
		if r == 0 {
			continue
		}
		path := utf16PathFromDetail(detail)
		if path == "" {
			continue
		}
		p16, _ := syscall.UTF16PtrFromString(path)
		h, _, _ := procCreateFile.Call(uintptr(unsafe.Pointer(p16)), uintptr(genericRead|genericWrite), uintptr(fileShareRead|fileShareWrite), 0, uintptr(openExisting), uintptr(fileAttributeNormal), 0)
		if h == invalidHandleValue || h == 0 {
			continue
		}
		handle := syscall.Handle(h)
		attr := HIDDAttributes{Size: uint32(unsafe.Sizeof(HIDDAttributes{}))}
		ok, _, _ := procHidAttr.Call(uintptr(handle), uintptr(unsafe.Pointer(&attr)))
		if ok != 0 && attr.VendorID == 0x048D && allowed[attr.ProductID] && hidUsageMatches(handle) {
			return handle, attr.ProductID, path, nil
		}
		procClose.Call(uintptr(handle))
	}
	return 0, 0, "", errors.New("contrôleur GIGABYTE RGB Fusion 2 / ITE introuvable")
}

func setFeature(h syscall.Handle, buf []byte) error {
	if len(buf) != 64 {
		return errors.New("paquet HID invalide")
	}
	r, _, e := procSetFeat.Call(uintptr(h), uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
	if r == 0 {
		return fmt.Errorf("HidD_SetFeature a échoué: %v", e)
	}
	return nil
}

func parseHexColor(s string) (byte, byte, byte, error) {
	s = strings.TrimPrefix(strings.TrimSpace(s), "#")
	if len(s) != 6 {
		return 0, 0, 0, errors.New("couleur HEX invalide")
	}
	n, err := strconv.ParseUint(s, 16, 32)
	if err != nil {
		return 0, 0, 0, errors.New("couleur HEX invalide")
	}
	return byte(n >> 16), byte(n >> 8), byte(n), nil
}

func scaleRGB(r, g, b byte, brightness string) (byte, byte, byte) {
	n, _ := strconv.Atoi(brightness)
	if n <= 0 {
		n = 100
	}
	if n > 100 {
		n = 100
	}
	return byte(int(r) * n / 100), byte(int(g) * n / 100), byte(int(b) * n / 100)
}

func boardAllowed(board string) bool {
	b := strings.ToUpper(strings.Join(strings.Fields(board), " "))
	if !strings.Contains(b, "B650") {
		return false
	}
	return strings.Contains(b, "EAGLE") || strings.Contains(b, "GAMING X")
}

func zoneInfo(zone string) (effectIndex byte, argbHeader byte, countIndex int, normalized string, err error) {
	z := strings.ToUpper(strings.ReplaceAll(strings.TrimSpace(zone), " ", ""))
	switch z {
	case "D_LED1", "ARGB_V2_1", "ARGB_V2_3", "ARGB_V2_1/ARGB_V2_3":
		return 5, 0x58, 0, z, nil
	case "D_LED2", "ARGB_V2_2":
		return 6, 0x59, 1, z, nil
	default:
		return 0, 0, 0, "", fmt.Errorf("zone ARGB refusée par FAN LOCK: %s", zone)
	}
}

func getFeature(h syscall.Handle, buf []byte) error {
	if len(buf) != 64 {
		return errors.New("paquet HID invalide")
	}
	r, _, e := procGetFeat.Call(uintptr(h), uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
	if r == 0 {
		return fmt.Errorf("HidD_GetFeature a échoué: %v", e)
	}
	return nil
}

func sendCC(h syscall.Handle, a, b, c byte) error {
	buf := make([]byte, 64)
	buf[0], buf[1], buf[2], buf[3] = 0xCC, a, b, c
	return setFeature(h, buf)
}

type gigabyteReport struct {
	cal     [2]uint32
	counts  [2]int
	support byte
}

func ledCountFromEnum(v byte, pid uint16) int {
	switch v & 0x0F {
	case 0:
		return 32
	case 1:
		return 64
	case 2:
		return 256
	case 3:
		if pid == 0x5702 || pid == 0x5711 {
			return 256
		}
		return 512
	default:
		if pid == 0x5702 || pid == 0x5711 {
			return 256
		}
		return 1024
	}
}

func readGigabyteReport(h syscall.Handle, pid uint16) (gigabyteReport, error) {
	var out gigabyteReport
	if err := sendCC(h, 0x60, 0x00, 0x00); err != nil {
		return out, err
	}
	time.Sleep(12 * time.Millisecond)
	buf := make([]byte, 64)
	buf[0] = 0xCC
	if err := getFeature(h, buf); err != nil {
		return out, err
	}
	if len(buf) < 64 {
		return out, errors.New("rapport RGB Fusion 2 incomplet")
	}
	counts := buf[8]
	out.counts[0] = ledCountFromEnum(counts&0x0F, pid)
	out.counts[1] = ledCountFromEnum((counts>>4)&0x0F, pid)
	out.cal[0] = binary.LittleEndian.Uint32(buf[44:48])
	out.cal[1] = binary.LittleEndian.Uint32(buf[48:52])
	out.support = buf[11]
	return out, nil
}

func rgbOffsets(cal uint32) (int, int, int) {
	r := int((cal >> 16) & 0xFF)
	g := int((cal >> 8) & 0xFF)
	b := int(cal & 0xFF)
	if r >= 0 && r < 3 && g >= 0 && g < 3 && b >= 0 && b < 3 && r != g && r != b && g != b {
		return r, g, b
	}
	// Most ARGB strips use GRB when no usable calibration is exposed.
	return 1, 0, 2
}

func sendDirectArgb(h syscall.Handle, header byte, cal uint32, count int, r, g, b byte) error {
	if count < 1 {
		count = 32
	}
	if count > 256 {
		count = 256
	}
	ro, goff, bo := rgbOffsets(cal)
	offset := 0
	for offset < count {
		n := count - offset
		if n > 19 {
			n = 19
		}
		pkt := make([]byte, 64)
		pkt[0] = 0xCC
		pkt[1] = header
		binary.LittleEndian.PutUint16(pkt[2:4], uint16(offset*3))
		pkt[4] = byte(n * 3)
		for i := 0; i < n; i++ {
			base := 5 + i*3
			pkt[base+ro] = r
			pkt[base+goff] = g
			pkt[base+bo] = b
		}
		if err := setFeature(h, pkt); err != nil {
			return err
		}
		offset += n
	}
	return nil
}

type rgbPixel struct{ R, G, B byte }

func sendDirectArgbPixels(h syscall.Handle, header byte, cal uint32, pixels []rgbPixel) error {
	count := len(pixels)
	if count < 1 {
		return nil
	}
	if count > 256 {
		pixels = pixels[:256]
		count = 256
	}
	ro, goff, bo := rgbOffsets(cal)
	for offset := 0; offset < count; {
		n := count - offset
		if n > 19 {
			n = 19
		}
		pkt := make([]byte, 64)
		pkt[0] = 0xCC
		pkt[1] = header
		binary.LittleEndian.PutUint16(pkt[2:4], uint16(offset*3))
		pkt[4] = byte(n * 3)
		for i := 0; i < n; i++ {
			c := pixels[offset+i]
			base := 5 + i*3
			pkt[base+ro], pkt[base+goff], pkt[base+bo] = c.R, c.G, c.B
		}
		if err := setFeature(h, pkt); err != nil {
			return err
		}
		offset += n
	}
	return nil
}

func hsvToRGBBytes(h, s, v float64) (byte, byte, byte) {
	h = math.Mod(h, 360)
	if h < 0 {
		h += 360
	}
	if s < 0 {
		s = 0
	}
	if s > 1 {
		s = 1
	}
	if v < 0 {
		v = 0
	}
	if v > 1 {
		v = 1
	}
	c := v * s
	x := c * (1 - math.Abs(math.Mod(h/60, 2)-1))
	m := v - c
	var r, g, b float64
	switch {
	case h < 60:
		r, g, b = c, x, 0
	case h < 120:
		r, g, b = x, c, 0
	case h < 180:
		r, g, b = 0, c, x
	case h < 240:
		r, g, b = 0, x, c
	case h < 300:
		r, g, b = x, 0, c
	default:
		r, g, b = c, 0, x
	}
	return byte(math.Round((r + m) * 255)), byte(math.Round((g + m) * 255)), byte(math.Round((b + m) * 255))
}

func rgbBytesToHSV(r, g, b byte) (float64, float64, float64) {
	rf, gf, bf := float64(r)/255, float64(g)/255, float64(b)/255
	mx := math.Max(rf, math.Max(gf, bf))
	mn := math.Min(rf, math.Min(gf, bf))
	d := mx - mn
	h := 0.0
	if d != 0 {
		if mx == rf {
			h = 60 * math.Mod((gf-bf)/d, 6)
		} else if mx == gf {
			h = 60 * ((bf-rf)/d + 2)
		} else {
			h = 60 * ((rf-gf)/d + 4)
		}
	}
	if h < 0 {
		h += 360
	}
	sat := 0.0
	if mx != 0 {
		sat = d / mx
	}
	return h, sat, mx
}

func makeArgbEffectFrame(effect, color, brightness string, count int, elapsed float64) ([]rgbPixel, error) {
	r, g, b, err := parseHexColor(color)
	if err != nil {
		return nil, err
	}
	pct, _ := strconv.Atoi(brightness)
	if pct < 0 {
		pct = 0
	}
	if pct > 100 {
		pct = 100
	}
	if pct == 0 {
		pct = 100
	}
	baseH, baseS, baseV := rgbBytesToHSV(r, g, b)
	bright := float64(pct) / 100
	out := make([]rgbPixel, count)
	effect = strings.ToLower(strings.TrimSpace(effect))
	if effect == "" {
		effect = "static"
	}
	for i := 0; i < count; i++ {
		pos := 0.0
		if count > 1 {
			pos = float64(i) / float64(count-1)
		}
		h, sat, val := baseH, math.Max(.28, baseS), baseV*bright
		switch effect {
		case "wave":
			crest := (math.Sin(pos*math.Pi*4-elapsed*3.8) + 1) / 2
			h = baseH + 18*math.Sin(pos*math.Pi*2-elapsed*1.9)
			val = baseV * bright * (.18 + .82*crest)
		case "spectrum":
			h = elapsed*72 + pos*360
			sat = 1
			val = bright
		case "cycle":
			h = baseH + elapsed*55 + pos*52
			sat = math.Max(.68, baseS)
			val = math.Max(.55, baseV) * bright
		case "breath":
			pulse := .14 + .86*((math.Sin(elapsed*2.35-math.Pi/2)+1)/2)
			val = baseV * bright * pulse
		case "flash":
			if math.Mod(elapsed, 0.56) > .22 {
				val = .03
			} else {
				val = baseV * bright
			}
		}
		rr, gg, bb := hsvToRGBBytes(h, sat, val)
		out[i] = rgbPixel{rr, gg, bb}
	}
	return out, nil
}

func sendGigabyteStaticEffect(h syscall.Handle, effectIndex byte, r, g, b byte, brightness string) error {
	// Hardware static mode is used for a fixed color instead of a transient direct frame.
	// This is the same RGB Fusion 2 lighting controller path and never touches PWM/fans.
	n, _ := strconv.Atoi(brightness)
	if n < 0 {
		n = 0
	}
	if n > 100 {
		n = 100
	}
	hwBright := byte((n*255 + 50) / 100)
	mask := uint32(1) << effectIndex
	pkt := make([]byte, 64)
	pkt[0] = 0xCC
	pkt[1] = 0x20 + effectIndex
	binary.LittleEndian.PutUint32(pkt[2:6], mask)
	pkt[11] = 0x01 // EFFECT_STATIC
	pkt[12] = hwBright
	pkt[13] = 0
	// RGB Fusion 2 stores static effect colors as B,G,R in the packed payload.
	pkt[14], pkt[15], pkt[16], pkt[17] = b, g, r, 0
	if err := setFeature(h, pkt); err != nil {
		return err
	}
	apply := make([]byte, 64)
	apply[0], apply[1] = 0xCC, 0x28
	binary.LittleEndian.PutUint32(apply[2:6], mask)
	return setFeature(h, apply)
}

type argbHoldState struct {
  Pixels []string `json:"pixels,omitempty"`
	Board      string `json:"board"`
	Zone       string `json:"zone"`
	Color      string `json:"color"`
	Brightness string `json:"brightness"`
	Effect     string `json:"effect,omitempty"`
	StartedMs  int64  `json:"startedMs,omitempty"`
}

var argbHoldMu sync.RWMutex
var argbHolds = map[string]argbHoldState{}

func argbHoldFile() string {
	exe, err := os.Executable()
	if err != nil || exe == "" {
		return ""
	}
	return filepath.Join(filepath.Dir(exe), "argb-hold.json")
}

func persistArgbHoldsLocked() {
	path := argbHoldFile()
	if path == "" {
		return
	}
	items := make([]argbHoldState, 0, len(argbHolds))
	for _, h := range argbHolds {
		items = append(items, h)
	}
	b, err := json.Marshal(items)
	if err != nil {
		return
	}
	tmp := path + ".tmp"
	if os.WriteFile(tmp, b, 0600) == nil {
		_ = os.Rename(tmp, path)
	}
}

func rememberArgbHold(board, zone, color, brightness, effect string, startedMs int64) {
	if strings.TrimSpace(effect) == "" {
		effect = "static"
	}
	if startedMs <= 0 {
		startedMs = time.Now().UnixMilli()
	}
	argbHoldMu.Lock()
	argbHolds[strings.ToUpper(zone)] = argbHoldState{Board: board, Zone: zone, Color: color, Brightness: brightness, Effect: strings.ToLower(effect), StartedMs: startedMs}
	persistArgbHoldsLocked()
	argbHoldMu.Unlock()
}

func rememberArgbPixels(board, zone, brightness string, pixels []string) {
  argbHoldMu.Lock()
  argbHolds[strings.ToUpper(zone)] = argbHoldState{Board:board,Zone:zone,Brightness:brightness,Effect:"custom",Pixels:append([]string(nil),pixels...),StartedMs:time.Now().UnixMilli()}
  persistArgbHoldsLocked()
  argbHoldMu.Unlock()
}

// Strictly validate all colors before writing any HID frames.
func pixelFrameFromStrings(colors []string, brightness string) ([]rgbPixel,error) {
 if len(colors)<6 || len(colors)>120 { return nil,fmt.Errorf("Nombre de LED ARGB invalide (6..120)") }
 out:=make([]rgbPixel,len(colors))
 for i,c:=range colors {
   r,g,b,e:=parseHexColor(c)
   if e!=nil {return nil,fmt.Errorf("Pixel %d: %w",i,e)}
   r,g,b=scaleRGB(r,g,b,brightness)
   out[i]=rgbPixel{r,g,b}
 }
 return out,nil
}
func applyGigabytePixels(board,zone string, colors []string,brightness string) Resp {
 if !boardAllowed(board) {return Resp{"ok":false,"code":"board-not-allowlisted"}}
 _,header,countIndex,normalized,e:=zoneInfo(zone)
 if e!=nil {return Resp{"ok":false,"code":"zone-not-allowlisted","error":e.Error()}}
 pixels,e:=pixelFrameFromStrings(colors,brightness)
 if e!=nil {return Resp{"ok":false,"code":"invalid-pixels","error":e.Error()}}
 argbRuntimeMu.Lock()
 defer argbRuntimeMu.Unlock()
 h,pid,_,e:=findGigabyteController()
 if e!=nil {return Resp{"ok":false,"code":"controller-not-found","error":e.Error()}}
 defer procClose.Call(uintptr(h))
 report,e:=readGigabyteReport(h,pid)
 if e!=nil{return Resp{"ok":false,"error":e.Error()}}
 if e=prepareGigabyteDirectOwnership(h);e!=nil{return Resp{"ok":false,"error":e.Error()}}
 if e=sendDirectArgbPixels(h,header,report.cal[countIndex],pixels);e!=nil{return Resp{"ok":false,"error":e.Error()}}
 rememberArgbPixels(board,normalized,brightness,colors)
 return Resp{"ok":true,"driver":"gigabyte-rgbfusion2-usb","zone":normalized,"mode":"native-direct-custom-pixels","pixels":len(pixels),"fanLock":true}
}

func loadArgbHoldsFromDisk() {
	path := argbHoldFile()
	if path == "" {
		return
	}
	b, err := os.ReadFile(path)
	if err != nil || len(b) == 0 {
		return
	}
	var items []argbHoldState
	if json.Unmarshal(b, &items) != nil {
		return
	}
	argbHoldMu.Lock()
	for _, h := range items {
		if h.Zone != "" {
			if h.Effect == "" {
				h.Effect = "static"
			}
			if h.StartedMs <= 0 {
				h.StartedMs = time.Now().UnixMilli()
			}
			argbHolds[strings.ToUpper(h.Zone)] = h
		}
	}
	argbHoldMu.Unlock()
}

func snapshotArgbHolds() []argbHoldState {
	argbHoldMu.RLock()
	defer argbHoldMu.RUnlock()
	out := make([]argbHoldState, 0, len(argbHolds))
	for _, h := range argbHolds {
		out = append(out, h)
	}
	return out
}

func directCountForCable(reported int) int {
	// AsiaHorse Aurora/ARGB cable covers are passive strips and may expose more
	// LEDs than the controller's stored default. Direct RGB packets can safely
	// clock extra pixels; a shorter strip simply ignores data past its end.
	if reported < 120 {
		return 120
	}
	if reported > 256 {
		return 256
	}
	return reported
}

func prepareGigabyteDirectOwnership(h syscall.Handle) error {
	if err := sendCC(h, 0x31, 0x00, 0x00); err != nil {
		return err
	} // Beat/audio OFF
	if err := sendCC(h, 0x48, 0x00, 0x00); err != nil {
		return err
	} // LampArray OFF
	// IT5702: bit0=D_LED1 and bit1=D_LED2. Setting both bits disables the
	// built-in hardware effect engine for both headers, leaving Direct ARGB data
	// as the owner. This mirrors SetStripBuiltinEffectState(..., false).
	if err := sendCC(h, 0x32, 0x03, 0x00); err != nil {
		return err
	}
	time.Sleep(18 * time.Millisecond)
	return nil
}

// prepareGigabyteStaticOwnership mirrors the RGB Fusion 2 hardware-effect path:
// Beat/LampArray are disabled, while the built-in effect engine is ENABLED for
// D_LED1/D_LED2 (0x32 bitmask cleared). This is required for a persistent
// hardware STATIC effect; Direct ARGB instead requires these bits to be set.
func prepareGigabyteStaticOwnership(h syscall.Handle) error {
	if err := sendCC(h, 0x31, 0x00, 0x00); err != nil {
		return err
	}
	if err := sendCC(h, 0x48, 0x00, 0x00); err != nil {
		return err
	}
	// Enable built-in effects for both D_LED headers.
	if err := sendCC(h, 0x32, 0x00, 0x00); err != nil {
		return err
	}
	time.Sleep(20 * time.Millisecond)
	return nil
}

func persistGigabyteLighting(h syscall.Handle) error {
	// Enable persistent lighting, then save current hardware state to flash.
	if err := sendCC(h, 0x47, 0x01, 0x00); err != nil {
		return err
	}
	time.Sleep(20 * time.Millisecond)
	if err := sendCC(h, 0x5E, 0x00, 0x00); err != nil {
		return err
	}
	time.Sleep(25 * time.Millisecond)
	return nil
}

var argbRuntimeMu sync.Mutex
var argbRuntimeHandle syscall.Handle
var argbRuntimePID uint16
var argbRuntimeReport gigabyteReport
var argbRuntimeLastOwnership time.Time
var argbRuntimeLastDiskLoad time.Time

func closeArgbRuntimeLocked() {
	if argbRuntimeHandle != 0 {
		procClose.Call(uintptr(argbRuntimeHandle))
		argbRuntimeHandle = 0
		argbRuntimePID = 0
		argbRuntimeReport = gigabyteReport{}
	}
}

func refreshHeldArgb() {
	argbRuntimeMu.Lock()
	defer argbRuntimeMu.Unlock()

	// A one-shot fallback bridge can update argb-hold.json even when the resident
	// engine did not receive the original apply request. Reload periodically so
	// Direct Hold always survives that path and also survives Windows logon.
	if time.Since(argbRuntimeLastDiskLoad) > time.Second {
		loadArgbHoldsFromDisk()
		argbRuntimeLastDiskLoad = time.Now()
	}
	holds := snapshotArgbHolds()
	if len(holds) == 0 {
		closeArgbRuntimeLocked()
		return
	}
	if argbRuntimeHandle == 0 {
		h, pid, _, err := findGigabyteController()
		if err != nil {
			return
		}
		report, err := readGigabyteReport(h, pid)
		if err != nil {
			procClose.Call(uintptr(h))
			return
		}
		argbRuntimeHandle = h
		argbRuntimePID = pid
		argbRuntimeReport = report
		argbRuntimeLastOwnership = time.Time{}
	}
	// Reassert ownership every few seconds. The actual pixel frames are refreshed
	// much faster below. This is intentionally Direct mode because the user's
	// AsiaHorse strips visibly react to Direct packets whereas hardware STATIC
	// switches the addressable outputs off on this IT5702 layout.
	if argbRuntimeLastOwnership.IsZero() || time.Since(argbRuntimeLastOwnership) > 2*time.Second {
		if err := prepareGigabyteDirectOwnership(argbRuntimeHandle); err != nil {
			closeArgbRuntimeLocked()
			return
		}
		argbRuntimeLastOwnership = time.Now()
	}
	for _, st := range holds {
		_, header, countIndex, _, e := zoneInfo(st.Zone)
		if e != nil {
			continue
		}
		count := directCountForCable(argbRuntimeReport.counts[countIndex])
		elapsed := float64(time.Now().UnixMilli()-st.StartedMs) / 1000.0
		var pixels []rgbPixel
        if st.Effect == "custom" {
            pixels, e = pixelFrameFromStrings(st.Pixels,st.Brightness)
        } else {
            pixels, e = makeArgbEffectFrame(st.Effect, st.Color, st.Brightness, count, elapsed)
        }
        if e!=nil {continue}
		if e := sendDirectArgbPixels(argbRuntimeHandle, header, argbRuntimeReport.cal[countIndex], pixels); e != nil {
			closeArgbRuntimeLocked()
			return
		}
	}
}

func applyGigabyte(board, zone, color, brightness string) Resp {
	// Serialize direct HID writes with the resident ARGB compositor.
	// This prevents a static apply from colliding with a 20 Hz effect frame.
	argbRuntimeMu.Lock()
	defer argbRuntimeMu.Unlock()
	if !boardAllowed(board) {
		return Resp{"ok": false, "code": "board-not-allowlisted", "error": "Carte mère non autorisée par la liste blanche EXDEV."}
	}
	_, header, countIndex, normalized, err := zoneInfo(zone)
	if err != nil {
		return Resp{"ok": false, "code": "zone-not-allowlisted", "error": err.Error()}
	}
	r, g, b, err := parseHexColor(color)
	if err != nil {
		return Resp{"ok": false, "code": "bad-color", "error": err.Error()}
	}
	r, g, b = scaleRGB(r, g, b, brightness)
	h, pid, path, err := findGigabyteController()
	if err != nil {
		return Resp{"ok": false, "code": "controller-not-found", "error": err.Error()}
	}
	defer procClose.Call(uintptr(h))
	report, err := readGigabyteReport(h, pid)
	if err != nil {
		return Resp{"ok": false, "code": "hid-report-failed", "error": err.Error(), "pid": fmt.Sprintf("%04X", pid)}
	}

	// Recovery path for the user's passive AsiaHorse ARGB cable covers. Hardware
	// STATIC on this IT5702 layout turned D_LED1/D_LED2 completely off, while a
	// Direct frame is known to light the strips. Keep Direct ownership and persist
	// the desired state for the elevated resident engine to refresh continuously.
	if err := prepareGigabyteDirectOwnership(h); err != nil {
		return Resp{"ok": false, "code": "argb-direct-ownership-failed", "error": err.Error(), "pid": fmt.Sprintf("%04X", pid)}
	}
	count := directCountForCable(report.counts[countIndex])
	if err := sendDirectArgb(h, header, report.cal[countIndex], count, r, g, b); err != nil {
		return Resp{"ok": false, "code": "argb-direct-write-failed", "error": err.Error(), "pid": fmt.Sprintf("%04X", pid)}
	}
	time.Sleep(15 * time.Millisecond)
	if err := sendDirectArgb(h, header, report.cal[countIndex], count, r, g, b); err != nil {
		return Resp{"ok": false, "code": "argb-direct-confirm-failed", "error": err.Error(), "pid": fmt.Sprintf("%04X", pid)}
	}
	rememberArgbHold(board, normalized, color, brightness, "static", time.Now().UnixMilli())
	return Resp{"ok": true, "driver": "gigabyte-rgbfusion2-usb", "mode": "direct-held-persistent-engine", "runtimeHold": true, "persistentFlash": false, "zone": normalized, "header": fmt.Sprintf("0x%02X", header), "ledsClocked": count, "color": fmt.Sprintf("#%02X%02X%02X", r, g, b), "pid": fmt.Sprintf("%04X", pid), "path": path, "fanLock": true}
}

func applyGigabyteEffect(board, zone, effect, color, brightness string) Resp {
	if !boardAllowed(board) {
		return Resp{"ok": false, "code": "board-not-allowlisted", "error": "Carte mère non autorisée par la liste blanche EXDEV."}
	}
	_, _, _, normalized, err := zoneInfo(zone)
	if err != nil {
		return Resp{"ok": false, "code": "zone-not-allowlisted", "error": err.Error()}
	}
	effect = strings.ToLower(strings.TrimSpace(effect))
	switch effect {
	case "wave", "breath", "spectrum", "cycle", "flash":
	default:
		return Resp{"ok": false, "code": "effect-not-supported", "error": "Effet ARGB non pris en charge."}
	}
	if _, _, _, err := parseHexColor(color); err != nil {
		return Resp{"ok": false, "code": "bad-color", "error": err.Error()}
	}
	started := time.Now().UnixMilli()
	rememberArgbHold(board, normalized, color, brightness, effect, started)
	// Render immediately through the persistent compositor. The 50 ms ticker then
	// keeps both headers on the same monotonic timeline instead of replaying whole-device
	// static writes from Electron.
	refreshHeldArgb()
	return Resp{"ok": true, "driver": "gigabyte-rgbfusion2-usb", "mode": "native-per-led-fx", "effect": effect, "zone": normalized, "startedMs": started, "fanLock": true}
}

// -----------------------------------------------------------------------------
// AORUS Radeon RX 9070 XT Elite RGB-only path through AMD ADL I2C.
// The allowlist is exact: AMD 1002:7550 + GIGABYTE subsystem 1458:2426. RGB probes are limited to I2C 0x75 and 0x73.
// No ADL Overdrive, fan, PWM, clock or voltage entry point is loaded.
// -----------------------------------------------------------------------------
var adlAllocations []uintptr
var adlAllocMu sync.Mutex

func adlAlloc(size uintptr) uintptr {
	heap, _, _ := procGetProcessHeap.Call()
	if heap == 0 {
		return 0
	}
	p, _, _ := procHeapAlloc.Call(heap, 0, size)
	if p != 0 {
		adlAllocMu.Lock()
		adlAllocations = append(adlAllocations, p)
		adlAllocMu.Unlock()
	}
	return p
}

func cString(b []byte) string {
	if i := strings.IndexByte(string(b), 0); i >= 0 {
		return string(b[:i])
	}
	return string(b)
}

type adlSession struct {
	dll      *syscall.LazyDLL
	context  uintptr
	adapter  int32
	adapters []int32
	destroy  *syscall.LazyProc
	writeI2C *syscall.LazyProc
	pnp      string
}

func adlErrorName(code int32) string {
	switch code {
	case 0:
		return "ADL_OK"
	case -1:
		return "ADL_ERR"
	case -2:
		return "ADL_ERR_NOT_INIT"
	case -3:
		return "ADL_ERR_INVALID_PARAM"
	case -4:
		return "ADL_ERR_INVALID_PARAM_SIZE"
	case -5:
		return "ADL_ERR_INVALID_ADL_IDX"
	case -8:
		return "ADL_ERR_NOT_SUPPORTED"
	case -9:
		return "ADL_ERR_NULL_POINTER"
	default:
		return "ADL_ERROR"
	}
}

func appendUniqueAdapter(dst []int32, v int32) []int32 {
	for _, x := range dst {
		if x == v {
			return dst
		}
	}
	return append(dst, v)
}

func isAorus9070PNP(pnp string) bool {
	p := strings.ToUpper(pnp)
	return strings.Contains(p, "VEN_1002") && strings.Contains(p, "DEV_7550") && strings.Contains(p, "SUBSYS_24261458")
}

func openAorus9070XT() (*adlSession, error) {
	dll := syscall.NewLazyDLL("atiadlxx.dll")
	create := dll.NewProc("ADL2_Main_Control_Create")
	destroy := dll.NewProc("ADL2_Main_Control_Destroy")
	num := dll.NewProc("ADL2_Adapter_NumberOfAdapters_Get")
	infoX2 := dll.NewProc("ADL2_Adapter_AdapterInfoX2_Get")
	infoX4 := dll.NewProc("ADL2_Adapter_AdapterInfoX4_Get")
	write := dll.NewProc("ADL2_Display_WriteAndReadI2C")
	for _, p := range []*syscall.LazyProc{create, destroy, num, infoX2, write} {
		if err := p.Find(); err != nil {
			return nil, fmt.Errorf("AMD ADL indisponible: %w", err)
		}
	}
	cb := syscall.NewCallback(func(sz uintptr) uintptr { return adlAlloc(sz) })
	var ctx uintptr
	r, _, _ := create.Call(cb, 1, uintptr(unsafe.Pointer(&ctx)))
	if int32(r) != 0 || ctx == 0 {
		return nil, fmt.Errorf("ADL2_Main_Control_Create code %d (%s)", int32(r), adlErrorName(int32(r)))
	}
	closeOnErr := func() { destroy.Call(ctx) }
	candidates := []int32{}
	pnpSeen := ""
	diag := []string{}

	// Modern ADL/OpenRGB path: enumerate extended X4 records with the actual
	// physical/logical adapter indexes. A single GPU may expose multiple indexes.
	if infoX4.Find() == nil {
		var n int32
		var infos uintptr
		r4, _, _ := infoX4.Call(ctx, uintptr(^uint32(0)), uintptr(unsafe.Pointer(&n)), uintptr(unsafe.Pointer(&infos)))
		if int32(r4) == 0 && infos != 0 && n > 0 {
			sz := unsafe.Sizeof(ADLAdapterInfoX2{})
			seenBus := map[int32]bool{}
			for i := int32(0); i < n; i++ {
				inf := (*ADLAdapterInfoX2)(unsafe.Pointer(infos + uintptr(i)*sz))
				pnp := cString(inf.PNPString[:])
				if isAorus9070PNP(pnp) {
					// Match OpenRGB's AMD ADL enumeration: one I2C bus per unique PCI bus.
					// Radeon drivers expose several logical adapter indexes for the same GPU;
					// probing all of them produced misleading ACKs on this RX 9070 XT.
					if !seenBus[inf.BusNumber] {
						seenBus[inf.BusNumber] = true
						candidates = appendUniqueAdapter(candidates, inf.AdapterIndex)
						diag = append(diag, fmt.Sprintf("bus %d -> adapter %d", inf.BusNumber, inf.AdapterIndex))
					}
					pnpSeen = strings.ToUpper(pnp)
				}
			}
			diag = append(diag, fmt.Sprintf("X4:%d record(s)", n))
		} else {
			diag = append(diag, fmt.Sprintf("X4 code %d (%s)", int32(r4), adlErrorName(int32(r4))))
		}
	}

	if len(candidates) == 0 {
		var count int32
		rn, _, _ := num.Call(ctx, uintptr(unsafe.Pointer(&count)))
		if int32(rn) == 0 && count > 0 {
			var infos uintptr
			r2, _, _ := infoX2.Call(ctx, uintptr(unsafe.Pointer(&infos)))
			if int32(r2) == 0 && infos != 0 {
				sz := unsafe.Sizeof(ADLAdapterInfo{})
				for i := int32(0); i < count; i++ {
					inf := (*ADLAdapterInfo)(unsafe.Pointer(infos + uintptr(i)*sz))
					pnp := cString(inf.PNPString[:])
					if isAorus9070PNP(pnp) {
						candidates = appendUniqueAdapter(candidates, inf.AdapterIndex)
						pnpSeen = strings.ToUpper(pnp)
					}
				}
				diag = append(diag, fmt.Sprintf("X2:%d record(s)", count))
			} else {
				diag = append(diag, fmt.Sprintf("X2 code %d (%s)", int32(r2), adlErrorName(int32(r2))))
			}
		} else {
			diag = append(diag, fmt.Sprintf("AdapterCount code %d (%s)", int32(rn), adlErrorName(int32(rn))))
		}
	}
	if len(candidates) == 0 {
		closeOnErr()
		return nil, fmt.Errorf("AORUS Radeon RX 9070 XT Elite 1002:7550 / 1458:2426 introuvable dans AMD ADL (%s)", strings.Join(diag, "; "))
	}
	return &adlSession{dll: dll, context: ctx, adapter: candidates[0], adapters: candidates, destroy: destroy, writeI2C: write, pnp: pnpSeen}, nil
}
func (a *adlSession) close() {
	if a != nil && a.context != 0 {
		a.destroy.Call(a.context)
		a.context = 0
	}
}
func (a *adlSession) writeAt(addr byte, payload []byte) error {
	if len(payload) == 0 {
		return errors.New("paquet GPU vide")
	}
	req := ADLI2C{Line: 1, Address: int32(addr << 1), Offset: 0, Action: 2, Speed: 100, DataSize: int32(len(payload)), Data: uintptr(unsafe.Pointer(&payload[0]))}
	req.Size = int32(unsafe.Sizeof(req))
	r, _, _ := a.writeI2C.Call(a.context, uintptr(a.adapter), uintptr(unsafe.Pointer(&req)))
	if int32(r) != 0 {
		return fmt.Errorf("AMD ADL I2C write 0x%02X code %d (%s) [adapter %d]", addr, int32(r), adlErrorName(int32(r)), a.adapter)
	}
	return nil
}
func (a *adlSession) readAt(addr byte, size int) ([]byte, error) {
	if size < 1 || size > 64 {
		return nil, errors.New("taille lecture GPU invalide")
	}
	buf := make([]byte, size)
	req := ADLI2C{Line: 1, Address: int32(addr << 1), Offset: 0, Action: 1, Speed: 100, DataSize: int32(size), Data: uintptr(unsafe.Pointer(&buf[0]))}
	req.Size = int32(unsafe.Sizeof(req))
	r, _, _ := a.writeI2C.Call(a.context, uintptr(a.adapter), uintptr(unsafe.Pointer(&req)))
	if int32(r) != 0 {
		return nil, fmt.Errorf("AMD ADL I2C read 0x%02X code %d (%s) [adapter %d]", addr, int32(r), adlErrorName(int32(r)), a.adapter)
	}
	return buf, nil
}
func (a *adlSession) probeClassic(addr byte) ([]byte, error) {
	if err := a.writeAt(addr, []byte{0xAB, 0, 0, 0, 0, 0, 0, 0}); err != nil {
		return nil, err
	}
	time.Sleep(8 * time.Millisecond)
	b, err := a.readAt(addr, 4)
	if err != nil {
		return nil, err
	}
	if len(b) != 4 || b[0] != 0xAB || (b[1] == 0xAB && b[2] == 0xAB && b[3] == 0xAB) {
		return b, fmt.Errorf("contrôleur RGB Fusion 2 classique non validé @0x%02X: % X", addr, b)
	}
	return b, nil
}
func (a *adlSession) probeBlackwell(addr byte) ([]byte, bool, error) {
	pkt := make([]byte, 64)
	pkt[0], pkt[1] = 0x10, 0x01
	if err := a.writeAt(addr, pkt); err != nil {
		return nil, false, err
	}
	// On the user's RX 9070 XT Elite, adapter 5 ACKs the 64-byte 0x75 write but
	// ADL returns ADL_ERR on the subsequent read. Some Gigabyte new-generation
	// RGB controllers are effectively write-only through the Windows GPU I2C
	// transport. A successful write ACK is therefore accepted as a safe probe;
	// if a read is available we still validate the normal 01 01/02 01 signature.
	time.Sleep(8 * time.Millisecond)
	b, err := a.readAt(addr, 4)
	if err != nil {
		return nil, true, nil
	}
	if len(b) != 4 || b[0] != 0x01 || (b[1] != 0x01 && b[1] != 0x02) || b[2] != 0x01 {
		return b, false, fmt.Errorf("contrôleur RGB Fusion 2 nouvelle génération non validé @0x%02X: % X", addr, b)
	}
	return b, false, nil
}
func adlFreshWrite(adapter int32, line int32, addr byte, payload []byte) error {
	if len(payload) == 0 {
		return errors.New("paquet GPU vide")
	}
	dll := syscall.NewLazyDLL("atiadlxx.dll")
	create := dll.NewProc("ADL2_Main_Control_Create")
	destroy := dll.NewProc("ADL2_Main_Control_Destroy")
	write := dll.NewProc("ADL2_Display_WriteAndReadI2C")
	for _, p := range []*syscall.LazyProc{create, destroy, write} {
		if err := p.Find(); err != nil {
			return fmt.Errorf("AMD ADL indisponible: %w", err)
		}
	}
	cb := syscall.NewCallback(func(sz uintptr) uintptr { return adlAlloc(sz) })
	var ctx uintptr
	rc, _, _ := create.Call(cb, 1, uintptr(unsafe.Pointer(&ctx)))
	if int32(rc) != 0 || ctx == 0 {
		return fmt.Errorf("ADL2_Main_Control_Create code %d (%s)", int32(rc), adlErrorName(int32(rc)))
	}
	defer destroy.Call(ctx)
	req := ADLI2C{Line: line, Address: int32(addr << 1), Offset: 0, Action: 2, Speed: 100, DataSize: int32(len(payload)), Data: uintptr(unsafe.Pointer(&payload[0]))}
	req.Size = int32(unsafe.Sizeof(req))
	r, _, _ := write.Call(ctx, uintptr(adapter), uintptr(unsafe.Pointer(&req)))
	if int32(r) != 0 {
		return fmt.Errorf("AMD ADL I2C write 0x%02X code %d (%s) [adapter %d line %d]", addr, int32(r), adlErrorName(int32(r)), adapter, line)
	}
	return nil
}

type gpuWriteResult struct {
	InitOK      bool
	ZonesOK     []int
	ZonesFailed []string
	SaveOK      bool
	Strategy    string
}

func blackwellQueryPacket() []byte {
	pkt := make([]byte, 64)
	pkt[0], pkt[1] = 0x10, 0x01
	return pkt
}

func blackwellStaticPacket(zone byte, r, g, b byte, brightness int) []byte {
	if brightness < 1 {
		brightness = 1
	}
	if brightness > 100 {
		brightness = 100
	}
	hwBright := byte((brightness*9+50)/100 + 1)
	if hwBright > 10 {
		hwBright = 10
	}
	pkt := make([]byte, 64)
	// Exact current RGB Fusion 2 GPU packet layout used by OpenRGB:
	// TYPE, 0x01, MODE, SPEED, BRIGHTNESS, R, G, B, 0x00, ZONE, COLOR_COUNT...
	pkt[0], pkt[1], pkt[2] = 0x12, 0x01, 0x01 // REG_MODE / STATIC
	pkt[3], pkt[4] = 0x03, hwBright
	pkt[5], pkt[6], pkt[7] = r, g, b
	pkt[8], pkt[9], pkt[10] = 0x00, zone, 0x00
	return pkt
}

func blackwellSavePacket() []byte {
	pkt := make([]byte, 64)
	pkt[0], pkt[1] = 0x13, 0x01
	return pkt
}

// The Gaming layout exposes four UI zones, but Gigabyte/OpenRGB deliberately
// sends SIX hardware zone packets (0..5). Zones 4 and 5 mirror the last UI
// colour. Sending only four packets can be ACKed by ADL without committing a
// visible lighting state on recent RX 9000 firmware.
var blackwellGamingHardwareZones = []byte{0, 1, 2, 3, 4, 5}

func adlPersistentSequence(adapter int32, line int32, addr byte, r, g, b byte, brightness int) gpuWriteResult {
	res := gpuWriteResult{Strategy: "persistent-openrgb-6zone"}
	dll := syscall.NewLazyDLL("atiadlxx.dll")
	create := dll.NewProc("ADL2_Main_Control_Create")
	destroy := dll.NewProc("ADL2_Main_Control_Destroy")
	write := dll.NewProc("ADL2_Display_WriteAndReadI2C")
	for _, p := range []*syscall.LazyProc{create, destroy, write} {
		if err := p.Find(); err != nil {
			res.ZonesFailed = append(res.ZonesFailed, fmt.Sprintf("ADL indisponible: %v", err))
			return res
		}
	}
	cb := syscall.NewCallback(func(sz uintptr) uintptr { return adlAlloc(sz) })
	var ctx uintptr
	rc, _, _ := create.Call(cb, 1, uintptr(unsafe.Pointer(&ctx)))
	if int32(rc) != 0 || ctx == 0 {
		res.ZonesFailed = append(res.ZonesFailed, fmt.Sprintf("ADL2_Main_Control_Create %d (%s)", int32(rc), adlErrorName(int32(rc))))
		return res
	}
	defer destroy.Call(ctx)

	writePacket := func(payload []byte) error {
		req := ADLI2C{Line: line, Address: int32(addr << 1), Offset: 0, Action: 2, Speed: 100, DataSize: int32(len(payload)), Data: uintptr(unsafe.Pointer(&payload[0]))}
		req.Size = int32(unsafe.Sizeof(req))
		rv, _, _ := write.Call(ctx, uintptr(adapter), uintptr(unsafe.Pointer(&req)))
		if int32(rv) != 0 {
			return fmt.Errorf("code %d (%s)", int32(rv), adlErrorName(int32(rv)))
		}
		return nil
	}

	// OpenRGB's detector performs a 0x10 controller transaction before SetZone.
	// We keep the write but intentionally omit readback because this Radeon driver
	// returns ADL_ERR on reads even when the write reaches the controller.
	if err := writePacket(blackwellQueryPacket()); err == nil {
		res.InitOK = true
	} else {
		res.ZonesFailed = append(res.ZonesFailed, "init 0x10: "+err.Error())
		return res
	}

	for _, zone := range blackwellGamingHardwareZones {
		if err := writePacket(blackwellStaticPacket(zone, r, g, b, brightness)); err != nil {
			res.ZonesFailed = append(res.ZonesFailed, fmt.Sprintf("zone %d: %v", zone, err))
			return res
		}
		res.ZonesOK = append(res.ZonesOK, int(zone))
	}
	if err := writePacket(blackwellSavePacket()); err == nil {
		res.SaveOK = true
	} else {
		res.ZonesFailed = append(res.ZonesFailed, "save 0x13: "+err.Error())
	}
	return res
}

func adlFreshSequence(adapter int32, line int32, addr byte, r, g, b byte, brightness int) gpuWriteResult {
	res := gpuWriteResult{Strategy: "fresh-context-openrgb-6zone"}
	// Fallback for drivers that allow only one ADL I2C transaction per context.
	// The protocol sequence still exactly matches the six-zone Gaming layout.
	if err := adlFreshWrite(adapter, line, addr, blackwellQueryPacket()); err == nil {
		res.InitOK = true
	} else {
		res.ZonesFailed = append(res.ZonesFailed, "init 0x10: "+err.Error())
		return res
	}
	for _, zone := range blackwellGamingHardwareZones {
		if err := adlFreshWrite(adapter, line, addr, blackwellStaticPacket(zone, r, g, b, brightness)); err != nil {
			res.ZonesFailed = append(res.ZonesFailed, fmt.Sprintf("zone %d: %v", zone, err))
			continue
		}
		res.ZonesOK = append(res.ZonesOK, int(zone))
		time.Sleep(8 * time.Millisecond)
	}
	if len(res.ZonesOK) == len(blackwellGamingHardwareZones) {
		res.SaveOK = adlFreshWrite(adapter, line, addr, blackwellSavePacket()) == nil
		if !res.SaveOK {
			res.ZonesFailed = append(res.ZonesFailed, "save 0x13: ADL write failed")
		}
	}
	return res
}

func gpuSequenceComplete(r gpuWriteResult) bool {
	return r.InitOK && len(r.ZonesOK) == len(blackwellGamingHardwareZones) && r.SaveOK && len(r.ZonesFailed) == 0
}

func (a *adlSession) applyBlackwellGaming(addr byte, r, g, b byte, brightness int) error {
	if brightness < 1 {
		brightness = 1
	}
	if brightness > 100 {
		brightness = 100
	}
	hwBright := byte((brightness*9+50)/100 + 1) // protocol range 1..10
	if hwBright > 10 {
		hwBright = 10
	}
	// RX 9070 XT Elite is registered as the Gaming layout: 4 RGB zones.
	for zone := byte(0); zone < 4; zone++ {
		pkt := make([]byte, 64)
		pkt[0] = 0x12 // hardware mode register
		pkt[1] = 0x01
		pkt[2] = 0x01 // STATIC
		pkt[3] = 0x03 // normal speed (ignored by static)
		pkt[4] = hwBright
		pkt[5], pkt[6], pkt[7] = r, g, b
		pkt[8] = 0x00
		pkt[9] = zone
		pkt[10] = 0x00
		if err := a.writeAt(addr, pkt); err != nil {
			return fmt.Errorf("zone GPU %d: %w", zone, err)
		}
		time.Sleep(12 * time.Millisecond)
	}
	save := make([]byte, 64)
	save[0], save[1] = 0x13, 0x01
	return a.writeAt(addr, save)
}
func (a *adlSession) applyClassic(addr byte, r, g, b byte, brightness int) error {
	if brightness < 0 {
		brightness = 0
	}
	if brightness > 100 {
		brightness = 100
	}
	hwBright := byte((brightness*0x63 + 50) / 100)
	for z := 0; z < 5; z++ {
		if err := a.writeAt(addr, []byte{0x88, 0x01, 0x02, hwBright, 0x00, byte(z + 1), 0, 0}); err != nil {
			return err
		}
	}
	if err := a.writeAt(addr, []byte{0xB0, 0x01, r, g, b, r, g, b}); err != nil {
		return err
	}
	if err := a.writeAt(addr, []byte{0xB1, 0x01, r, g, b, 0, 0, 0}); err != nil {
		return err
	}
	for _, z := range []byte{4, 5} {
		if err := a.writeAt(addr, []byte{0x40, r, g, b, z, 0, 0, 0}); err != nil {
			return err
		}
	}
	return a.writeAt(addr, []byte{0xAA, 0, 0, 0, 0, 0, 0, 0})
}
func applyAorusGPU(color, brightness string) Resp {
	r, g, b, err := parseHexColor(color)
	if err != nil {
		return Resp{"ok": false, "code": "bad-color", "error": err.Error()}
	}
	n, _ := strconv.Atoi(brightness)
	if n < 0 {
		n = 0
	}
	if n > 100 {
		n = 100
	}

	// Enumerate the exact PCI-allowlisted card using the same physical-bus
	// de-duplication rule as OpenRGB's AMD ADL backend.
	discovery, err := openAorus9070XT()
	if err != nil {
		return Resp{"ok": false, "code": "gpu-adl-not-found", "error": err.Error()}
	}
	adapters := append([]int32(nil), discovery.adapters...)
	discovery.close()

	diagnostics := []string{}
	for _, adapter := range adapters {
		// First try the exact OpenRGB/GCC behaviour: one persistent ADL context,
		// controller transaction 0x10, SIX Gaming hardware zones 0..5, then SaveConfig.
		persistent := adlPersistentSequence(adapter, 1, 0x75, r, g, b, n)
		if gpuSequenceComplete(persistent) {
			return Resp{
				"ok": true, "verified": false,
				"driver": "gigabyte-aorus-rx9070xt-rgb", "model": "AORUS Radeon RX 9070 XT Elite",
				"color": fmt.Sprintf("#%02X%02X%02X", r, g, b), "brightness": n,
				"controllers": []string{"0x75/fusion2-64-gaming-6zone"}, "rgbOnly": true,
				"adapterIndex": adapter, "i2cLine": 1, "zonesAck": persistent.ZonesOK, "saveAck": true,
				"strategy":  persistent.Strategy,
				"warning":   "Séquence RGB Fusion 2 complète acquittée (init + 6 zones + sauvegarde), sans lecture de validation AMD ADL; confirme visuellement le RGB GPU.",
				"fanAccess": false, "pwmAccess": false,
			}
		}

		// Some Radeon Windows drivers ACK the first I2C write of a context then
		// reject following writes. Keep the exact protocol but reopen ADL for each
		// packet. Unlike 1.2.9, success now requires ALL six zones and SaveConfig.
		fresh := adlFreshSequence(adapter, 1, 0x75, r, g, b, n)
		if gpuSequenceComplete(fresh) {
			return Resp{
				"ok": true, "verified": false,
				"driver": "gigabyte-aorus-rx9070xt-rgb", "model": "AORUS Radeon RX 9070 XT Elite",
				"color": fmt.Sprintf("#%02X%02X%02X", r, g, b), "brightness": n,
				"controllers": []string{"0x75/fusion2-64-gaming-6zone"}, "rgbOnly": true,
				"adapterIndex": adapter, "i2cLine": 1, "zonesAck": fresh.ZonesOK, "saveAck": true,
				"strategy":  fresh.Strategy,
				"warning":   "Séquence RGB Fusion 2 complète acquittée via contextes ADL isolés (init + 6 zones + sauvegarde), sans lecture de validation; confirme visuellement le RGB GPU.",
				"fanAccess": false, "pwmAccess": false,
			}
		}

		diagnostics = append(diagnostics, fmt.Sprintf(
			"adapter %d => persistent[%s] init=%v zones=%v save=%v erreurs=%s ; fresh[%s] init=%v zones=%v save=%v erreurs=%s",
			adapter,
			persistent.Strategy, persistent.InitOK, persistent.ZonesOK, persistent.SaveOK, strings.Join(persistent.ZonesFailed, " | "),
			fresh.Strategy, fresh.InitOK, fresh.ZonesOK, fresh.SaveOK, strings.Join(fresh.ZonesFailed, " | "),
		))
	}
	return Resp{
		"ok": false, "code": "gpu-rgb-controller-not-applied",
		"error":     "Aucun contrôleur RGB GPU appliqué avec une séquence complète 0x75 (init + zones 0..5 + save). " + strings.Join(diagnostics, " ; "),
		"fanAccess": false, "pwmAccess": false,
	}
}

// probes Corsair DRAM addresses validated by Corsair VID/PID. No GPU bus path.
// -----------------------------------------------------------------------------
func ctlCode(deviceType, function, method, access uint32) uint32 {
	return (deviceType << 16) | (access << 14) | (function << 2) | method
}
func pawnLoadIOCTL() uint32 { return ctlCode(pawnIODeviceType, pawnLoadFunction, 0, 0) }
func pawnExecIOCTL() uint32 { return ctlCode(pawnIODeviceType, pawnExecFunction, 0, 0) }

func deviceIoControl(h syscall.Handle, code uint32, in []byte, out []byte) (uint32, error) {
	var inPtr, outPtr uintptr
	if len(in) > 0 {
		inPtr = uintptr(unsafe.Pointer(&in[0]))
	}
	if len(out) > 0 {
		outPtr = uintptr(unsafe.Pointer(&out[0]))
	}
	var returned uint32
	r, _, e := procDevIo.Call(uintptr(h), uintptr(code), inPtr, uintptr(len(in)), outPtr, uintptr(len(out)), uintptr(unsafe.Pointer(&returned)), 0)
	if r == 0 {
		return 0, fmt.Errorf("DeviceIoControl 0x%08X: %w", code, e)
	}
	return returned, nil
}

func nativeDir() string      { exe, _ := os.Executable(); return filepath.Dir(exe) }
func pawnModulePath() string { return filepath.Join(nativeDir(), "PawnIO", "SmbusPIIX4.bin") }

func openPawnIO() (syscall.Handle, error) {
	// The GLOBALROOT path works across current PawnIO generations. Keep the
	// historical Win32 alias as a fallback for older installations.
	paths := []string{`\\?\GLOBALROOT\Device\PawnIO`, `\\.\PawnIO`}
	var lastErr error
	for _, devPath := range paths {
		p, _ := syscall.UTF16PtrFromString(devPath)
		h, _, e := procCreateFile.Call(uintptr(unsafe.Pointer(p)), uintptr(genericRead|genericWrite), uintptr(fileShareRead|fileShareWrite|fileShareDelete), 0, uintptr(openExisting), uintptr(fileAttributeNormal), 0)
		if h != invalidHandleValue && h != 0 {
			return syscall.Handle(h), nil
		}
		lastErr = e
	}
	return 0, fmt.Errorf("pilote PawnIO indisponible: %v", lastErr)
}

func loadPawnModule(h syscall.Handle) error {
	blob, err := os.ReadFile(pawnModulePath())
	if err != nil {
		return fmt.Errorf("module SMBus EXDEV absent: %w", err)
	}
	_, err = deviceIoControl(h, pawnLoadIOCTL(), blob, nil)
	if err != nil {
		// PawnIO returns ERROR_BUSY when this signed module is already active.
		// Treat it as loaded; executing the module is the authoritative check.
		msg := strings.ToLower(err.Error())
		if strings.Contains(msg, "resource is in use") || strings.Contains(msg, "ressource demandée est utilisée") || strings.Contains(msg, "error 170") {
			return nil
		}
		return fmt.Errorf("module AMD SMBus refusé: %w", err)
	}
	return nil
}

func configurePawnModule(h syscall.Handle) {
	// Match OpenRGB/rgbctrl: let the PawnIO PIIX4 module sleep between
	// transactions. This reduces host-busy collisions without changing the
	// SMBus clock or any RAM state.
	_, _ = pawnExecute(h, "ioctl_set_sleep_mode", []uint64{2}, 0)
}

func isPawnBusyError(err error) bool {
	if err == nil {
		return false
	}
	if errors.Is(err, syscall.Errno(170)) { // ERROR_BUSY: The requested resource is in use.
		return true
	}
	msg := strings.ToLower(err.Error())
	return strings.Contains(msg, "requested resource is in use") ||
		strings.Contains(msg, "resource is in use") ||
		strings.Contains(msg, "ressource demandée est utilisée") ||
		strings.Contains(msg, "ressource demandee est utilisee") ||
		strings.Contains(msg, "error 170")
}

func pawnExecute(h syscall.Handle, name string, in []uint64, outCount int) ([]uint64, error) {
	if len(name) >= 32 {
		return nil, errors.New("nom PawnIO trop long")
	}
	input := make([]byte, 32+len(in)*8)
	copy(input, []byte(name))
	for i, v := range in {
		binary.LittleEndian.PutUint64(input[32+i*8:40+i*8], v)
	}

	// PawnIO's SmbusPIIX4 module returns STATUS_DEVICE_BUSY when the AMD host
	// controller still has a transaction/status bit asserted. The module already
	// acknowledges stale status once; give the controller a bounded recovery
	// window instead of immediately failing the DIMM write. Only ERROR_BUSY is
	// retried — protocol/CRC/no-device errors are returned immediately.
	backoff := [...]time.Duration{8, 12, 20, 32, 48, 72, 96}
	var lastErr error
	for attempt := 0; attempt <= len(backoff); attempt++ {
		output := make([]byte, outCount*8)
		returned, err := deviceIoControl(h, pawnExecIOCTL(), input, output)
		if err == nil {
			count := int(returned) / 8
			if count > outCount {
				count = outCount
			}
			vals := make([]uint64, count)
			for i := 0; i < count; i++ {
				vals[i] = binary.LittleEndian.Uint64(output[i*8 : (i+1)*8])
			}
			return vals, nil
		}
		lastErr = err
		if !isPawnBusyError(err) || attempt == len(backoff) {
			break
		}
		time.Sleep(backoff[attempt] * time.Millisecond)
	}
	if isPawnBusyError(lastErr) {
		return nil, fmt.Errorf("SMBus AMD occupé après reprises sécurisées: %w", lastErr)
	}
	return nil, lastErr
}

func withSMBusMutexTimeout(timeoutMs uint32, fn func() error) error {
	// Win32 mutex ownership is thread-affine. Keep acquisition and release on the
	// same OS thread even if the Go scheduler would otherwise migrate the goroutine.
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()

	n, _ := syscall.UTF16PtrFromString(`Global\Access_SMBUS.HTP.Method`)
	h, _, e := procCreateMutex.Call(0, 0, uintptr(unsafe.Pointer(n)))
	if h == 0 {
		return fmt.Errorf("mutex SMBus: %v", e)
	}
	defer procClose.Call(h)
	w, _, waitErr := procWait.Call(h, uintptr(timeoutMs))
	if w == waitTimeout {
		return fmt.Errorf("SMBus occupé: verrou global indisponible après %d ms", timeoutMs)
	}
	if w != waitObject0 && w != waitAbandoned {
		return fmt.Errorf("impossible de verrouiller le SMBus (wait=0x%X, err=%v)", w, waitErr)
	}

	fnErr := fn()
	r, _, relErr := procReleaseMutex.Call(h)
	if r == 0 {
		if fnErr != nil {
			return fmt.Errorf("%v; libération mutex SMBus impossible: %v", fnErr, relErr)
		}
		return fmt.Errorf("libération mutex SMBus impossible: %v", relErr)
	}
	return fnErr
}

func withSMBusMutex(fn func() error) error {
	return withSMBusMutexTimeout(3500, fn)
}
func selectPort(h syscall.Handle, port int) (int, error) {
	vals, err := pawnExecute(h, "ioctl_piix4_port_sel", []uint64{uint64(int64(port))}, 1)
	if err != nil {
		return -1, err
	}
	if len(vals) < 1 {
		return -1, errors.New("port SMBus sans réponse")
	}
	return int(int64(vals[0])), nil
}

func smbusReadByte(h syscall.Handle, addr, cmd byte) (byte, error) {
	vals, err := pawnExecute(h, "ioctl_smbus_xfer", []uint64{uint64(addr), smbusRead, uint64(cmd), smbusByteData}, 1)
	if err != nil {
		return 0, err
	}
	if len(vals) < 1 {
		return 0, errors.New("lecture SMBus vide")
	}
	return byte(vals[0] & 0xFF), nil
}
func smbusWriteByte(h syscall.Handle, addr, cmd, val byte) error {
	_, err := pawnExecute(h, "ioctl_smbus_xfer", []uint64{uint64(addr), smbusWrite, uint64(cmd), smbusByteData, uint64(val)}, 0)
	return err
}
func smbusWriteWord(h syscall.Handle, addr, cmd byte, val uint16) error {
	_, err := pawnExecute(h, "ioctl_smbus_xfer", []uint64{uint64(addr), smbusWrite, uint64(cmd), smbusWordData, uint64(val)}, 0)
	return err
}
func smbusWriteBlock(h syscall.Handle, addr, cmd byte, payload []byte) error {
	if len(payload) < 1 || len(payload) > 32 {
		return errors.New("bloc SMBus invalide")
	}
	packed := make([]byte, 40)
	packed[0] = byte(len(payload))
	copy(packed[1:], payload)
	in := []uint64{uint64(addr), smbusWrite, uint64(cmd), smbusBlockData, 0, 0, 0, 0, 0}
	for i := 0; i < 5; i++ {
		in[4+i] = binary.LittleEndian.Uint64(packed[i*8 : (i+1)*8])
	}
	_, err := pawnExecute(h, "ioctl_smbus_xfer", in, 0)
	return err
}

func crc8(data []byte) byte {
	var crc byte
	for _, v := range data {
		crc ^= v
		for i := 0; i < 8; i++ {
			if crc&0x80 != 0 {
				crc = (crc << 1) ^ 0x07
			} else {
				crc <<= 1
			}
		}
	}
	return crc
}

type corsairModule struct {
	Port     int    `json:"port"`
	Address  byte   `json:"address"`
	VID      uint16 `json:"vid"`
	PID      uint16 `json:"pid"`
	Protocol byte   `json:"protocol"`
	Firmware string `json:"firmware"`
	LEDCount int    `json:"ledCount"`
}

var corsairCacheMu sync.Mutex
var corsairCache []corsairModule
var corsairLastScan time.Time

func getCorsairCache() []corsairModule {
	corsairCacheMu.Lock()
	defer corsairCacheMu.Unlock()
	out := make([]corsairModule, len(corsairCache))
	copy(out, corsairCache)
	return out
}

func corsairCacheScanAge() time.Duration {
	corsairCacheMu.Lock()
	defer corsairCacheMu.Unlock()
	if corsairLastScan.IsZero() {
		return 24 * time.Hour
	}
	return time.Since(corsairLastScan)
}

func corsairModuleKey(m corsairModule) string {
	// On AMD PIIX4 systems two physical DDR5 DIMMs can legitimately expose the
	// same Corsair controller address behind different SMBus mux ports.  The
	// physical identity therefore has to include BOTH the mux port and address.
	// The cache merge below preserves a previously confirmed DIMM when a later
	// scan is transiently incomplete, which fixes the one-stick-only regression
	// without collapsing two real modules into one entry.
	return fmt.Sprintf("%d:%02X:%04X:%04X", m.Port, m.Address, m.VID, m.PID)
}

func mergeCorsairCache(v []corsairModule) []corsairModule {
	corsairCacheMu.Lock()
	defer corsairCacheMu.Unlock()
	corsairLastScan = time.Now()
	merged := make(map[string]corsairModule, len(corsairCache)+len(v))
	order := make([]string, 0, len(corsairCache)+len(v))
	for _, m := range corsairCache {
		k := corsairModuleKey(m)
		if _, ok := merged[k]; !ok {
			order = append(order, k)
		}
		merged[k] = m
	}
	// Fresh detections replace stale route information for the same DIMM.
	for _, m := range v {
		k := corsairModuleKey(m)
		if _, ok := merged[k]; !ok {
			order = append(order, k)
		}
		merged[k] = m
	}
	out := make([]corsairModule, 0, len(order))
	for _, k := range order {
		out = append(out, merged[k])
	}
	if len(out) > 0 {
		corsairCache = append([]corsairModule(nil), out...)
	}
	return append([]corsairModule(nil), out...)
}

func readCorsairInfo(h syscall.Handle, addr byte) (corsairModule, error) {
	var m corsairModule
	m.Address = addr
	if err := smbusWriteByte(h, addr, regGetDeviceInfo, 0); err != nil {
		return m, err
	}
	if err := smbusWriteByte(h, addr, regBinaryStart, 0); err != nil {
		return m, err
	}
	info := make([]byte, 32)
	for i := 0; i < 32; i++ {
		v, err := smbusReadByte(h, addr, regGetBinaryData)
		if err != nil {
			return m, err
		}
		info[i] = v
	}
	deviceCRC, err := smbusReadByte(h, addr, regChecksum)
	if err != nil {
		return m, err
	}
	if crc8(info) != deviceCRC {
		return m, errors.New("CRC informations Corsair invalide")
	}
	m.VID = uint16(info[1])<<8 | uint16(info[0])
	m.PID = uint16(info[3])<<8 | uint16(info[2])
	m.Protocol = info[28]
	m.Firmware = fmt.Sprintf("%d.%d.%d", info[9], info[8], uint16(info[11])<<8|uint16(info[10]))
	if m.VID != corsairVID || !corsairVengeanceDDR5PIDs[m.PID] {
		return m, fmt.Errorf("module non autorisé VID=%04X PID=%04X", m.VID, m.PID)
	}
	m.LEDCount = 10
	if m.Protocol < 4 {
		return m, fmt.Errorf("protocole Corsair %d non compatible avec le contrôle EXDEV", m.Protocol)
	}
	return m, nil
}

func probeCorsairSignature(h syscall.Handle, addr byte) bool {
	// OpenRGB spaces DRAM probes by 10 ms. On some AMD PIIX4 systems a DIMM can
	// transiently NACK one read while another controller on the bus just replied.
	// Retry the two read-only signature registers before declaring the route empty.
	for attempt := 0; attempt < 3; attempt++ {
		a, err := smbusReadByte(h, addr, regSignatureA)
		if err == nil && (a == 0x1A || a == 0x1B || a == 0x1C) {
			b, err := smbusReadByte(h, addr, regSignatureB)
			if err == nil && (b == 0x01 || b == 0x03 || b == 0x04) {
				return true
			}
		}
		if attempt < 2 {
			time.Sleep(8 * time.Millisecond)
		}
	}
	return false
}

type corsairProbeDiagnostic struct {
	Port      int    `json:"port"`
	Address   byte   `json:"address"`
	Reg43     int    `json:"reg43"`
	Reg44     int    `json:"reg44"`
	Signature bool   `json:"signature"`
	Verified  bool   `json:"verified"`
	Error     string `json:"error,omitempty"`
	AliasOf   int    `json:"aliasOf,omitempty"`
}

func readCorsairSignatureDetailed(h syscall.Handle, port int, addr byte) corsairProbeDiagnostic {
	d := corsairProbeDiagnostic{Port: port, Address: addr, Reg43: -1, Reg44: -1}
	old, err := selectPort(h, port)
	if err != nil {
		d.Error = "select-port: " + err.Error()
		return d
	}
	defer func() {
		if old >= 0 && old != port {
			_, _ = selectPort(h, old)
		}
	}()
	a, err := smbusReadByte(h, addr, regSignatureA)
	if err != nil {
		d.Error = "reg43: " + err.Error()
		return d
	}
	d.Reg43 = int(a)
	b, err := smbusReadByte(h, addr, regSignatureB)
	if err != nil {
		d.Error = "reg44: " + err.Error()
		return d
	}
	d.Reg44 = int(b)
	d.Signature = (a == 0x1A || a == 0x1B || a == 0x1C) && (b == 0x01 || b == 0x03 || b == 0x04)
	if !d.Signature {
		d.Error = fmt.Sprintf("signature inattendue 43=%02X 44=%02X", a, b)
	}
	return d
}

func hasCorsairRoute(mods []corsairModule, port int, addr byte) bool {
	for _, m := range mods {
		if m.Port == port && m.Address == addr {
			return true
		}
	}
	return false
}

// Targeted recovery for populated DIMM slots reported by SMBIOS. DDR5 Corsair
// controllers use 0x18..0x1F in current hardware implementations; some older
// stacks also expose an alias at +0x40. We only accept a route after the same
// signature + full VID/PID/protocol/CRC validation as normal discovery.
func recoverExpectedCorsair(h syscall.Handle, expected []int) ([]corsairModule, []corsairProbeDiagnostic) {
	mods := getCorsairCache()
	diags := []corsairProbeDiagnostic{}
	seenExpected := map[int]bool{}
	for _, raw := range expected {
		if raw < 0x18 || raw > 0x1F || seenExpected[raw] {
			continue
		}
		seenExpected[raw] = true
		canonical := byte(raw)

		// OpenRGB on Windows registers AMD PIIX4 port 0 and port 1 as separate
		// SMBus interfaces. A two-DIMM kit may therefore expose the second RGB
		// controller on the other port, sometimes at the same address. Probe both
		// ports and both the canonical DDR5 address and its legacy +0x40 alias.
		for _, port := range []int{0, 1} {
			if hasCorsairRoute(mods, port, canonical) || hasCorsairRoute(mods, port, canonical+0x40) {
				continue
			}
			candidates := []byte{canonical, canonical + 0x40}
			for ci, addr := range candidates {
				verified := false
				for attempt := 0; attempt < 6 && !verified; attempt++ {
					d := readCorsairSignatureDetailed(h, port, addr)
					if ci == 1 {
						d.AliasOf = int(canonical)
					}
					if d.Signature {
						old, selErr := selectPort(h, port)
						if selErr != nil {
							d.Error = "select-port: " + selErr.Error()
						} else {
							for infoTry := 0; infoTry < 3; infoTry++ {
								m, err := readCorsairInfo(h, addr)
								if err == nil {
									m.Port = port
									mods = mergeCorsairCache([]corsairModule{m})
									d.Verified = true
									d.Error = ""
									verified = true
									break
								}
								d.Error = "device-info: " + err.Error()
								time.Sleep(10 * time.Millisecond)
							}
							if old >= 0 && old != port {
								_, _ = selectPort(h, old)
							}
						}
					}
					diags = append(diags, d)
					if !verified {
						time.Sleep(time.Duration(15+attempt*10) * time.Millisecond)
					}
				}
				if verified {
					break
				}
			}
		}
	}
	return getCorsairCache(), diags
}

func detectCorsair(h syscall.Handle) ([]corsairModule, error) {
	var found []corsairModule
	// OpenRGB Windows exposes the AMD FCH/PIIX4 primary and auxiliary SMBus
	// interfaces independently. Scan both ports. Prefer the canonical DDR5 RGB
	// range (0x18..0x1F), then the legacy +0x40 aliases only when that logical
	// route was not already verified on the same port.
	canonical := []byte{0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F}
	aliases := []byte{0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F}
	for _, port := range []int{0, 1} {
		old, err := selectPort(h, port)
		if err != nil {
			continue
		}
		logicalSeen := map[byte]bool{}
		probeList := [][]byte{canonical, aliases}
		for rangeIndex, addrs := range probeList {
			for _, addr := range addrs {
				logical := addr
				if logical >= 0x58 && logical <= 0x5F {
					logical -= 0x40
				}
				if rangeIndex == 1 && logicalSeen[logical] {
					continue
				}
				if probeCorsairSignature(h, addr) {
					for infoTry := 0; infoTry < 2; infoTry++ {
						m, infoErr := readCorsairInfo(h, addr)
						if infoErr == nil {
							m.Port = port
							found = append(found, m)
							logicalSeen[logical] = true
							break
						}
						if infoTry == 0 {
							time.Sleep(12 * time.Millisecond)
						}
					}
				}
				time.Sleep(10 * time.Millisecond)
			}
		}
		if old >= 0 && old != port {
			_, _ = selectPort(h, old)
		}
	}

	// Deduplicate canonical/alias views of the same logical route, but keep the
	// same address on different PIIX4 ports because those can be two real DIMMs.
	type picked struct {
		m         corsairModule
		canonical bool
	}
	chosen := map[string]picked{}
	order := []string{}
	for _, m := range found {
		logical := m.Address
		isCanonical := logical >= 0x18 && logical <= 0x1F
		if logical >= 0x58 && logical <= 0x5F {
			logical -= 0x40
		}
		k := fmt.Sprintf("%d:%02X", m.Port, logical)
		prev, ok := chosen[k]
		if !ok {
			order = append(order, k)
			chosen[k] = picked{m: m, canonical: isCanonical}
			continue
		}
		if !prev.canonical && isCanonical {
			chosen[k] = picked{m: m, canonical: true}
		}
	}
	fresh := make([]corsairModule, 0, len(order))
	for _, k := range order {
		fresh = append(fresh, chosen[k].m)
	}
	return mergeCorsairCache(fresh), nil
}

func waitCorsairReady(h syscall.Handle, addr byte) error {
	// OpenRGB's current Corsair DRAM protocol uses register 0x30, bit 3 as the
	// controller busy flag. A Vengeance DDR5 can NACK every SMBus access for
	// roughly 100-120 ms while committing configuration; that is normal, not a
	// failed DIMM. Allow up to one second and retry quietly until the controller
	// comes back and clears the busy bit.
	deadline := time.Now().Add(1 * time.Second)
	for time.Now().Before(deadline) {
		status, err := smbusReadByte(h, addr, regStatus)
		if err == nil && status&0x08 == 0 {
			return nil
		}
		time.Sleep(5 * time.Millisecond)
	}
	return errors.New("contrôleur Corsair RGB non prêt après 1 s")
}

func corsairEffectMode(effect string) (mode, speed, direction byte, random bool, normalized string, ok bool) {
	switch strings.ToLower(strings.TrimSpace(effect)) {
	case "", "static":
		return 0x10, 0x01, 0x03, false, "static", true
	case "breath", "breathing":
		return 0x01, 0x01, 0x03, false, "breath", true
	case "wave":
		return 0x04, 0x01, 0x03, false, "wave", true
	case "spectrum", "rainbow":
		return 0x03, 0x01, 0x03, true, "spectrum", true
	case "cycle", "shift":
		return 0x00, 0x01, 0x03, true, "cycle", true
	case "flash":
		// Corsair DRAM has no dedicated flash opcode. A fast color-pulse is the
		// closest hardware-native effect and avoids software SMBus hammering.
		return 0x01, 0x02, 0x03, false, "flash", true
	default:
		return 0, 0, 0, false, "", false
	}
}

func writeCorsairHardwareEffect(h syscall.Handle, m corsairModule, effect, color, brightness string) error {
	mode, speed, direction, random, normalized, ok := corsairEffectMode(effect)
	if !ok {
		return fmt.Errorf("effet Corsair non supporté: %s", effect)
	}
	r, g, b, err := parseHexColor(color)
	if err != nil {
		return err
	}
	// The Vengeance effect protocol has no independent brightness byte. Scale the
	// user colour itself, then send the exact 20-byte effect descriptor.
	r, g, b = scaleRGB(r, g, b, brightness)
	r2, g2, b2 := byte(0), byte(0), byte(0)
	if normalized == "static" {
		r2, g2, b2 = r, g, b
	}
	randomByte := byte(0x01) // custom colours
	if random {
		randomByte = 0x00
	}
	packet := []byte{
		mode, speed, randomByte, direction,
		r, g, b, 0xFF,
		r2, g2, b2, 0xFF,
		0, 0, 0, 0, 0, 0, 0, 0,
	}
	if err := waitCorsairReady(h, m.Address); err != nil {
		return err
	}
	// Reset Corsair's binary configuration buffer, stream the descriptor, then
	// compare the controller CRC before committing it. Never save a partial or
	// corrupted descriptor to the DIMM.
	if err := smbusWriteByte(h, m.Address, regResetBuffer, 0x00); err != nil {
		return err
	}
	if err := smbusWriteByte(h, m.Address, regBinaryStart, 0x00); err != nil {
		return err
	}
	for _, v := range packet {
		if err := smbusWriteByte(h, m.Address, regSetBinaryData, v); err != nil {
			return err
		}
	}
	receivedCRC, err := smbusReadByte(h, m.Address, regChecksum)
	if err != nil {
		return err
	}
	expectedCRC := crc8(packet)
	if receivedCRC != expectedCRC {
		return fmt.Errorf("CRC effet Corsair invalide: reçu 0x%02X attendu 0x%02X", receivedCRC, expectedCRC)
	}
	if err := smbusWriteByte(h, m.Address, regWriteConfiguration, corsairEffectConfigID); err != nil {
		return err
	}
	return waitCorsairReady(h, m.Address)
}

func applyCorsairEffectScoped(part, effect, color, brightness string, targetPort, targetAddress int, scoped bool) Resp {
	if !strings.EqualFold(strings.TrimSpace(part), "CMH32GX5M2B5200Z40") {
		return Resp{"ok": false, "code": "ram-not-allowlisted", "error": "Ce kit Corsair n’est pas autorisé par le profil stable EXDEV."}
	}
	_, _, _, _, normalized, supported := corsairEffectMode(effect)
	if !supported {
		return Resp{"ok": false, "code": "effect-not-supported", "error": "Effet non pris en charge sur la RAM Corsair."}
	}
	if _, _, _, err := parseHexColor(color); err != nil {
		return Resp{"ok": false, "code": "bad-color", "error": err.Error()}
	}
	h, err := openPawnIO()
	if err != nil {
		return Resp{"ok": false, "code": "pawnio-driver-required", "error": "Pilote SMBus EXDEV/PawnIO absent. Relance EXDEV_RGB_INSTALLER.exe en administrateur."}
	}
	defer procClose.Call(uintptr(h))
	if err := loadPawnModule(h); err != nil {
		return Resp{"ok": false, "code": "pawnio-module-required", "error": err.Error()}
	}
	configurePawnModule(h)
	var mods []corsairModule
	err = withSMBusMutex(func() error { var e error; mods, e = detectCorsair(h); return e })
	if err != nil {
		return Resp{"ok": false, "code": "smbus-detect-failed", "error": err.Error()}
	}
	if len(mods) == 0 {
		mods = getCorsairCache()
	}
	if len(mods) == 0 {
		return Resp{"ok": false, "code": "ram-controller-not-found", "error": "Aucun contrôleur RGB Corsair Vengeance DDR5 validé sur le SMBus."}
	}
	if scoped {
		filtered := make([]corsairModule, 0, 1)
		for _, m := range mods {
			if m.Port == targetPort && int(m.Address) == targetAddress {
				filtered = append(filtered, m)
			}
		}
		mods = filtered
		if len(mods) == 0 {
			return Resp{"ok": false, "code": "ram-route-not-found", "error": "La barrette sélectionnée n’est plus disponible sur sa route SMBus validée."}
		}
	}

	applied := 0
	details := []Resp{}
	failures := []Resp{}
	err = withSMBusMutex(func() error {
		for _, m := range mods {
			var lastErr error
			attempts := 0
			for attempt := 1; attempt <= 3; attempt++ {
				attempts = attempt
				old, e := selectPort(h, m.Port)
				if e == nil {
					e = writeCorsairHardwareEffect(h, m, normalized, color, brightness)
				}
				if old >= 0 && old != m.Port {
					_, _ = selectPort(h, old)
				}
				if e == nil {
					lastErr = nil
					break
				}
				lastErr = e
				time.Sleep(time.Duration(18*attempt) * time.Millisecond)
			}
			if lastErr != nil {
				failures = append(failures, Resp{"port": m.Port, "address": fmt.Sprintf("0x%02X", m.Address), "error": lastErr.Error(), "attempts": attempts})
				continue
			}
			applied++
			setCorsairDirectReady(m, false)
			details = append(details, Resp{"port": m.Port, "address": fmt.Sprintf("0x%02X", m.Address), "pid": fmt.Sprintf("%04X", m.PID), "protocol": m.Protocol, "firmware": m.Firmware, "attempts": attempts})
			time.Sleep(12 * time.Millisecond)
		}
		return nil
	})
	if err != nil {
		return Resp{"ok": false, "code": "ram-write-failed", "error": err.Error(), "applied": applied, "failures": failures}
	}
	if len(failures) > 0 {
		return Resp{"ok": false, "code": "ram-partial-write", "error": fmt.Sprintf("%d/%d module(s) Corsair mis à jour. Une barrette n’a pas répondu après les reprises sécurisées.", applied, len(mods)), "modules": applied, "details": details, "failures": failures, "effect": normalized, "fanLock": true}
	}
	return Resp{"ok": true, "driver": "corsair-ddr5", "modules": applied, "details": details, "color": strings.ToUpper(color), "brightness": brightness, "effect": normalized, "fanLock": true}
}

func applyCorsairEffect(part, effect, color, brightness string) Resp {
	return applyCorsairEffectScoped(part, effect, color, brightness, 0, 0, false)
}

type corsairZoneTarget struct {
	Port    int      `json:"port"`
	Address int      `json:"address"`
	Colors  []string `json:"colors"`
}

var corsairDirectModeMu sync.Mutex
var corsairDirectMode = map[string]bool{}

func corsairDirectReady(m corsairModule) bool {
	corsairDirectModeMu.Lock()
	defer corsairDirectModeMu.Unlock()
	return corsairDirectMode[corsairModuleKey(m)]
}

func setCorsairDirectReady(m corsairModule, ready bool) {
	corsairDirectModeMu.Lock()
	defer corsairDirectModeMu.Unlock()
	corsairDirectMode[corsairModuleKey(m)] = ready
}

func fitCorsairLEDColors(colors []string, ledCount int, brightness string) ([][3]byte, error) {
	if ledCount < 1 || ledCount > 12 {
		return nil, errors.New("nombre de LED Corsair invalide")
	}
	if len(colors) < 1 || len(colors) > ledCount {
		return nil, fmt.Errorf("1 à %d couleurs LED sont requises", ledCount)
	}
	out := make([][3]byte, ledCount)
	for i := 0; i < ledCount; i++ {
		c := colors[i]
		if i >= len(colors) {
			c = colors[len(colors)-1]
		}
		r, g, b, err := parseHexColor(c)
		if err != nil {
			return nil, fmt.Errorf("LED %d: %w", i+1, err)
		}
		r, g, b = scaleRGB(r, g, b, brightness)
		out[i] = [3]byte{r, g, b}
	}
	return out, nil
}

func writeCorsairDirectWords(h syscall.Handle, addr byte, packet []byte) error {
	// Exact fallback used by OpenRGB's Corsair DRAM controller when the host
	// SMBus adapter refuses SMBUS_BLOCK_DATA. Corsair packs five payload bytes
	// across two WORD_DATA writes; the third byte is split between the low
	// nibble of the first register and the low nibble of the second register.
	for blockIndex := 0; blockIndex < len(packet); {
		reg0 := byte(0xA0)
		reg1 := byte(0x00)
		if blockIndex == 0 {
			reg0 = 0x90
		}

		word0 := uint16(packet[blockIndex])
		blockIndex++
		if blockIndex < len(packet) {
			word0 |= uint16(packet[blockIndex]) << 8
			blockIndex++
		}
		if blockIndex < len(packet) {
			reg1 = 0xA0
			reg0 |= packet[blockIndex] & 0x0F
			reg1 |= (packet[blockIndex] & 0xF0) >> 4
			blockIndex++
		}

		var word1 uint16
		if blockIndex < len(packet) {
			word1 = uint16(packet[blockIndex])
			blockIndex++
		}
		if blockIndex < len(packet) {
			word1 |= uint16(packet[blockIndex]) << 8
			blockIndex++
		}

		if err := smbusWriteWord(h, addr, reg0, word0); err != nil {
			return fmt.Errorf("fallback WORD reg 0x%02X: %w", reg0, err)
		}
		if reg1 != 0 {
			if err := smbusWriteWord(h, addr, reg1, word1); err != nil {
				return fmt.Errorf("fallback WORD reg 0x%02X: %w", reg1, err)
			}
		}
	}
	return nil
}

func writeCorsairDirectLEDs(h syscall.Handle, m corsairModule, colors [][3]byte) (string, error) {
	if len(colors) != m.LEDCount {
		return "", fmt.Errorf("%d couleurs reçues pour %d LED", len(colors), m.LEDCount)
	}
	// Protocol >= 4, same direct packet used by current OpenRGB:
	// [LED count][R G B × N][CRC-8]. Vengeance RGB DDR5 has 10 LEDs, so the
	// complete frame is exactly 32 bytes. Direct mode is a software-side state;
	// DO NOT commit a Static effect before this frame (that save can make the
	// controller NACK the SMBus for ~100 ms and was the cause of EXDEV's partial
	// writes in 1.6.2).
	packet := make([]byte, 1+m.LEDCount*3+1)
	packet[0] = byte(m.LEDCount)
	for i, c := range colors {
		o := 1 + i*3
		packet[o], packet[o+1], packet[o+2] = c[0], c[1], c[2]
	}
	packet[len(packet)-1] = crc8(packet[:len(packet)-1])

	blockErr := smbusWriteBlock(h, m.Address, regColorBlock1, packet[:minInt(len(packet), 32)])
	if blockErr == nil {
		if len(packet) > 32 {
			if err := smbusWriteBlock(h, m.Address, regColorBlock2, packet[32:]); err != nil {
				blockErr = err
			} else {
				setCorsairDirectReady(m, true)
				return "smbus-block", nil
			}
		} else {
			setCorsairDirectReady(m, true)
			return "smbus-block", nil
		}
	}

	// OpenRGB fallback for SMBus hosts/drivers that do not support block data.
	// This is especially relevant on some AMD PIIX4/PawnIO paths.
	if err := writeCorsairDirectWords(h, m.Address, packet); err != nil {
		setCorsairDirectReady(m, false)
		return "", fmt.Errorf("SMBus block refusé (%v); fallback WORD refusé (%w)", blockErr, err)
	}
	setCorsairDirectReady(m, true)
	return "smbus-word-fallback", nil
}

func minInt(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func ensureCorsairDirectMode(h syscall.Handle, m corsairModule, seedColor, brightness string) error {
	// OpenRGB's Direct mode does not write/commit an effect descriptor. It only
	// switches its software state and sends direct LED frames. Keep this helper as
	// a compatibility no-op so older call sites cannot accidentally save Static.
	_ = h
	_ = seedColor
	_ = brightness
	setCorsairDirectReady(m, true)
	return nil
}

func findCorsairModule(mods []corsairModule, port int, address int) (corsairModule, bool) {
	for _, m := range mods {
		if m.Port == port && int(m.Address) == address {
			return m, true
		}
	}
	return corsairModule{}, false
}

func discoverCorsairModulesWithHints(h syscall.Handle, expected []int) ([]corsairModule, []corsairProbeDiagnostic, error) {
	mods := getCorsairCache()
	diagnostics := []corsairProbeDiagnostic{}
	if len(mods) >= 2 && corsairCacheScanAge() < 5*time.Second {
		return mods, diagnostics, nil
	}
	var lastErr error
	// Never hold the global SMBus mutex across the whole multi-pass discovery.
	// OpenRGB/rgbctrl arbitrate the bus for short transactions; doing the same
	// lets iCUE/sensors/other RGB software get a turn and prevents startup scans
	// from starving the bus for several seconds.
	for pass := 0; pass < 5; pass++ {
		var detectErr error
		lockErr := withSMBusMutexTimeout(1500, func() error {
			_, detectErr = detectCorsair(h)
			return detectErr
		})
		if lockErr != nil {
			lastErr = lockErr
		} else if detectErr != nil {
			lastErr = detectErr
		}
		mods = getCorsairCache()
		if len(mods) >= 2 {
			return mods, diagnostics, nil
		}
		time.Sleep(time.Duration(45+pass*20) * time.Millisecond)
	}
	if len(expected) > 0 && len(mods) < len(expected) {
		var targeted []corsairProbeDiagnostic
		var recovered []corsairModule
		lockErr := withSMBusMutexTimeout(1800, func() error {
			recovered, targeted = recoverExpectedCorsair(h, expected)
			return nil
		})
		diagnostics = append(diagnostics, targeted...)
		if lockErr != nil {
			lastErr = lockErr
		} else {
			mods = recovered
		}
	}
	mods = getCorsairCache()
	if len(mods) > 0 {
		return mods, diagnostics, nil
	}
	return nil, diagnostics, lastErr
}
func discoverCorsairModules(h syscall.Handle) ([]corsairModule, error) {
	mods, _, err := discoverCorsairModulesWithHints(h, nil)
	return mods, err
}

func applyCorsairZones(part string, targets []corsairZoneTarget, brightness string) Resp {
	if !strings.EqualFold(strings.TrimSpace(part), "CMH32GX5M2B5200Z40") {
		return Resp{"ok": false, "code": "ram-not-allowlisted", "error": "Ce kit Corsair n’est pas autorisé par le profil stable EXDEV."}
	}
	if len(targets) < 1 || len(targets) > 4 {
		return Resp{"ok": false, "code": "bad-targets", "error": "Aucune barrette Corsair valide sélectionnée."}
	}
	h, err := openPawnIO()
	if err != nil {
		return Resp{"ok": false, "code": "pawnio-driver-required", "error": "Pilote SMBus EXDEV/PawnIO absent."}
	}
	defer procClose.Call(uintptr(h))
	if err := loadPawnModule(h); err != nil {
		return Resp{"ok": false, "code": "pawnio-module-required", "error": err.Error()}
	}
	configurePawnModule(h)
	var mods []corsairModule
	mods, err = discoverCorsairModules(h)
	if err != nil || len(mods) == 0 {
		msg := "Aucun contrôleur RGB Corsair Vengeance DDR5 validé sur le SMBus."
		if err != nil {
			msg = err.Error()
		}
		return Resp{"ok": false, "code": "ram-controller-not-found", "error": msg}
	}

	applied := []Resp{}
	failures := []Resp{}
	err = withSMBusMutex(func() error {
		for _, t := range targets {
			m, ok := findCorsairModule(mods, t.Port, t.Address)
			if !ok {
				failures = append(failures, Resp{"port": t.Port, "address": fmt.Sprintf("0x%02X", t.Address), "error": "route DIMM non validée pendant cette session"})
				continue
			}
			colors, e := fitCorsairLEDColors(t.Colors, m.LEDCount, brightness)
			if e != nil {
				failures = append(failures, Resp{"port": m.Port, "address": fmt.Sprintf("0x%02X", m.Address), "error": e.Error()})
				continue
			}
			var lastErr error
			strategy := ""
			for attempt := 1; attempt <= 2; attempt++ {
				old, e := selectPort(h, m.Port)
				if e == nil {
					strategy, e = writeCorsairDirectLEDs(h, m, colors)
				}
				if old >= 0 && old != m.Port {
					_, _ = selectPort(h, old)
				}
				if e == nil {
					lastErr = nil
					break
				}
				lastErr = e
				time.Sleep(time.Duration(20*attempt) * time.Millisecond)
			}
			if lastErr != nil {
				setCorsairDirectReady(m, false)
				failures = append(failures, Resp{"port": m.Port, "address": fmt.Sprintf("0x%02X", m.Address), "error": lastErr.Error()})
				continue
			}
			applied = append(applied, Resp{"port": m.Port, "address": fmt.Sprintf("0x%02X", m.Address), "ledCount": m.LEDCount, "strategy": strategy})
			// Keep writes serialized but do not add large sleeps: one direct packet per
			// DIMM is enough. A tiny gap avoids back-to-back mux switching edge cases.
			time.Sleep(4 * time.Millisecond)
		}
		return nil
	})
	if err != nil {
		return Resp{"ok": false, "code": "ram-zone-write-failed", "error": err.Error(), "applied": applied, "failures": failures}
	}
	return Resp{"ok": len(failures) == 0, "driver": "corsair-ddr5", "mode": "per-led-static", "applied": applied, "failures": failures, "fanLock": true}
}

func applyCorsair(part, color, brightness string) Resp {
	if !strings.EqualFold(strings.TrimSpace(part), "CMH32GX5M2B5200Z40") {
		return Resp{"ok": false, "code": "ram-not-allowlisted", "error": "Ce kit Corsair n’est pas autorisé par le profil stable EXDEV."}
	}
	if _, _, _, err := parseHexColor(color); err != nil {
		return Resp{"ok": false, "code": "bad-color", "error": err.Error()}
	}
	h, err := openPawnIO()
	if err != nil {
		return Resp{"ok": false, "code": "pawnio-driver-required", "error": "Pilote SMBus EXDEV/PawnIO absent. Relance EXDEV_RGB_INSTALLER.exe en administrateur."}
	}
	defer procClose.Call(uintptr(h))
	if err := loadPawnModule(h); err != nil {
		return Resp{"ok": false, "code": "pawnio-module-required", "error": err.Error()}
	}
	configurePawnModule(h)
	var mods []corsairModule
	mods, err = discoverCorsairModules(h)
	if err != nil {
		return Resp{"ok": false, "code": "smbus-detect-failed", "error": err.Error()}
	}
	if len(mods) == 0 {
		return Resp{"ok": false, "code": "ram-controller-not-found", "error": "Aucun contrôleur RGB Corsair Vengeance DDR5 validé sur le SMBus."}
	}

	applied := 0
	details := []Resp{}
	failures := []Resp{}
	err = withSMBusMutex(func() error {
		for _, m := range mods {
			colors, e := fitCorsairLEDColors([]string{color}, m.LEDCount, brightness)
			if e != nil {
				return e
			}
			var lastErr error
			strategy := ""
			for attempt := 1; attempt <= 2; attempt++ {
				old, e := selectPort(h, m.Port)
				if e == nil {
					strategy, e = writeCorsairDirectLEDs(h, m, colors)
				}
				if old >= 0 && old != m.Port {
					_, _ = selectPort(h, old)
				}
				if e == nil {
					lastErr = nil
					break
				}
				lastErr = e
				time.Sleep(time.Duration(20*attempt) * time.Millisecond)
			}
			if lastErr != nil {
				setCorsairDirectReady(m, false)
				failures = append(failures, Resp{"port": m.Port, "address": fmt.Sprintf("0x%02X", m.Address), "error": lastErr.Error()})
				continue
			}
			applied++
			details = append(details, Resp{"port": m.Port, "address": fmt.Sprintf("0x%02X", m.Address), "pid": fmt.Sprintf("%04X", m.PID), "protocol": m.Protocol, "firmware": m.Firmware, "strategy": strategy})
			time.Sleep(4 * time.Millisecond)
		}
		return nil
	})
	if err != nil {
		return Resp{"ok": false, "code": "ram-write-failed", "error": err.Error(), "modules": applied, "failures": failures}
	}
	if len(failures) > 0 {
		return Resp{"ok": false, "code": "ram-partial-write", "error": fmt.Sprintf("%d/%d module(s) Corsair mis à jour.", applied, len(mods)), "modules": applied, "details": details, "failures": failures, "fanLock": true}
	}
	return Resp{"ok": true, "driver": "corsair-ddr5", "modules": applied, "details": details, "color": strings.ToUpper(color), "brightness": brightness, "fanLock": true}
}

func pawnStatus() Resp {
	module := pawnModulePath()
	if _, err := os.Stat(module); err != nil {
		return Resp{"installed": false, "state": "module-missing", "module": module}
	}
	h, err := openPawnIO()
	if err != nil {
		return Resp{"installed": false, "state": "driver-missing", "module": module, "error": err.Error()}
	}
	procClose.Call(uintptr(h))
	// Do not load the PawnIO module during a status check. Loading is reserved
	// for an actual RAM operation and serialized by the elevated engine.
	return Resp{"installed": true, "state": "ready", "module": module}
}

func scanCorsairResponse(expected []int) Resp {
	h, err := openPawnIO()
	if err != nil {
		return Resp{"ok": false, "code": "pawnio-driver-required", "error": err.Error()}
	}
	defer procClose.Call(uintptr(h))
	if err := loadPawnModule(h); err != nil {
		return Resp{"ok": false, "code": "pawnio-module-required", "error": err.Error()}
	}
	configurePawnModule(h)
	var mods []corsairModule
	var diagnostics []corsairProbeDiagnostic
	mods, diagnostics, err = discoverCorsairModulesWithHints(h, expected)
	if err != nil {
		return Resp{"ok": false, "code": "smbus-detect-failed", "error": err.Error(), "modules": mods, "count": len(mods), "diagnostics": diagnostics}
	}
	return Resp{"ok": true, "modules": mods, "count": len(mods), "diagnostics": diagnostics, "expected": expected, "scan": "boot-safe-short-lock-multi-port-openrgb"}
}

var daemonMu sync.Mutex

type daemonRequest struct {
	Driver            string              `json:"driver"`
	Board             string              `json:"board"`
	Zone              string              `json:"zone"`
	Part              string              `json:"part"`
	Color             string              `json:"color"`
	Brightness        string              `json:"brightness"`
	Effect            string              `json:"effect"`
	ModulePort        int                 `json:"modulePort"`
	ModuleAddress     int                 `json:"moduleAddress"`
	Scoped            bool                `json:"scoped"`
	RAMTargets        []corsairZoneTarget `json:"ramTargets"`
    Pixels            []string            `json:"pixels"`
	ExpectedAddresses []int               `json:"expectedAddresses"`
}

func readToken(path string) string {
	b, err := os.ReadFile(path)
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(b))
}

func tokenOK(r *http.Request, token string) bool {
	got := r.Header.Get("X-EXDEV-Token")
	if token == "" || len(got) != len(token) {
		return false
	}
	return subtle.ConstantTimeCompare([]byte(got), []byte(token)) == 1
}

func serveEngine(opts map[string]string) {
	startedAt := time.Now()
	initialPawn := pawnStatus()
	port := opts["port"]
	if port == "" {
		port = "47651"
	}
	tokenFile := opts["token-file"]
	token := readToken(tokenFile)
	if token == "" {
		emit(Resp{"ok": false, "error": "token moteur EXDEV absent"})
		return
	}
	mux := http.NewServeMux()
	mux.HandleFunc("/v1/status", func(w http.ResponseWriter, r *http.Request) {
		if !tokenOK(r, token) {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		pawnOK := initialPawn["installed"] == true
		_ = json.NewEncoder(w).Encode(Resp{"ok": true, "version": "1.6.12", "engineReady": true, "uptimeMs": time.Since(startedAt).Milliseconds(), "fanLock": true, "writeEnabled": true, "drivers": Resp{"corsair-ddr5": Resp{"detected": true, "write": pawnOK, "state": initialPawn["state"]}, "gigabyte-rgbfusion2-usb": Resp{"detected": true, "write": true, "state": "ready-direct-held-persistent-engine"}, "gigabyte-aorus-rx9070xt-rgb": Resp{"detected": true, "write": true, "state": "static-global-safe; per-zone-gpu-disabled-by-default"}}, "pawnio": initialPawn, "gpuAccess": "rgb-only-allowlisted", "fanAccess": false, "pumpAccess": false})
	})
	mux.HandleFunc("/v1/scan-corsair", func(w http.ResponseWriter, r *http.Request) {
		if !tokenOK(r, token) {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		if r.Method != http.MethodGet && r.Method != http.MethodPost {
			http.Error(w, "method", http.StatusMethodNotAllowed)
			return
		}
		var expected []int
		if r.Method == http.MethodPost {
			body, _ := io.ReadAll(io.LimitReader(r.Body, 16*1024))
			var q daemonRequest
			if len(body) > 0 && json.Unmarshal(body, &q) == nil {
				expected = q.ExpectedAddresses
			}
		}
		daemonMu.Lock()
		out := scanCorsairResponse(expected)
		daemonMu.Unlock()
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(out)
	})
	mux.HandleFunc("/v1/apply", func(w http.ResponseWriter, r *http.Request) {
		if !tokenOK(r, token) {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		if r.Method != http.MethodPost {
			http.Error(w, "method", http.StatusMethodNotAllowed)
			return
		}
		daemonMu.Lock()
		defer daemonMu.Unlock()
		body, _ := io.ReadAll(io.LimitReader(r.Body, 64*1024))
		var q daemonRequest
		if json.Unmarshal(body, &q) != nil {
			http.Error(w, "bad json", http.StatusBadRequest)
			return
		}
		var out Resp
		switch strings.ToLower(q.Driver) {
		case "corsair-ddr5":
			out = applyCorsair(q.Part, q.Color, q.Brightness)
		case "gigabyte-rgbfusion2-usb":
			out = applyGigabyte(q.Board, q.Zone, q.Color, q.Brightness)
		case "gigabyte-aorus-rx9070xt-rgb":
			out = applyAorusGPU(q.Color, q.Brightness)
		default:
			out = Resp{"ok": false, "code": "driver-not-allowlisted", "error": "Pilote refusé par la liste blanche EXDEV."}
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(out)
	})
	// Per-DIMM / per-LED static RAM control. Routes are validated against the
	// current Corsair discovery cache, so callers cannot write arbitrary SMBus
	// addresses. One direct frame is emitted per DIMM; no animation timer here.
	mux.HandleFunc("/v1/ram-zones", func(w http.ResponseWriter, r *http.Request) {
		if !tokenOK(r, token) {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		if r.Method != http.MethodPost {
			http.Error(w, "method", http.StatusMethodNotAllowed)
			return
		}
		daemonMu.Lock()
		defer daemonMu.Unlock()
		body, _ := io.ReadAll(io.LimitReader(r.Body, 64*1024))
		var q daemonRequest
		if json.Unmarshal(body, &q) != nil {
			http.Error(w, "bad json", http.StatusBadRequest)
			return
		}
		out := applyCorsairZones(q.Part, q.RAMTargets, q.Brightness)
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(out)
	})

	mux.HandleFunc("/v1/cable-pixels",func(w http.ResponseWriter,r *http.Request){
    if !tokenOK(r,token){http.Error(w,"forbidden",http.StatusForbidden);return}
    if r.Method!=http.MethodPost{http.Error(w,"method",http.StatusMethodNotAllowed);return}
    body,e:=io.ReadAll(io.LimitReader(r.Body,16*1024))
    if e!=nil{http.Error(w,"bad request",http.StatusBadRequest);return}
    var q daemonRequest
    if json.Unmarshal(body,&q)!=nil || q.Driver!="gigabyte-rgbfusion2-usb" {
       http.Error(w,"invalid driver",http.StatusBadRequest);return
    }
    daemonMu.Lock()
    out:=applyGigabytePixels(q.Board,q.Zone,q.Pixels,q.Brightness)
    daemonMu.Unlock()
    w.Header().Set("Content-Type","application/json")
    _=json.NewEncoder(w).Encode(out)
 })
 mux.HandleFunc("/v1/effect", func(w http.ResponseWriter, r *http.Request) {
		if !tokenOK(r, token) {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		if r.Method != http.MethodPost {
			http.Error(w, "method", http.StatusMethodNotAllowed)
			return
		}
		daemonMu.Lock()
		defer daemonMu.Unlock()
		body, _ := io.ReadAll(io.LimitReader(r.Body, 64*1024))
		var q daemonRequest
		if json.Unmarshal(body, &q) != nil {
			http.Error(w, "bad json", http.StatusBadRequest)
			return
		}
		var out Resp
		switch strings.ToLower(q.Driver) {
		case "corsair-ddr5":
			out = applyCorsairEffectScoped(q.Part, q.Effect, q.Color, q.Brightness, q.ModulePort, q.ModuleAddress, q.Scoped)
		case "gigabyte-rgbfusion2-usb":
			out = applyGigabyteEffect(q.Board, q.Zone, q.Effect, q.Color, q.Brightness)
		default:
			out = Resp{"ok": false, "code": "effect-driver-not-supported", "error": "Effet matériel non disponible pour ce pilote."}
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(out)
	})

	// Hold passive ARGB strips in Direct mode. State is persisted in Lib\Native so
	// it survives one-shot fallback calls and Windows logon. Keep a persistent HID
	// handle and refresh at 10 Hz to win normal last-writer RGB races without busy looping.
	loadArgbHoldsFromDisk()
	go func() {
		t := time.NewTicker(50 * time.Millisecond)
		defer t.Stop()
		for range t.C {
			refreshHeldArgb()
		}
	}()

	ln, err := net.Listen("tcp", "127.0.0.1:"+port)
	if err != nil {
		emit(Resp{"ok": false, "error": err.Error()})
		return
	}
	server := &http.Server{Handler: mux, ReadHeaderTimeout: 3 * time.Second, IdleTimeout: 30 * time.Second}
	_ = server.Serve(ln)
}

func main() {
	args := os.Args[1:]
	cmd := "status"
	if len(args) > 0 {
		cmd = strings.ToLower(args[0])
	}
	opts := parseArgs(args[1:])
	switch cmd {
	case "serve":
		serveEngine(opts)
	case "status", "capabilities":
		ps := pawnStatus()
		emit(Resp{"ok": true, "name": "EXDEV Native Bridge", "version": "1.6.12", "safeMode": true, "writeEnabled": true, "drivers": Resp{"corsair-ddr5": Resp{"detected": true, "write": ps["installed"] == true, "state": ps["state"]}, "gigabyte-rgbfusion2-usb": Resp{"detected": true, "write": true, "state": "ready-direct-held-persistent-engine"}, "gigabyte-aorus-rx9070xt-rgb": Resp{"detected": true, "write": true, "state": "static-global-safe; per-zone-gpu-disabled-by-default"}}, "pawnio": ps, "fanLock": true, "gpuAccess": "rgb-only-allowlisted", "fanAccess": false, "pumpAccess": false})
	case "scan-corsair":
		var expected []int
		if raw := strings.TrimSpace(opts["expected"]); raw != "" {
			for _, part := range strings.Split(raw, ",") {
				if v, e := strconv.ParseInt(strings.TrimSpace(part), 0, 32); e == nil {
					expected = append(expected, int(v))
				}
			}
		}
		emit(scanCorsairResponse(expected))
	case "ram-zones":
		var targets []corsairZoneTarget
		if raw := opts["targets"]; raw != "" {
			if err := json.Unmarshal([]byte(raw), &targets); err != nil {
				emit(Resp{"ok": false, "code": "bad-targets-json", "error": "Configuration zones RAM invalide."})
				return
			}
		}
		emit(applyCorsairZones(opts["part"], targets, opts["brightness"]))
	case "effect":
		switch strings.ToLower(opts["driver"]) {
		case "corsair-ddr5":
			port, _ := strconv.Atoi(opts["module-port"])
			addr, _ := strconv.Atoi(opts["module-address"])
			scoped := opts["module-port"] != "" && opts["module-address"] != ""
			emit(applyCorsairEffectScoped(opts["part"], opts["effect"], opts["color"], opts["brightness"], port, addr, scoped))
		default:
			emit(Resp{"ok": false, "code": "effect-driver-not-supported", "error": "Effet matériel non disponible pour ce pilote."})
		}
	case "apply":
		switch strings.ToLower(opts["driver"]) {
		case "gigabyte-rgbfusion2-usb":
			emit(applyGigabyte(opts["board"], opts["zone"], opts["color"], opts["brightness"]))
		case "corsair-ddr5":
			emit(applyCorsair(opts["part"], opts["color"], opts["brightness"]))
		case "gigabyte-aorus-rx9070xt-rgb":
			emit(applyAorusGPU(opts["color"], opts["brightness"]))
		default:
			emit(Resp{"ok": false, "code": "driver-not-allowlisted", "error": "Pilote refusé par la liste blanche EXDEV."})
		}
	default:
		emit(Resp{"ok": false, "code": "unknown-command", "error": "Commande EXDEV Native Bridge inconnue."})
	}
}
