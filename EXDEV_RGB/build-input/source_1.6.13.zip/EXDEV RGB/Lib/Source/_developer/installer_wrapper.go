//go:build windows

package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"unsafe"
)

var (
	shell32           = syscall.NewLazyDLL("shell32.dll")
	user32            = syscall.NewLazyDLL("user32.dll")
	procIsUserAnAdmin = shell32.NewProc("IsUserAnAdmin")
	procShellExecuteW = shell32.NewProc("ShellExecuteW")
	procMessageBoxW   = user32.NewProc("MessageBoxW")
	// Injected by the Windows build script with -X main.expectedManifestSHA=<sha256>.
	expectedManifestSHA = ""
)

type securityManifest struct {
	Version string            `json:"version"`
	Files   map[string]string `json:"files"`
}

func wptr(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func message(text, title string, flags uintptr) {
	procMessageBoxW.Call(0, uintptr(unsafe.Pointer(wptr(text))), uintptr(unsafe.Pointer(wptr(title))), flags)
}
func isAdmin() bool {
	r, _, _ := procIsUserAnAdmin.Call()
	return r != 0
}
func quoteArg(s string) string {
	if s == "" {
		return `""`
	}
	if !strings.ContainsAny(s, " \t\"") {
		return s
	}
	return `"` + strings.ReplaceAll(s, `"`, `\"`) + `"`
}
func relaunchElevated(self string, args []string) error {
	params := make([]string, 0, len(args)+1)
	params = append(params, "/elevated")
	params = append(params, args...)
	quoted := make([]string, len(params))
	for i, a := range params {
		quoted[i] = quoteArg(a)
	}
	r, _, _ := procShellExecuteW.Call(
		0,
		uintptr(unsafe.Pointer(wptr("runas"))),
		uintptr(unsafe.Pointer(wptr(self))),
		uintptr(unsafe.Pointer(wptr(strings.Join(quoted, " ")))),
		uintptr(unsafe.Pointer(wptr(filepath.Dir(self)))),
		1,
	)
	if r <= 32 {
		return fmt.Errorf("ShellExecuteW=%d", r)
	}
	return nil
}

func sha256File(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return "", err
	}
	return strings.ToUpper(hex.EncodeToString(h.Sum(nil))), nil
}

func verifyPackage(root string) error {
	manifestPath := filepath.Join(root, "Lib", "security-manifest.json")
	if expectedManifestSHA == "" {
		return fmt.Errorf("empreinte de securite de l'installateur absente")
	}
	gotManifest, err := sha256File(manifestPath)
	if err != nil {
		return fmt.Errorf("manifest de securite introuvable: %w", err)
	}
	if !strings.EqualFold(gotManifest, expectedManifestSHA) {
		return fmt.Errorf("manifest de securite modifie (SHA256 invalide)")
	}
	raw, err := os.ReadFile(manifestPath)
	if err != nil {
		return err
	}
	var m securityManifest
	if err := json.Unmarshal(raw, &m); err != nil {
		return fmt.Errorf("manifest invalide: %w", err)
	}
	if len(m.Files) == 0 || len(m.Files) > 512 {
		return fmt.Errorf("manifest vide ou anormal")
	}
	rootClean := filepath.Clean(root) + string(os.PathSeparator)
	for rel, expected := range m.Files {
		cleanRel := filepath.Clean(filepath.FromSlash(rel))
		if filepath.IsAbs(cleanRel) || cleanRel == "." || strings.HasPrefix(cleanRel, ".."+string(os.PathSeparator)) || cleanRel == ".." {
			return fmt.Errorf("chemin interdit dans le manifest: %s", rel)
		}
		full := filepath.Clean(filepath.Join(root, cleanRel))
		if !strings.HasPrefix(strings.ToLower(full), strings.ToLower(rootClean)) {
			return fmt.Errorf("chemin hors package: %s", rel)
		}
		got, err := sha256File(full)
		if err != nil {
			return fmt.Errorf("fichier requis absent: %s", rel)
		}
		if !strings.EqualFold(got, expected) {
			return fmt.Errorf("integrite invalide: %s", rel)
		}
	}
	return nil
}

func main() {
	self, err := os.Executable()
	if err != nil {
		return
	}
	root := filepath.Dir(self)

	// Verify the exact package before elevation and again in the elevated process.
	// This prevents a modified PowerShell/source payload from being executed as admin.
	if err := verifyPackage(root); err != nil {
		message("Verification de securite EXDEV RGB impossible.\n\n"+err.Error()+"\n\nRe-extrayez l'archive officielle avant de relancer l'installation.", "EXDEV RGB - Integrite", 0x10)
		return
	}

	elevatedFlag := false
	autoStart := false
	passthrough := make([]string, 0, len(os.Args)-1)
	for _, a := range os.Args[1:] {
		if strings.EqualFold(a, "/elevated") {
			elevatedFlag = true
			continue
		}
		if strings.EqualFold(a, "/autoupdate") {
			autoStart = true
		}
		passthrough = append(passthrough, a)
	}

	// Installation/update/repair/uninstall is elevated once. The installed EXDEV RGB
	// UI remains a normal user process; only the allowlisted Native Engine is elevated.
	if !elevatedFlag && !isAdmin() {
		if err := relaunchElevated(self, passthrough); err != nil {
			message("L'elevation administrateur a ete annulee ou a echoue.\n\nEXDEV RGB n'a effectue aucune modification.", "EXDEV RGB", 0x10)
		}
		return
	}

	script := filepath.Join(root, "Lib", "Installer", "installer-ui.ps1")
	if _, err := os.Stat(script); err != nil {
		message("Le module d'installation est introuvable :\nLib\\Installer\\installer-ui.ps1\n\nRe-extrayez completement l'archive EXDEV RGB.", "EXDEV RGB", 0x10)
		return
	}

	mode := "install"
	for _, a := range passthrough {
		if strings.EqualFold(a, "/uninstall") {
			mode = "uninstall"
		}
		if strings.EqualFold(a, "/repair") {
			mode = "repair"
		}
		if strings.EqualFold(a, "/update") {
			mode = "update"
		}
	}
	args := []string{
		"-NoLogo", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-ExecutionPolicy", "Bypass", "-STA",
		"-File", script,
		"-PackageRoot", root,
		"-InstallerPath", self,
		"-Mode", mode,
	}
	if autoStart && mode == "update" {
		args = append(args, "-AutoStart")
	}
	cmd := exec.Command("powershell.exe", args...)
	cmd.Dir = root
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}

	logsDir := filepath.Join(root, "Lib", "Logs")
	_ = os.MkdirAll(logsDir, 0755)
	bootstrapLogPath := filepath.Join(logsDir, "installer-bootstrap.log")
	bootstrapLog, _ := os.OpenFile(bootstrapLogPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if bootstrapLog != nil {
		defer bootstrapLog.Close()
		fmt.Fprintln(bootstrapLog, "\n[EXDEV] bootstrap start")
		cmd.Stdout = bootstrapLog
		cmd.Stderr = bootstrapLog
	}

	if err := cmd.Run(); err != nil {
		if bootstrapLog != nil {
			fmt.Fprintln(bootstrapLog, "[EXDEV] bootstrap error:", err)
		}
		message("L'installateur EXDEV RGB s'est ferme avec une erreur.\n\nConsultez :\nLib\\Logs\\installer-bootstrap.log\n\nPuis Lib\\Logs\\installer-ui.log si celui-ci existe.", "EXDEV RGB - Erreur", 0x10)
	}
}
