package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"syscall"
	"unsafe"
)

var (
	user32      = syscall.NewLazyDLL("user32.dll")
	messageBoxW = user32.NewProc("MessageBoxW")
)

func wptr(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func msg(s string) {
	messageBoxW.Call(0, uintptr(unsafe.Pointer(wptr(s))), uintptr(unsafe.Pointer(wptr("EXDEV RGB"))), 0x10)
}
func main() {
	self, err := os.Executable()
	if err != nil {
		return
	}
	root := filepath.Dir(self)
	runtime := filepath.Join(root, "Lib", "AppRuntime", "EXDEV RGB.exe")
	if _, err := os.Stat(runtime); err != nil {
		msg("Le moteur EXDEV RGB est introuvable. Relancez EXDEV_RGB_INSTALLER.exe pour réparer l’installation.")
		return
	}
	cmd := exec.Command(runtime, os.Args[1:]...)
	cmd.Dir = root
	cmd.Env = append(os.Environ(), "EXDEV_RGB_ROOT="+root, "PORTABLE_EXECUTABLE_DIR="+root)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: false}
	if err := cmd.Start(); err != nil {
		msg("Impossible de lancer le moteur EXDEV RGB. Relancez l’installateur pour réparer l’application.")
	}
}
