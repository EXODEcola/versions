# EXDEV RGB 1.6.5 — SMBus Busy Recovery

- Corrige `DeviceIoControl 0xA1B22104: The requested resource is in use`.
- Cette erreur correspond au `STATUS_DEVICE_BUSY` du module PawnIO SmbusPIIX4 lorsque le contrôleur AMD SMBus est encore occupé.
- Les appels PawnIO `EXECUTE_FN` retentent uniquement `ERROR_BUSY` avec backoff borné.
- Les erreurs de protocole, CRC et périphérique absent ne sont jamais masquées ni retentées aveuglément.
- Le scan Corsair passe en priorité par le Native Engine résident.
- Scan, écritures zones RAM et effets RAM sont sérialisés par le même verrou du moteur pour supprimer les courses internes EXDEV.
- Le chemin Direct 10 LED + fallback WORD OpenRGB reste inchangé.
- FAN LOCK inchangé.
