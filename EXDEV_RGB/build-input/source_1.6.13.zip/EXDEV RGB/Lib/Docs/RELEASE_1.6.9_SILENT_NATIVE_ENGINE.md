# EXDEV RGB 1.6.9 — Silent Native Engine

## Native Engine
- `EXDEV_RGB_BRIDGE.exe` est compilé en sous-système Windows GUI/background (`-H=windowsgui`).
- La tâche planifiée `EXDEV RGB Native Engine` ne crée plus de fenêtre CMD au login Windows.
- Le moteur HTTP local 127.0.0.1:47651 reste inchangé.
- Les commandes one-shot du bridge restent compatibles avec les pipes stdout/stderr utilisés par Electron.

## Installation
- La préparation ne conserve plus stdout/stderr dans des pipes bloquants pendant `npm` / `electron-builder`.
- Les logs sont redirigés directement vers des fichiers temporaires puis fusionnés dans `Lib/Logs/installer.log`.
- Cela supprime le risque de deadlock lorsque la compilation atteint environ 91%.
- Le démarrage du moteur est borné et ne peut plus bloquer l'installation en attendant une console.

## Sécurité
- FAN LOCK inchangé.
- Aucun accès ventilateur, PWM ou pompe ajouté.
