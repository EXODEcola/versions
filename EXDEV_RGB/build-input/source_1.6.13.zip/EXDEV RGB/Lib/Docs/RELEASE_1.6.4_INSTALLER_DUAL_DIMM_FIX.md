# EXDEV RGB 1.6.4 — Installer + Dual-DIMM Fix

## Cause confirmée
Le package 1.6.3 contenait bien le bridge et le scanner multi-passes 1.6.3, mais `installer-ui.ps1` conservait un ancien `$AppVersion = 1.6.1`. Lors d’une mise à jour depuis 1.6.1, `Runtime-Current` concluait donc à tort que le runtime était déjà à jour et sautait sa reconstruction.

## Correctifs
- La version de l’installateur est désormais lue depuis `Lib/version.txt` : plus aucune version produit n’est codée en dur dans le script d’installation.
- Une différence entre le marqueur `Lib/AppRuntime/version.txt` et la version du package force la reconstruction du runtime.
- Le badge de l’installateur affiche la version réellement lue dans le package.
- `/autoupdate` est maintenant transmis à l’interface d’installation via `-AutoStart`.
- Le scanner Corsair multi-passes de la 1.6.3 est conservé : ports PIIX4 0/1, adresses 0x58–0x5F et 0x18–0x1F, retries lecture seule et pacing 10 ms.
- Le chemin Direct 10 LED + fallback WORD de la 1.6.2 est conservé.

## Sécurité
FAN LOCK inchangé. Aucun accès ventilateur, PWM ou pompe.
