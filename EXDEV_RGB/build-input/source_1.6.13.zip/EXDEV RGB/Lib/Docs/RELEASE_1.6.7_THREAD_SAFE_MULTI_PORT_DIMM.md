# EXDEV RGB 1.6.7 — Thread-Safe SMBus + Multi-Port Dual-DIMM Recovery

## Cause du verrou SMBus
Le mutex Windows `Global\Access_SMBUS.HTP.Method` est possédé par le thread qui l’acquiert. Une goroutine Go peut migrer entre threads Windows : sans épinglage, `WaitForSingleObject` pouvait réussir sur un thread et `ReleaseMutex` être exécuté sur un autre, laissant le verrou détenu par EXDEV lui-même.

## Correctifs SMBus
- `runtime.LockOSThread()` pendant toute la section critique SMBus.
- `WAIT_ABANDONED` accepté comme récupération sûre d’un propriétaire disparu.
- résultat de `ReleaseMutex` contrôlé au lieu d’être ignoré.
- attente bornée à 8 s pour une contention réelle, sans busy-loop.

## Dual DIMM AMD
- retour du scan OpenRGB-style sur PIIX4 **port 0 et port 1**.
- scan canonique `0x18..0x1F` puis aliases `0x58..0x5F`.
- déduplication canonique/alias sur un même port, mais conservation d’une même adresse sur deux ports différents.
- récupération ciblée des routes SMBIOS sur les deux ports.
- mapping d’affichage basé prioritairement sur le slot SMBIOS réellement associé.
- un DIMM présent mais RGB non validé reste visible dans la liste Éclairage en diagnostic, sans écriture.

## RGB
- Direct Corsair 10 LED conservé.
- 3 zones = 3 / 4 / 3 LED.
- fallback WORD OpenRGB conservé.
- FAN LOCK inchangé.
