# EXDEV RGB 1.6.6 — Slot-Aware Dual-DIMM Recovery

- Corrige la synchronisation SMBus inter-processus avec le mutex global `Global\Access_SMBUS.HTP.Method`.
- Utilise le chemin PawnIO `\\?\GLOBALROOT\Device\PawnIO` avec fallback historique.
- Active le sleep mode 2 du module SmbusPIIX4 comme OpenRGB/rgbctrl.
- Croise SMBIOS et contrôleurs RGB Corsair pour ne plus masquer un DIMM physique dont le contrôleur RGB ne répond pas.
- Pour le kit exact 2×16 Go sur la plateforme AM5 ciblée, A2/B2 sont utilisés comme indices de récupération lecture-seule : 0x19 / 0x1B.
- Chaque route candidate est validée par signature 0x43/0x44 puis Device Info + CRC + VID/PID + protocole avant toute écriture.
- Si le slot 2 reste absent, EXDEV affiche le DIMM physique avec la route attendue et la dernière erreur de diagnostic au lieu de le supprimer de l’interface.
- Direct 10 LED, 3 zones 3/4/3, dégradé et fallback WORD OpenRGB restent inchangés.
- FAN LOCK inchangé.
