# EXDEV RGB 1.6.2 — Corsair DDR5 Direct Hotfix

## Cause identifiée dans 1.6.1
Le chemin Per-DIMM passait d'abord le module Corsair en effet matériel Static via un commit de configuration, puis envoyait la trame Direct 10 LED. Cette séquence ne correspond pas au mode Direct d'OpenRGB et peut rendre le contrôleur temporairement indisponible sur le SMBus pendant le commit.

Le bridge 1.6.1 ne possédait pas non plus le fallback WORD_DATA utilisé par OpenRGB lorsque SMBUS_BLOCK_DATA est refusé par le contrôleur hôte.

## Correction 1.6.2
- aucun commit Static avant les trames Direct ;
- paquet Direct Vengeance DDR5 : LED count + 10 x RGB + CRC-8 = 32 octets ;
- essai SMBUS_BLOCK_DATA sur 0x31 ;
- fallback compatible OpenRGB en SMBUS_WORD_DATA (registres 0x90/0xA0...) ;
- sélection du port PIIX4 conservée par DIMM ;
- verrou Access_SMBUS.HTP.Method conservé ;
- diagnostic de route + stratégie d'écriture remonté jusqu'à l'UI ;
- FAN LOCK inchangé.
