# EXDEV RGB 1.6.3 — Dual-DIMM Scan Hotfix

## Correctif principal
- Corrige la détection intermittente d'une seule barrette Corsair Vengeance RGB DDR5 sur un kit 2-DIMM.
- `scan-corsair` utilise désormais la même découverte multi-passes que le chemin d'écriture.
- Trois tentatives de signature en lecture seule par route SMBus avant abandon.
- Deux tentatives maximum du bloc Device Info/CRC par route.
- Temporisation de 10 ms entre les adresses, alignée sur le détecteur Corsair DRAM d'OpenRGB.
- Jusqu'à cinq passes de découverte pour retrouver les deux DIMM avant d'exposer une topologie incomplète à l'interface.
- Cache physique conservé par clé `port + adresse + VID + PID` afin de ne jamais fusionner deux barrettes réelles.

## RGB RAM
- Le chemin Direct 10 LED de la 1.6.2 est conservé sans modification.
- SMBUS_BLOCK_DATA puis fallback WORD OpenRGB.
- Aucun commit Static préalable.
- Les modes Unie / 3 zones / Dégradé restent indépendants par barrette.

## Sécurité
- Détection supplémentaire = lectures SMBus uniquement.
- FAN LOCK inchangé.
- Aucun accès ventilateur, PWM ou pompe.
