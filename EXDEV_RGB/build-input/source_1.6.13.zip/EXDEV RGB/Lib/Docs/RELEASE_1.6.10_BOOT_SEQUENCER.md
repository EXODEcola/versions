# EXDEV RGB 1.6.10 — Boot Sequencer + Silent Native Engine

## Windows logon
- The renderer and startup lighting restore now share one native device scan instead of starting two SMBus scans.
- EXDEV waits for the elevated Native Engine HTTP listener to be ready before the first Corsair scan.
- The first Corsair scan is retried through the same resident engine when SMBIOS reports more DIMMs than the RGB scan has validated.
- No second PawnIO bridge is spawned merely because the scheduled engine is still starting.
- A one-shot fallback is used only after the bounded resident-engine startup window expires.

## Native Engine
- EXDEV_RGB_BRIDGE.exe remains a Windows GUI/background binary: no CMD window at logon.
- /v1/status exposes engineReady and uptimeMs so Electron can sequence startup deterministically.
- Status also exposes the resident driver capabilities, avoiding a separate capabilities process during boot.

## RAM
- Keeps the validated 1.6.8 dual-DIMM logic (P0/0x19 and P0/0x1B on the current machine).
- Keeps 10 LEDs per DIMM, 3-zone 3/4/3 layout and SMBus Block direct frames.
- Physical SMBIOS inventory remains independent of RGB readiness.

## Safety
- FAN LOCK unchanged.
- No fan, PWM, pump or NZXT control is added.
