param(
  [Parameter(Mandatory=$true)][string]$RootDir,
  [Parameter(Mandatory=$true)][string]$SourceDir,
  [Parameter(Mandatory=$true)][string]$LogFile,
  [switch]$SkipRuntime
)

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
$ErrorActionPreference = 'Stop'
$script:ExitCode = 1
$script:Stage = 0
$script:Proc = $null
$script:HardwareSummary = 'Initialisation materielle...'
$script:SkipRuntime = [bool]$SkipRuntime

New-Item -ItemType Directory -Force -Path (Split-Path -Parent $LogFile) | Out-Null

$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="EXDEV RGB - Préparation" Height="450" Width="760" WindowStartupLocation="CenterScreen" ResizeMode="NoResize" Background="#080D15" Foreground="#F4F8FF" ShowInTaskbar="True" FontFamily="Segoe UI">
  <Window.Resources><LinearGradientBrush x:Key="BrandBrush" StartPoint="0,0" EndPoint="1,0"><GradientStop Color="#7C3AED" Offset="0"/><GradientStop Color="#4F46E5" Offset="1"/></LinearGradientBrush></Window.Resources>
  <Grid Margin="30">
    <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
    <Grid><Grid.ColumnDefinitions><ColumnDefinition Width="62"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><Border Width="52" Height="52" CornerRadius="13" Background="#121A2A" BorderBrush="#5934C7" BorderThickness="1"><TextBlock Text="X" FontSize="28" FontWeight="Bold" HorizontalAlignment="Center" VerticalAlignment="Center" Foreground="#8B5CF6"/></Border><StackPanel Grid.Column="1" Margin="14,3,0,0"><TextBlock Text="Préparation de EXDEV RGB" FontSize="22" FontWeight="SemiBold"/><TextBlock Text="Native Lighting Engine · installation sécurisée" Margin="0,5,0,0" FontSize="12" Foreground="#9AA8BA"/></StackPanel><Border Grid.Column="2" Padding="10,5" CornerRadius="9" Background="#17142B" BorderBrush="#4D2EB4" BorderThickness="1" VerticalAlignment="Center"><TextBlock Text="FAN LOCK" Foreground="#A58BFA" FontWeight="Bold" FontSize="8"/></Border></Grid>
    <TextBlock Grid.Row="1" Name="StageText" Margin="0,30,0,9" FontSize="15" FontWeight="SemiBold" Text="Vérification des composants..."/>
    <ProgressBar Grid.Row="2" Name="Bar" Height="10" Minimum="0" Maximum="100" Value="5" Foreground="{StaticResource BrandBrush}" Background="#172335" BorderThickness="0"/>
    <Grid Grid.Row="3" Margin="0,9,0,0"><TextBlock Name="PercentText" Text="5%" FontSize="11" Foreground="#8D9CAF"/><TextBlock HorizontalAlignment="Right" Text="Ne fermez pas cette fenêtre" FontSize="10" Foreground="#8090A5"/></Grid>
    <Border Grid.Row="4" Margin="0,20,0,0" CornerRadius="12" Background="#0C141F" BorderBrush="#203047" BorderThickness="1" Padding="16,14"><Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/></Grid.RowDefinitions><TextBlock Name="InfoText" Text="EXDEV vérifie le pilote SMBus, le moteur Windows et les fichiers de l application." FontSize="12" Foreground="#A0ADBD" TextWrapping="Wrap"/><StackPanel Grid.Row="1" Orientation="Horizontal" Margin="0,16,0,0"><TextBlock Text="●  Pilotes" Foreground="#7D8CA0" FontSize="10" Margin="0,0,24,0"/><TextBlock Text="●  Moteur Native" Foreground="#7D8CA0" FontSize="10" Margin="0,0,24,0"/><TextBlock Text="●  Interface" Foreground="#7D8CA0" FontSize="9"/></StackPanel></Grid></Border>
  </Grid>
</Window>
"@

$reader = New-Object System.Xml.XmlNodeReader ([xml]$xaml)
$window = [Windows.Markup.XamlReader]::Load($reader)
try {
  $ico = Join-Path $RootDir 'Lib\Assets\EXDEV_RGB.ico'
  if(Test-Path $ico) { $window.Icon = [System.Windows.Media.Imaging.BitmapFrame]::Create([Uri]$ico) }
} catch {}
$stageText = $window.FindName('StageText')
$bar = $window.FindName('Bar')
$percentText = $window.FindName('PercentText')
$infoText = $window.FindName('InfoText')

function Set-Ui([int]$percent,[string]$stage,[string]$info) {
  $bar.Value = $percent
  $percentText.Text = "$percent%"
  $stageText.Text = $stage
  $infoText.Text = $info
}
function Escape-CmdArg([string]$value) { return '"' + ($value -replace '"','\"') + '"' }
function Start-LoggedProcess([string]$command,[string]$arguments,[string]$workingDirectory) {
  # Redirect directly to temporary files instead of keeping anonymous pipes open.
  # PowerShell 5.1 / .NET can deadlock if a verbose npm/electron-builder child fills
  # stdout or stderr before the UI thread reaches ReadToEnd(). File-backed logging
  # keeps the child fully asynchronous and prevents the installer freezing near 91%.
  $id = [guid]::NewGuid().ToString('N')
  $stdoutPath = Join-Path ([IO.Path]::GetTempPath()) ("EXDEV_RGB_" + $id + ".stdout.log")
  $stderrPath = Join-Path ([IO.Path]::GetTempPath()) ("EXDEV_RGB_" + $id + ".stderr.log")
  $p = Start-Process -FilePath $command -ArgumentList $arguments -WorkingDirectory $workingDirectory -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath
  $p | Add-Member -NotePropertyName EXDEVStdoutPath -NotePropertyValue $stdoutPath -Force
  $p | Add-Member -NotePropertyName EXDEVStderrPath -NotePropertyValue $stderrPath -Force
  return $p
}
function Finish-ProcessOutput($p) {
  $stdoutPath = [string]$p.EXDEVStdoutPath
  $stderrPath = [string]$p.EXDEVStderrPath
  try {
    if($stdoutPath -and (Test-Path -LiteralPath $stdoutPath)) {
      $stdout = Get-Content -LiteralPath $stdoutPath -Raw -ErrorAction SilentlyContinue
      if($stdout) { Add-Content -LiteralPath $LogFile -Value $stdout -Encoding UTF8 }
    }
    if($stderrPath -and (Test-Path -LiteralPath $stderrPath)) {
      $stderr = Get-Content -LiteralPath $stderrPath -Raw -ErrorAction SilentlyContinue
      if($stderr) { Add-Content -LiteralPath $LogFile -Value $stderr -Encoding UTF8 }
    }
  } finally {
    if($stdoutPath) { Remove-Item -LiteralPath $stdoutPath -Force -ErrorAction SilentlyContinue }
    if($stderrPath) { Remove-Item -LiteralPath $stderrPath -Force -ErrorAction SilentlyContinue }
  }
  return $p.ExitCode
}
function Start-HardwareStage {
  Set-Ui 8 'Etape 1/4 - Pilote materiel' 'Verification du transport SMBus EXDEV. Une demande UAC Windows peut apparaitre si PawnIO doit etre installe.'
  $script:Stage = 1
  $hardware = Join-Path $RootDir 'Lib\Installer\ensure-hardware.ps1'
  $args = '-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File ' + (Escape-CmdArg $hardware) + ' -RootDir ' + (Escape-CmdArg $RootDir) + ' -LogFile ' + (Escape-CmdArg $LogFile)
  $script:Proc = Start-LoggedProcess 'powershell.exe' $args $RootDir
}
function Start-NpmStage {
  # Clean stale build output with retries because antivirus/Explorer may briefly hold a file.
  for($i=0;$i -lt 6;$i++) {
    try { if(Test-Path (Join-Path $SourceDir 'dist')) { Remove-Item (Join-Path $SourceDir 'dist') -Recurse -Force -ErrorAction Stop }; break }
    catch { Start-Sleep -Milliseconds 600 }
  }
  Set-Ui 35 'Etape 2/4 - Dependances' 'Installation des composants Electron necessaires au moteur EXDEV RGB.'
  $script:Stage = 2
  $script:Proc = Start-LoggedProcess 'cmd.exe' '/D /S /C "npm install --no-audit --no-fund"' $SourceDir
}
function Start-BuildStage {
  Set-Ui 62 'Etape 3/4 - Compilation' 'Creation du moteur Windows EXDEV RGB avec le logo et les composants de la version Stable.'
  $script:Stage = 3
  $script:Proc = Start-LoggedProcess 'cmd.exe' '/D /S /C "npm run build:portable"' $SourceDir
}

Start-HardwareStage
$timer = New-Object Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(430)
$timer.Add_Tick({
  if($script:Proc -and -not $script:Proc.HasExited) {
    if($script:Stage -eq 1 -and $bar.Value -lt 28) { $bar.Value += 1 }
    elseif($script:Stage -eq 2 -and $bar.Value -lt 56) { $bar.Value += 1 }
    elseif($script:Stage -eq 3 -and $bar.Value -lt 91) { $bar.Value += 1 }
    $percentText.Text = "$([int]$bar.Value)%"
    return
  }
  if(-not $script:Proc) { return }
  $code = Finish-ProcessOutput $script:Proc
  $script:Proc = $null
  if($code -ne 0) {
    $timer.Stop(); Set-Ui 100 'Echec de la preparation' 'Consultez Lib\Logs\installer.log pour le detail de l erreur.'
    $bar.Foreground = '#FF6877'; $script:ExitCode = $code; Start-Sleep -Milliseconds 1000; $window.Close(); return
  }

  if($script:Stage -eq 1) {
    $statusPath = Join-Path $RootDir 'Lib\Native\hardware-status.json'
    try {
      $hs = Get-Content -LiteralPath $statusPath -Raw -Encoding UTF8 | ConvertFrom-Json
      if($hs.ready) { $script:HardwareSummary = 'Pilote SMBus pret - module AMD PIIX4 valide.' }
      elseif($hs.rebootRequired) { $script:HardwareSummary = 'Pilote installe - redemarrage Windows requis avant le controle de la RAM.' }
      elseif($hs.error) { $script:HardwareSummary = 'Pilote SMBus non pret : ' + $hs.error }
      else { $script:HardwareSummary = 'Pilote SMBus a verifier depuis Reglages > Reparer.' }
    } catch { $script:HardwareSummary = 'Etat du pilote SMBus non disponible.' }
    if($script:SkipRuntime) {
      Set-Ui 94 'Etape 4/4 - Finalisation' $script:HardwareSummary
      $script:Stage = 4; $script:ExitCode = 0; $timer.Stop(); Start-Sleep -Milliseconds 900; $window.Close(); return
    }
    Start-NpmStage; return
  }
  if($script:Stage -eq 2) { Start-BuildStage; return }
  if($script:Stage -eq 3) {
    Set-Ui 96 'Etape 4/4 - Finalisation' $script:HardwareSummary
    $script:Stage = 4; $script:ExitCode = 0; $timer.Stop(); Start-Sleep -Milliseconds 900; $window.Close(); return
  }
})
$timer.Start()
[void]$window.ShowDialog()
exit $script:ExitCode
