param(
  [Parameter(Mandatory=$true)][string]$PackageRoot,
  [Parameter(Mandatory=$true)][string]$InstallerPath,
  [ValidateSet('install','update','repair','uninstall')][string]$Mode = 'install',
  [switch]$AutoStart,
  [switch]$ScanOnly,
  [string]$ScanOutput,
  [string]$ScanStatus
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$VersionFile = Join-Path $PackageRoot 'Lib\version.txt'
try {
  $AppVersion = (Get-Content -LiteralPath $VersionFile -Raw -Encoding UTF8).Trim()
} catch {
  throw 'Version du package EXDEV RGB introuvable (Lib\version.txt).'
}
if($AppVersion -notmatch '^\d+\.\d+\.\d+$') { throw "Version EXDEV RGB invalide : $AppVersion" }
$AppName = 'EXDEV RGB'
$UninstallKey = 'Software\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB'

function Write-ScanStatus([int]$Percent,[string]$Text) {
  if($ScanStatus) {
    try {
      $safe=[Math]::Max(0,[Math]::Min(100,$Percent))
      [IO.File]::WriteAllText($ScanStatus,("{0}|{1}" -f $safe,$Text),[Text.UTF8Encoding]::new($false))
    } catch {}
  }
}
function Read-Version([string]$Root) {
  foreach($p in @((Join-Path $Root 'Lib\installed-version.txt'),(Join-Path $Root 'Lib\version.txt'),(Join-Path $Root 'Lib\AppRuntime\version.txt'))) {
    try { if(Test-Path -LiteralPath $p) { $v=(Get-Content -LiteralPath $p -Raw -Encoding UTF8).Trim(); if($v){return $v} } } catch {}
  }
  return 'inconnue'
}
function Test-InstallRoot([string]$Root) {
  if([string]::IsNullOrWhiteSpace($Root)) { return $false }
  try { $Root=[IO.Path]::GetFullPath($Root) } catch { return $false }
  return ((Test-Path -LiteralPath (Join-Path $Root 'Lib')) -and ((Test-Path -LiteralPath (Join-Path $Root 'EXDEV RGB.exe')) -or (Test-Path -LiteralPath (Join-Path $Root 'Lib\installed-version.txt'))))
}
function Add-Install([System.Collections.Generic.List[object]]$List,[hashtable]$Seen,[string]$Root,[string]$Source) {
  if(-not (Test-InstallRoot $Root)) { return }
  try { $full=[IO.Path]::GetFullPath($Root).TrimEnd('\') } catch { return }
  try {
    $pkg=[IO.Path]::GetFullPath($PackageRoot).TrimEnd('\')
    if($full -ieq $pkg -and -not (Test-Path -LiteralPath (Join-Path $full 'EXDEV RGB.exe'))) { return }
  } catch {}
  $key=$full.ToLowerInvariant()
  if($Seen.ContainsKey($key)) { return }
  $Seen[$key]=$true
  $List.Add([pscustomobject]@{ path=$full; version=(Read-Version $full); source=$Source }) | Out-Null
}
function Add-ExeCandidate([System.Collections.Generic.List[object]]$List,[hashtable]$Seen,[string]$Exe,[string]$Source) {
  if([string]::IsNullOrWhiteSpace($Exe)) { return }
  try {
    if(Test-Path -LiteralPath $Exe) { Add-Install $List $Seen (Split-Path -LiteralPath $Exe -Parent) $Source }
  } catch {}
}
function Get-RegistryInstallRoots {
  $result=New-Object System.Collections.Generic.List[object]
  foreach($path in @(
    'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB',
    'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB',
    'Registry::HKEY_LOCAL_MACHINE\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB'
  )) {
    try {
      $v=(Get-ItemProperty -LiteralPath $path -Name InstallLocation -ErrorAction Stop).InstallLocation
      if($v){$result.Add([pscustomobject]@{path=[string]$v;source='registre'})|Out-Null}
    } catch {}
  }
  foreach($path in @('HKLM:\Software\EXDEV\EXDEV RGB','HKCU:\Software\EXDEV\EXDEV RGB')) {
    try {
      $v=(Get-ItemProperty -LiteralPath $path -Name InstallLocation -ErrorAction Stop).InstallLocation
      if($v){$result.Add([pscustomobject]@{path=[string]$v;source='exdev-registry'})|Out-Null}
    } catch {}
  }
  foreach($path in @(
    'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\App Paths\EXDEV RGB.exe',
    'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\App Paths\EXDEV RGB.exe'
  )) {
    try {
      $item=Get-Item -LiteralPath $path -ErrorAction Stop
      $exe=[string]$item.GetValue('')
      if($exe){$result.Add([pscustomobject]@{path=(Split-Path -LiteralPath $exe -Parent);source='app-path'})|Out-Null}
    } catch {}
  }
  return $result
}
function Get-FixedDrives {
  $drives=New-Object System.Collections.Generic.List[string]
  foreach($d in [IO.DriveInfo]::GetDrives()) {
    try { if($d.IsReady -and $d.DriveType -eq [IO.DriveType]::Fixed) { $drives.Add($d.RootDirectory.FullName)|Out-Null } } catch {}
  }
  return $drives
}
function Get-RunningInstallRoots {
  $result=New-Object System.Collections.Generic.List[object]
  try {
    foreach($p in @(Get-Process -Name 'EXDEV RGB' -ErrorAction SilentlyContinue)) {
      try {
        $exe=$p.Path
        if($exe -and ([IO.Path]::GetFileName($exe) -ieq 'EXDEV RGB.exe')) {
          $result.Add([pscustomobject]@{path=(Split-Path -LiteralPath $exe -Parent);source='processus'})|Out-Null
        }
      } catch {}
    }
  } catch {}
  return $result
}
function Get-UninstallDisplayNameRoots {
  $result=New-Object System.Collections.Generic.List[object]
  foreach($base in @(
    'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Uninstall',
    'Registry::HKEY_LOCAL_MACHINE\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall',
    'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Uninstall'
  )) {
    try {
      foreach($key in (Get-ChildItem -LiteralPath $base -ErrorAction Stop)) {
        try {
          $item=Get-ItemProperty -LiteralPath $key.PSPath -ErrorAction Stop
          $name=[string]$item.DisplayName
          if($name -and ($name -ieq 'EXDEV RGB' -or $name -like 'EXDEV RGB *')) {
            $loc=[string]$item.InstallLocation
            if($loc){$result.Add([pscustomobject]@{path=$loc;source='registre-nom'})|Out-Null}
          }
        } catch {}
      }
    } catch {}
  }
  return $result
}
function Add-CurrentUserLegacyCandidates([System.Collections.Generic.List[object]]$List,[hashtable]$Seen) {
  $profile=[Environment]::GetFolderPath('UserProfile')
  if(-not $profile){return}
  foreach($rel in @('Downloads\EXDEV RGB','Desktop\EXDEV RGB','Documents\EXDEV RGB','AppData\Local\Programs\EXDEV RGB')) {
    Add-Install $List $Seen (Join-Path $profile $rel) 'profil-courant'
  }
  foreach($baseRel in @('Downloads','Desktop')) {
    $base=Join-Path $profile $baseRel
    if(-not (Test-Path -LiteralPath $base)){continue}
    $count=0
    try {
      foreach($child in [IO.Directory]::EnumerateDirectories($base)) {
        $count++; if($count -gt 1500){break}
        $name=[IO.Path]::GetFileName($child)
        if($name -ieq 'EXDEV RGB'){Add-Install $List $Seen $child 'profil-courant';continue}
        if($name -like 'EXDEV_RGB*' -or $name -like 'EXDEV RGB*') {
          Add-Install $List $Seen (Join-Path $child 'EXDEV RGB') 'profil-courant'
        }
      }
    } catch {}
  }
}
function Get-ShortcutTargets {
  $targets=New-Object System.Collections.Generic.List[string]
  try {
    $ws=New-Object -ComObject WScript.Shell
    $roots=@(
      [Environment]::GetFolderPath('Desktop'),
      [Environment]::GetFolderPath('CommonDesktopDirectory'),
      [Environment]::GetFolderPath('Programs'),
      [Environment]::GetFolderPath('CommonPrograms')
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
    foreach($root in $roots) {
      foreach($candidate in @((Join-Path $root 'EXDEV RGB.lnk'),(Join-Path $root 'EXDEV RGB\EXDEV RGB.lnk'))) {
        try { if(Test-Path -LiteralPath $candidate){$t=$ws.CreateShortcut($candidate).TargetPath;if($t){$targets.Add($t)|Out-Null}} } catch {}
      }
    }
  } catch {}
  return $targets
}
function Add-LegacyProfileCandidates([System.Collections.Generic.List[object]]$List,[hashtable]$Seen,[string]$UsersRoot) {
  if(-not (Test-Path -LiteralPath $UsersRoot)){return}
  try {
    foreach($u in [IO.Directory]::EnumerateDirectories($UsersRoot)) {
      foreach($rel in @('Desktop\EXDEV RGB','Downloads\EXDEV RGB','Documents\EXDEV RGB','AppData\Local\Programs\EXDEV RGB')) {
        Add-Install $List $Seen (Join-Path $u $rel) 'profil-legacy'
      }
      foreach($baseRel in @('Desktop','Downloads','Documents')) {
        $base=Join-Path $u $baseRel
        if(-not (Test-Path -LiteralPath $base)){continue}
        try {
          foreach($child in [IO.Directory]::EnumerateDirectories($base)) {
            $name=[IO.Path]::GetFileName($child)
            if($name -ieq 'EXDEV RGB'){Add-Install $List $seen $child 'profil-legacy';continue}
            if($name -like 'EXDEV_RGB*' -or $name -like 'EXDEV RGB*' -or $name -like '*EXDEV*RGB*') {
              Add-Install $List $Seen (Join-Path $child 'EXDEV RGB') 'profil-legacy'
            }
          }
        } catch {}
      }
    }
  } catch {}
}
function Find-EXDEVInstallations {
  $list=New-Object System.Collections.Generic.List[object]
  $seen=@{}

  Write-ScanStatus 8 'Registre EXDEV RGB...'
  foreach($r in (Get-RegistryInstallRoots)) { Add-Install $list $seen $r.path $r.source }

  Write-ScanStatus 25 'Raccourcis EXDEV RGB...'
  foreach($exe in (Get-ShortcutTargets)) { Add-ExeCandidate $list $seen $exe 'raccourci' }

  $drives=Get-FixedDrives
  Write-ScanStatus 45 'Emplacements standards...'
  foreach($drive in $drives) {
    foreach($rel in @('EXDEV RGB','Program Files\EXDEV RGB','Program Files (x86)\EXDEV RGB','Apps\EXDEV RGB','Applications\EXDEV RGB','Games\EXDEV RGB')) {
      Add-Install $list $seen (Join-Path $drive $rel) 'emplacement-standard'
    }
  }

  Write-ScanStatus 68 'Anciennes versions EXDEV RGB...'
  foreach($drive in $drives) { Add-LegacyProfileCandidates $list $seen (Join-Path $drive 'Users') }

  Write-ScanStatus 88 'Validation des installations trouvées...'
  $sorted=@($list | Sort-Object @{Expression={
    switch -Regex ($_.source) {
      '^exdev-registry$' {0;break}
      '^registre$' {1;break}
      '^app-path$' {2;break}
      '^raccourci$' {3;break}
      '^emplacement-standard$' {4;break}
      default {5}
    }
  }}, @{Expression={ try {[version]$_.version}catch{[version]'0.0.0'} };Descending=$true}, path)
  if($sorted.Count -gt 0){Write-ScanStatus 100 "$($sorted.Count) installation(s) trouvée(s)"}else{Write-ScanStatus 100 'Aucune installation trouvée'}
  return $sorted
}

if($ScanOnly) {
  try {
    $items=Find-EXDEVInstallations
    $json=@($items) | ConvertTo-Json -Depth 4
    if($ScanOutput) { [IO.File]::WriteAllText($ScanOutput,$json,[Text.UTF8Encoding]::new($false)) }
    exit 0
  } catch {
    if($ScanOutput) { [IO.File]::WriteAllText($ScanOutput,'[]',[Text.UTF8Encoding]::new($false)) }
    Write-ScanStatus 100 ('Erreur de recherche : ' + $_.Exception.Message)
    exit 1
  }
}

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Windows.Forms

$logDir=Join-Path $PackageRoot 'Lib\Logs'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$uiLog=Join-Path $logDir 'installer-ui.log'
function Log([string]$Text) { Add-Content -LiteralPath $uiLog -Value (('[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Text)) -Encoding UTF8 }

function Q([string]$s) { return '"' + ($s -replace '"','\"') + '"' }
function Default-InstallPath {
  # EXDEV RGB ships as a native x64 application. Prefer the native Program Files
  # directory for fresh installs. Existing installations keep their registered
  # path, including legacy Program Files (x86) locations, during an update.
  $pf=[Environment]::GetFolderPath('ProgramFiles')
  if([string]::IsNullOrWhiteSpace($pf)) { $pf=[Environment]::GetFolderPath('ProgramFilesX86') }
  return (Join-Path $pf 'EXDEV RGB')
}
function Compare-V([string]$A,[string]$B) {
  try{$aV=[version]$A}catch{$aV=[version]'0.0.0'}; try{$bV=[version]$B}catch{$bV=[version]'0.0.0'}
  return $aV.CompareTo($bV)
}
function Copy-Tree([string]$Source,[string]$Destination) {
  New-Item -ItemType Directory -Force -Path $Destination | Out-Null
  & (Join-Path $env:SystemRoot 'System32\robocopy.exe') $Source $Destination /E /R:2 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null
  $rc=$LASTEXITCODE
  if($rc -ge 8){throw "Robocopy a retourne le code $rc."}
}
function Stop-EXDEV {
  try{Stop-Process -Name 'EXDEV RGB' -Force -ErrorAction SilentlyContinue}catch{}
  try{Stop-Process -Name 'EXDEV_RGB_BRIDGE' -Force -ErrorAction SilentlyContinue}catch{}
  Start-Sleep -Milliseconds 350
}
function Create-Shortcuts([string]$Root) {
  $app=Join-Path $Root 'EXDEV RGB.exe'; $ico=Join-Path $Root 'Lib\Assets\EXDEV_RGB.ico'
  $ws=New-Object -ComObject WScript.Shell
  # Only update desktop shortcuts which the user has chosen to keep.
  $desktop=[Environment]::GetFolderPath('Desktop'); $lnk=Join-Path $desktop 'EXDEV RGB.lnk'
  if(Test-Path -LiteralPath $lnk) {
    $s=$ws.CreateShortcut($lnk)
    $s.TargetPath=$app; $s.WorkingDirectory=$Root
    $s.IconLocation="$ico,0"; $s.Description='EXDEV RGB Studio'; $s.Save()
  }
  # Start-menu shortcut is managed by the application installer.
  $programs=[Environment]::GetFolderPath('Programs'); $dir=Join-Path $programs 'EXDEV RGB'
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  $sml=Join-Path $dir 'EXDEV RGB.lnk'
  $s2=$ws.CreateShortcut($sml)
  $s2.TargetPath=$app; $s2.WorkingDirectory=$Root
  $s2.IconLocation="$ico,0"; $s2.Description='EXDEV RGB Studio'; $s2.Save()
  try{Start-Process ie4uinit.exe -ArgumentList '-show' -WindowStyle Hidden}catch{}
}
function Write-UninstallRegistry([string]$Root) {
  $key='HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB'
  New-Item -Path $key -Force | Out-Null
  $installer=Join-Path $Root 'EXDEV_RGB_INSTALLER.exe'; $icon=Join-Path $Root 'Lib\Assets\EXDEV_RGB.ico'
  New-ItemProperty -Path $key -Name DisplayName -Value 'EXDEV RGB' -PropertyType String -Force|Out-Null
  New-ItemProperty -Path $key -Name DisplayVersion -Value $AppVersion -PropertyType String -Force|Out-Null
  New-ItemProperty -Path $key -Name Publisher -Value 'EXDEV' -PropertyType String -Force|Out-Null
  New-ItemProperty -Path $key -Name InstallLocation -Value $Root -PropertyType String -Force|Out-Null
  New-ItemProperty -Path $key -Name DisplayIcon -Value $icon -PropertyType String -Force|Out-Null
  New-ItemProperty -Path $key -Name UninstallString -Value ('"'+$installer+'" /uninstall') -PropertyType String -Force|Out-Null
  New-ItemProperty -Path $key -Name ModifyPath -Value ('"'+$installer+'" /repair') -PropertyType String -Force|Out-Null
  New-ItemProperty -Path $key -Name NoRepair -Value 0 -PropertyType DWord -Force|Out-Null
  # Fast EXDEV-specific lookup for future updates.
  $exdevKey='HKLM:\Software\EXDEV\EXDEV RGB';New-Item -Path $exdevKey -Force|Out-Null
  New-ItemProperty -Path $exdevKey -Name InstallLocation -Value $Root -PropertyType String -Force|Out-Null
  New-ItemProperty -Path $exdevKey -Name Version -Value $AppVersion -PropertyType String -Force|Out-Null
  $appPath='HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\EXDEV RGB.exe';New-Item -Path $appPath -Force|Out-Null
  Set-Item -Path $appPath -Value (Join-Path $Root 'EXDEV RGB.exe') -Force
  New-ItemProperty -Path $appPath -Name Path -Value $Root -PropertyType String -Force|Out-Null
  # Clean the old per-user registration so Windows only exposes one installation.
  Remove-Item -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB' -Recurse -Force -ErrorAction SilentlyContinue
}
function Get-RealExeVersion([string]$Exe) {
  if(-not (Test-Path -LiteralPath $Exe -PathType Leaf)){return ''}
  try {
    $info=(Get-Item -LiteralPath $Exe -ErrorAction Stop).VersionInfo
    $product=[string]$info.ProductVersion
    if($product -match '^(\d+\.\d+\.\d+)') {return $Matches[1]}
    $file=[string]$info.FileVersion
    if($file -match '^(\d+\.\d+\.\d+)') {return $Matches[1]}
  } catch {}
  return ''
}
function Assert-ExpectedRuntime([string]$Exe) {
  $actual=Get-RealExeVersion $Exe
  if($actual -ne $AppVersion) {
    throw "L'executable Windows $Exe porte la version '$actual' au lieu de $AppVersion. Le registre Windows ne sera PAS mis a jour."
  }
}
function Runtime-Current([string]$Root) {
  $exe=Join-Path $Root 'Lib\AppRuntime\EXDEV RGB.exe'
  $v=Join-Path $Root 'Lib\AppRuntime\version.txt'
  if(-not (Test-Path -LiteralPath $exe -PathType Leaf)){return $false}
  if(-not (Test-Path -LiteralPath $v -PathType Leaf)){return $false}
  try {
    if((Get-Content -LiteralPath $v -Raw -Encoding UTF8).Trim() -ne $AppVersion){return $false}
    return (Get-RealExeVersion $exe) -eq $AppVersion
  } catch {return $false}
}
function Prepare-Runtime([string]$Root,[bool]$SkipRuntime) {
  $script=Join-Path $Root 'Lib\Installer\prepare-runtime.ps1';$source=Join-Path $Root 'Lib\Source';$log=Join-Path $Root 'Lib\Logs\installer.log'
  if(-not (Test-Path -LiteralPath $script)){throw 'prepare-runtime.ps1 introuvable dans Lib\Installer.'}
  New-Item -ItemType Directory -Force -Path (Split-Path $log -Parent)|Out-Null
  $argLine='-NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -STA -File ' + (Q $script) + ' -RootDir ' + (Q $Root) + ' -SourceDir ' + (Q $source) + ' -LogFile ' + (Q $log)
  if($SkipRuntime){$argLine+=' -SkipRuntime'}
  $p=Start-Process -FilePath 'powershell.exe' -ArgumentList $argLine -WindowStyle Hidden -Wait -PassThru
  if($p.ExitCode -ne 0){throw "La preparation du moteur a echoue (code $($p.ExitCode)). Consultez Lib\Logs\installer.log."}
  if(-not $SkipRuntime) {
    $built=Join-Path $source 'dist\EXDEV RGB.exe'; if(-not (Test-Path -LiteralPath $built)){throw 'EXDEV RGB.exe compile introuvable.'}
    $rt=Join-Path $Root 'Lib\AppRuntime';New-Item -ItemType Directory -Force -Path $rt|Out-Null
    Assert-ExpectedRuntime $built
    Copy-Item -LiteralPath $built -Destination (Join-Path $rt 'EXDEV RGB.exe') -Force
    [IO.File]::WriteAllText((Join-Path $rt 'version.txt'),$AppVersion+"`r`n",[Text.UTF8Encoding]::new($false))
  }
}
# A real, versioned rollback snapshot is written BEFORE the new package overwrites files.
# The snapshot contains a matched Electron PE, runtime, native bridge and prior installer.
# Users' AppData profiles are not overwritten and the original FAN LOCK task is untouched.
function Save-VerifiedRollback([string]$ExistingRoot,[string]$TargetRoot) {
  $oldApp=Join-Path $ExistingRoot 'EXDEV RGB.exe'
  $currentVersion=Get-RealExeVersion $oldApp
  if($currentVersion -notmatch '^\d+\.\d+\.\d+$' -or (Compare-V $currentVersion $AppVersion) -ge 0) {
    Log "Rollback snapshot skipped: real old PE version=$currentVersion candidate=$AppVersion"
    return
  }
  $currentParts=$currentVersion.Split('.')
  $newParts=$AppVersion.Split('.')
  if($currentParts[0] -ne $newParts[0] -or $currentParts[1] -ne $newParts[1]) {
    Log 'Rollback snapshot skipped: version family changed; settings compatibility not guaranteed.'
    return
  }
  $paths=@{
    rootExe='EXDEV RGB.exe'
    appRuntime='Lib\AppRuntime\EXDEV RGB.exe'
    nativeBridge='Lib\Native\EXDEV_RGB_BRIDGE.exe'
    installer='EXDEV_RGB_INSTALLER.exe'
    versionMarker='Lib\version.txt'
    sourcePackage='Lib\Source\package.json'
    sourceMain='Lib\Source\main.js'
    sourceRenderer='Lib\Source\renderer\app.js'
    sourcePreload='Lib\Source\preload.js'
    installerUi='Lib\Installer\installer-ui.ps1'
    prepareRuntime='Lib\Installer\prepare-runtime.ps1'
    hardwarePrep='Lib\Installer\ensure-hardware.ps1'
  }
  foreach($key in $paths.Keys) {
    if(-not (Test-Path -LiteralPath (Join-Path $ExistingRoot $paths[$key]) -PathType Leaf)) {
      Log "Rollback snapshot skipped: missing old component $key"
      return
    }
  }
  $rollbackDir=Join-Path $TargetRoot 'Lib\Rollback'
  New-Item -ItemType Directory -Path $rollbackDir -Force | Out-Null
  $pending=Join-Path $rollbackDir ('pending-'+[guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $pending -ErrorAction Stop | Out-Null
  try {
    $hashes=@{}
    foreach($key in $paths.Keys){
      $src=Join-Path $ExistingRoot $paths[$key]
      $dst=Join-Path $pending $paths[$key]
      New-Item -ItemType Directory -Path (Split-Path -Parent $dst) -Force | Out-Null
      Copy-Item -LiteralPath $src -Destination $dst -Force -ErrorAction Stop
      $sourceHash=(Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash
      $destHash=(Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash
      if($sourceHash -ne $destHash){throw "Rollback copy/hash mismatch for $key"}
      $hashes[$key]=$destHash
    }
    if((Get-RealExeVersion (Join-Path $pending $paths.rootExe)) -ne $currentVersion){throw 'Rollback old runtime version is invalid'}
    $record=[ordered]@{schema=1;version=$currentVersion;createdUtc=[DateTime]::UtcNow.ToString('o');files=$hashes;settingsSchema=1}
    [IO.File]::WriteAllText((Join-Path $pending 'snapshot.json'),($record|ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($false))
    $previous=Join-Path $rollbackDir 'previous'
    $previousOld=Join-Path $rollbackDir 'previous-old'
    if(Test-Path -LiteralPath $previousOld){Remove-Item -LiteralPath $previousOld -Force -Recurse}
    if(Test-Path -LiteralPath $previous){Move-Item -LiteralPath $previous -Destination $previousOld -ErrorAction Stop}
    try {Move-Item -LiteralPath $pending -Destination $previous -ErrorAction Stop} catch {
      if(Test-Path -LiteralPath $previousOld){Move-Item -LiteralPath $previousOld -Destination $previous -ErrorAction SilentlyContinue}
      throw
    }
    if(Test-Path -LiteralPath $previousOld){Remove-Item -LiteralPath $previousOld -Force -Recurse}
    Log "Verified rollback snapshot: version=$currentVersion hash-complete=$($hashes.Count)"
  } catch {
    Log "Rollback snapshot failed safely: $($_.Exception.Message)"
    throw
  } finally {
    if(Test-Path -LiteralPath $pending){Remove-Item -LiteralPath $pending -Recurse -Force -ErrorAction SilentlyContinue}
  }
}

function Finalize-Install([string]$Root) {
  $runtime=Join-Path $Root 'Lib\AppRuntime\EXDEV RGB.exe'; if(-not (Test-Path -LiteralPath $runtime)){throw 'Moteur EXDEV RGB absent apres preparation.'}
  Assert-ExpectedRuntime $runtime
  Stop-EXDEV
  Copy-Item -LiteralPath $runtime -Destination (Join-Path $Root 'EXDEV RGB.exe') -Force
  Assert-ExpectedRuntime (Join-Path $Root 'EXDEV RGB.exe')
  $installedInstaller=Join-Path $Root 'EXDEV_RGB_INSTALLER.exe'
  if([IO.Path]::GetFullPath($InstallerPath) -ine [IO.Path]::GetFullPath($installedInstaller)) {Copy-Item -LiteralPath $InstallerPath -Destination $installedInstaller -Force}
  [IO.File]::WriteAllText((Join-Path $Root 'Lib\installed-version.txt'),$AppVersion+"`r`n",[Text.UTF8Encoding]::new($false))
  Create-Shortcuts $Root
  Write-UninstallRegistry $Root
}
function Remove-Installation([string]$Root) {
  Stop-EXDEV
  try{schtasks.exe /Delete /TN 'EXDEV RGB Native Engine' /F | Out-Null}catch{}
  $desktop=Join-Path ([Environment]::GetFolderPath('Desktop')) 'EXDEV RGB.lnk';Remove-Item -LiteralPath $desktop -Force -ErrorAction SilentlyContinue
  $menu=Join-Path ([Environment]::GetFolderPath('Programs')) 'EXDEV RGB';Remove-Item -LiteralPath $menu -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB' -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB' -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath 'HKLM:\Software\EXDEV\EXDEV RGB' -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath 'HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\EXDEV RGB.exe' -Recurse -Force -ErrorAction SilentlyContinue
  # Remove after this PowerShell process exits so locked installer/script files can disappear too.
  $cmd=Join-Path $env:TEMP ('exdev_rgb_cleanup_'+[guid]::NewGuid().ToString('N')+'.cmd')
  $body="@echo off`r`ntimeout /t 2 /nobreak >nul`r`nrmdir /s /q `"$Root`"`r`ndel /q `"%~f0`"`r`n"
  [IO.File]::WriteAllText($cmd,$body,[Text.Encoding]::ASCII)
  Start-Process -FilePath 'cmd.exe' -ArgumentList '/c',('"'+$cmd+'"') -WindowStyle Hidden
}

$xaml=@"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="EXDEV RGB - Installation" Width="980" Height="620" WindowStartupLocation="CenterScreen" ResizeMode="NoResize" Background="#080D15" Foreground="#F4F8FF" FontFamily="Segoe UI">
  <Window.Resources>
    <LinearGradientBrush x:Key="BrandBrush" StartPoint="0,0" EndPoint="1,0"><GradientStop Color="#7C3AED" Offset="0"/><GradientStop Color="#4F46E5" Offset="1"/></LinearGradientBrush>
    <Style x:Key="ExdevButton" TargetType="Button">
      <Setter Property="FontFamily" Value="Segoe UI"/><Setter Property="BorderThickness" Value="1"/><Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button"><Border x:Name="Bd" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="9"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Bd" Property="Opacity" Value="0.94"/></Trigger><Trigger Property="IsPressed" Value="True"><Setter TargetName="Bd" Property="Opacity" Value="0.82"/></Trigger><Trigger Property="IsEnabled" Value="False"><Setter TargetName="Bd" Property="Opacity" Value="0.38"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter>
    </Style>
  </Window.Resources>
  <Grid>
    <Grid.ColumnDefinitions><ColumnDefinition Width="310"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
    <Border Grid.Column="0" Background="#0A101B" BorderBrush="#1A2739" BorderThickness="0,0,1,0">
      <Grid Margin="28">
        <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <StackPanel Orientation="Horizontal"><Border Width="52" Height="52" CornerRadius="13" Background="#121A2A" BorderBrush="#5530C9" BorderThickness="1"><Image Name="LogoImage" Width="42" Height="42" Stretch="Uniform"/></Border><StackPanel Margin="12,4,0,0"><TextBlock Text="EXDEV" FontSize="20" FontWeight="Bold"/><TextBlock Text="RGB" FontSize="15" FontWeight="Bold" Foreground="#8B5CF6" Margin="0,1,0,0"/></StackPanel></StackPanel>
        <StackPanel Grid.Row="1" VerticalAlignment="Center">
          <Border Height="172" CornerRadius="18" BorderBrush="#293A52" BorderThickness="1" Background="#0D1623" Padding="20">
            <StackPanel VerticalAlignment="Center"><TextBlock Text="X" FontSize="70" FontWeight="Bold" Foreground="#7C3AED" HorizontalAlignment="Center"/><TextBlock Text="EXDEV RGB" FontSize="21" FontWeight="SemiBold" HorizontalAlignment="Center" Margin="0,8,0,0"/><TextBlock Text="Éclairage. Performance. Contrôle." FontSize="10" Foreground="#8492A7" HorizontalAlignment="Center" Margin="0,7,0,0"/></StackPanel>
          </Border>
          <StackPanel Margin="0,24,0,0"><TextBlock Text="✓  Détection matérielle sécurisée" Foreground="#AEB9C8" FontSize="10" Margin="0,0,0,10"/><TextBlock Text="✓  FAN LOCK permanent" Foreground="#AEB9C8" FontSize="10" Margin="0,0,0,10"/><TextBlock Text="✓  Profils et réglages conservés" Foreground="#AEB9C8" FontSize="10"/></StackPanel>
        </StackPanel>
        <TextBlock Grid.Row="2" Name="BrandTag" Text="EXDEV Native Lighting Engine" FontSize="9" Foreground="#5F6E82"/>
      </Grid>
    </Border>

    <Grid Grid.Column="1" Margin="34,28,34,28">
      <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
      <Grid Grid.Row="0"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel><TextBlock Name="HeaderTitle" Text="Bienvenue dans EXDEV RGB" FontSize="28" FontWeight="Bold"/><TextBlock Name="HeaderSubtitle" Text="Préparation de l'installation et vérification de votre système." FontSize="11" Foreground="#8E9BAD" Margin="0,7,0,0"/></StackPanel><Border Grid.Column="1" Padding="11,6" CornerRadius="10" Background="#17142B" BorderBrush="#4D2EB4" BorderThickness="1" VerticalAlignment="Top"><TextBlock Text="v$AppVersion" Foreground="#A58BFA" FontWeight="SemiBold" FontSize="10"/></Border></Grid>
      <Border Grid.Row="1" Margin="0,22,0,0" CornerRadius="12" Padding="15" Background="#0D1622" BorderBrush="#22334A" BorderThickness="1"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel><TextBlock Name="DetectTitle" Text="Recherche d'une installation existante..." FontWeight="SemiBold" FontSize="12"/><TextBlock Name="DetectDetail" Text="EXDEV RGB vérifie Windows, les raccourcis et les emplacements connus." Foreground="#7F90A8" FontSize="9" Margin="0,5,0,0" TextWrapping="Wrap"/></StackPanel><Border Grid.Column="1" Name="DetectBadge" CornerRadius="9" Padding="10,5" Background="#171F31" BorderBrush="#2A3A52" BorderThickness="1"><TextBlock Name="DetectBadgeText" Text="ANALYSE" FontSize="8" Foreground="#9CB0CB" FontWeight="Bold"/></Border></Grid></Border>
      <Grid Grid.Row="2" Margin="0,16,0,0"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="110"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="Emplacement d'installation" FontSize="10" FontWeight="SemiBold"/><TextBox Name="PathBox" Height="39" Margin="0,7,10,0" Padding="11,8" Background="#0A121C" Foreground="#EAF2FF" BorderBrush="#2A3A52" BorderThickness="1" FontSize="10"/></StackPanel><Button Grid.Column="1" Name="BrowseButton" Style="{StaticResource ExdevButton}" Height="39" Margin="0,24,0,0" Content="Parcourir" Background="#131E2D" Foreground="#E7EDF5" BorderBrush="#30445F"/></Grid>
      <StackPanel Grid.Row="3" Margin="0,17,0,0"><Grid><TextBlock Name="StageText" Text="Préparation" FontWeight="SemiBold" FontSize="10"/><TextBlock Name="StatusText" HorizontalAlignment="Right" Text="Recherche..." Foreground="#748398" FontSize="9"/></Grid><ProgressBar Name="Progress" Height="9" Margin="0,9,0,0" Minimum="0" Maximum="100" Value="0" Foreground="{StaticResource BrandBrush}" Background="#172235" BorderThickness="0"/><TextBlock Name="ProgressText" Text="0%" Foreground="#7D8CA0" FontSize="9" Margin="0,6,0,0"/></StackPanel>
      <Border Grid.Row="4" Margin="0,17,0,0" CornerRadius="12" Padding="15" Background="#0A111B" BorderBrush="#1C2A3C" BorderThickness="1"><TextBlock Name="InfoText" Text="L'installateur vérifie les anciennes versions avant de proposer l'installation." Foreground="#8494AA" FontSize="9" TextWrapping="Wrap" VerticalAlignment="Top"/></Border>
      <Grid Grid.Row="5" Margin="0,18,0,0"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="140"/><ColumnDefinition Width="205"/></Grid.ColumnDefinitions><Button Name="CancelButton" Style="{StaticResource ExdevButton}" Grid.Column="1" Height="43" Margin="0,0,10,0" Content="Annuler" Background="#101925" Foreground="#CFDAE8" BorderBrush="#2A3B50"/><Button Name="InstallButton" Style="{StaticResource ExdevButton}" Grid.Column="2" Height="43" Content="Continuer" IsEnabled="False" Background="{StaticResource BrandBrush}" Foreground="White" BorderBrush="#8B5CF6" FontWeight="SemiBold"/></Grid>
    </Grid>
  </Grid>
</Window>
"@
$reader=New-Object System.Xml.XmlNodeReader ([xml]$xaml)
$window=[Windows.Markup.XamlReader]::Load($reader)
try{$ico=Join-Path $PackageRoot 'Lib\Assets\EXDEV_RGB.ico';if(Test-Path $ico){$window.Icon=[System.Windows.Media.Imaging.BitmapFrame]::Create([Uri]$ico)}}catch{}
$DetectTitle=$window.FindName('DetectTitle');$DetectDetail=$window.FindName('DetectDetail');$DetectBadge=$window.FindName('DetectBadge');$DetectBadgeText=$window.FindName('DetectBadgeText')
$LogoImage=$window.FindName('LogoImage');try{$logoPath=Join-Path $PackageRoot 'Lib\Assets\EXDEV_RGB.ico';if(Test-Path $logoPath){$LogoImage.Source=[System.Windows.Media.Imaging.BitmapFrame]::Create([Uri]$logoPath)}}catch{}
$HeaderTitle=$window.FindName('HeaderTitle');$HeaderSubtitle=$window.FindName('HeaderSubtitle');$BrandTag=$window.FindName('BrandTag');
$PathBox=$window.FindName('PathBox');$BrowseButton=$window.FindName('BrowseButton');$Progress=$window.FindName('Progress');$ProgressText=$window.FindName('ProgressText');$StageText=$window.FindName('StageText');$StatusText=$window.FindName('StatusText');$InfoText=$window.FindName('InfoText');$InstallButton=$window.FindName('InstallButton');$CancelButton=$window.FindName('CancelButton')
$script:Found=@();$script:OldRoot='';$script:OldVersion='';$script:Busy=$false
$PathBox.Text=Default-InstallPath
if($Mode -eq 'uninstall'){$HeaderTitle.Text='Désinstaller EXDEV RGB';$HeaderSubtitle.Text='Suppression propre de l application et de ses composants Windows.';$BrandTag.Text='Désinstallation sécurisée'}elseif($Mode -eq 'repair'){$HeaderTitle.Text='Réparer EXDEV RGB';$HeaderSubtitle.Text='Vérification et reconstruction de l installation actuelle.';$BrandTag.Text='Maintenance EXDEV RGB'}elseif($Mode -eq 'update'){$HeaderTitle.Text='Mettre à jour EXDEV RGB';$HeaderSubtitle.Text='Détection de la version actuelle avant installation de la nouvelle version.';$BrandTag.Text='Mise à jour EXDEV RGB'}
function Set-Progress([int]$P,[string]$Stage,[string]$Status,[string]$Info) {$Progress.IsIndeterminate=$false;$Progress.Value=$P;$ProgressText.Text="$P%";$StageText.Text=$Stage;$StatusText.Text=$Status;if($Info){$InfoText.Text=$Info};[System.Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke([action]{},'Background')}
function Apply-Detected([object[]]$items) {
  $script:Found=@($items)
  if($script:Found.Count -gt 0) {
    $best=$script:Found[0];$script:OldRoot=[string]$best.path;$script:OldVersion=[string]$best.version;$bestSource=[string]$best.source
    $DetectTitle.Text="EXDEV RGB $($script:OldVersion) détecté"
    if($Mode -eq 'uninstall'){$DetectBadgeText.Text='INSTALLÉ';$DetectBadge.Background='#321724'}elseif($Mode -eq 'repair'){$DetectBadgeText.Text='RÉPARATION';$DetectBadge.Background='#1D1740'}else{$DetectBadgeText.Text='MISE À JOUR';$DetectBadge.Background='#1D1740'}
    $registeredSource=($bestSource -in @('registre','exdev-registry','app-path'))
    $portableHint = (-not $registeredSource)
    if($portableHint) {
      $PathBox.Text=Default-InstallPath
      $DetectDetail.Text="Ancienne installation trouvée ($bestSource) : $($script:OldRoot)`nL'installation existante sera conservée à son emplacement pour une mise à jour sûre. Vous pouvez choisir un autre dossier si nécessaire."
    } else {
      $PathBox.Text=$script:OldRoot
      $DetectDetail.Text="Installation Windows trouvée ($bestSource) : $($script:OldRoot)`nLa mise à jour sera effectuée ici, sauf si vous choisissez un autre dossier."
    }
    $cmp=Compare-V $script:OldVersion $AppVersion
    if($Mode -eq 'uninstall'){$HeaderTitle.Text='Désinstaller EXDEV RGB';$HeaderSubtitle.Text="Version $($script:OldVersion) détectée dans Windows."}
    elseif($Mode -eq 'repair' -or $cmp -eq 0){$HeaderTitle.Text='EXDEV RGB est déjà installé';$HeaderSubtitle.Text="Version $($script:OldVersion) détectée · vous pouvez réparer les composants."}
    elseif($cmp -lt 0){$HeaderTitle.Text='Une nouvelle version est disponible';$HeaderSubtitle.Text="EXDEV RGB $($script:OldVersion) → $AppVersion · vos réglages seront conservés."}
    else{$HeaderTitle.Text='Installation EXDEV RGB';$HeaderSubtitle.Text="La version détectée sera remplacée par EXDEV RGB $AppVersion."}
    if($Mode -eq 'repair' -or $cmp -eq 0){$InstallButton.Content='Réparer EXDEV RGB'}elseif($cmp -lt 0){$InstallButton.Content="Mettre à jour vers $AppVersion"}else{$InstallButton.Content="Installer $AppVersion"}
    $InfoText.Text="Recherche optimisée : registre EXDEV, App Paths, raccourcis et dossiers EXDEV RGB connus. Aucun scan récursif complet des disques. Les réglages AppData sont conservés."
  } else {
    $DetectTitle.Text='Aucune installation existante détectée';$DetectDetail.Text='Nouvelle installation. Vous pouvez choisir le dossier de destination.';$DetectBadgeText.Text='NOUVELLE';$DetectBadge.Background='#1D1740';$PathBox.Text=Default-InstallPath;$InstallButton.Content="Installer EXDEV RGB $AppVersion";$InfoText.Text='Emplacement recommandé : Program Files\EXDEV RGB. Vous pouvez le modifier avec Parcourir.'
    if($Mode -ne 'uninstall'){$HeaderTitle.Text='Bienvenue dans EXDEV RGB';$HeaderSubtitle.Text='Première installation · choisissez votre emplacement puis lancez l installation.'}else{$HeaderTitle.Text='EXDEV RGB n est pas installé';$HeaderSubtitle.Text='Aucune installation Windows à supprimer.';$InstallButton.IsEnabled=$false}
  }
  $Progress.IsIndeterminate=$false;$Progress.Value=100;$ProgressText.Text='100%';$StageText.Text='Recherche terminée';$StatusText.Text='Prêt';$InstallButton.IsEnabled=($Mode -ne 'uninstall' -or $script:Found.Count -gt 0)
}

$BrowseButton.Add_Click({
  if($script:Busy){return}
  $dlg=New-Object System.Windows.Forms.FolderBrowserDialog;$dlg.Description='Choisissez le dossier parent où installer EXDEV RGB';$dlg.ShowNewFolderButton=$true
  try{$current=$PathBox.Text;if(Test-Path $current){$dlg.SelectedPath=$current}else{$dlg.SelectedPath=(Split-Path $current -Parent)}}catch{}
  if($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){$sel=$dlg.SelectedPath;if([IO.Path]::GetFileName($sel) -ine 'EXDEV RGB'){$sel=Join-Path $sel 'EXDEV RGB'};$PathBox.Text=$sel}
})
$CancelButton.Add_Click({if(-not $script:Busy){$window.Close()}})

$InstallButton.Add_Click({
  if($script:Busy){return};$script:Busy=$true;$InstallButton.IsEnabled=$false;$BrowseButton.IsEnabled=$false;$CancelButton.IsEnabled=$false
  try {
    $target=$PathBox.Text.Trim();if([string]::IsNullOrWhiteSpace($target)){throw 'Choisissez un dossier d installation.'};$target=[IO.Path]::GetFullPath($target).TrimEnd('\')
    if($Mode -eq 'uninstall') {
      if([string]::IsNullOrWhiteSpace($script:OldRoot)){throw 'Aucune installation EXDEV RGB à désinstaller.'}
      $ans=[System.Windows.MessageBox]::Show("Désinstaller EXDEV RGB de :`n$($script:OldRoot) ?`n`nLes paramètres utilisateur AppData sont conservés.",'EXDEV RGB',[System.Windows.MessageBoxButton]::YesNo,[System.Windows.MessageBoxImage]::Question)
      if($ans -ne [System.Windows.MessageBoxResult]::Yes){$script:Busy=$false;$window.Close();return}
      Set-Progress 25 'Désinstallation' 'Arrêt des services...' 'Suppression des raccourcis, de la tâche Native Engine et de l installation.'
      Remove-Installation $script:OldRoot;Set-Progress 100 'Terminé' 'EXDEV RGB désinstallé' 'La suppression du dossier se termine en arrière-plan.';[System.Windows.MessageBox]::Show('EXDEV RGB a été désinstallé.','EXDEV RGB')|Out-Null;$window.Close();return
    }

    Log "Start $Mode old=$($script:OldVersion) oldRoot=$($script:OldRoot) target=$target package=$PackageRoot"
    Set-Progress 8 'Préparation' 'Arrêt de l ancienne version...' 'EXDEV RGB prépare une installation propre sans supprimer vos réglages utilisateur.'
    Stop-EXDEV
    New-Item -ItemType Directory -Force -Path $target|Out-Null
    if($script:OldRoot -and (Test-Path -LiteralPath (Join-Path $script:OldRoot 'EXDEV RGB.exe'))) {
      Save-VerifiedRollback $script:OldRoot $target
    }
    Set-Progress 18 'Fichiers' 'Copie de Lib...' 'Copie de la nouvelle version dans le dossier choisi.'
    if([IO.Path]::GetFullPath($PackageRoot).TrimEnd('\') -ine $target) { Copy-Tree (Join-Path $PackageRoot 'Lib') (Join-Path $target 'Lib') }
    $installedInstaller=Join-Path $target 'EXDEV_RGB_INSTALLER.exe'
    if([IO.Path]::GetFullPath($InstallerPath) -ine [IO.Path]::GetFullPath($installedInstaller)) {Copy-Item -LiteralPath $InstallerPath -Destination $installedInstaller -Force}

    Set-Progress 28 'Moteur EXDEV' 'Pilote SMBus et moteur Windows...' 'Une fenêtre de progression détaillée va maintenant vérifier le pilote, le Native Bridge et compiler le moteur Windows si nécessaire.'
    $skip=Runtime-Current $target
    if(-not $skip){Log "Compiling fresh runtime: on-disk EXE marker/version mismatch or runtime missing."}
    $window.Hide()
    try { Prepare-Runtime $target $skip } finally { $window.Show();$window.Activate() }
    Set-Progress 88 'Finalisation' 'Création de l application et des raccourcis...' 'Enregistrement de EXDEV RGB dans Windows et vérification de la version installée.'
    Finalize-Install $target
    # On success, remove only known stale EXDEV application startup entries.
    # Keep the native engine task, drivers and all user settings intact.
    $runKey='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
    try {
      $entries=Get-ItemProperty -LiteralPath $runKey -ErrorAction Stop
      foreach($r in @(
        @{Name='electron.app.Electron';Marker='EXDEV_RGB_Native_v0.2'},
        @{Name='electron.app.EXDEV RGB Companion';Marker='EXDEV RGB Companion\EXDEV RGB Companion.exe'}
      )) {
        $v=$entries.PSObject.Properties[$r.Name]
        if($v -and ([string]$v.Value).IndexOf($r.Marker,[StringComparison]::OrdinalIgnoreCase) -ge 0) {
          Remove-ItemProperty -LiteralPath $runKey -Name $r.Name -ErrorAction Stop
          Log "Retired known legacy startup: $($r.Name)"
        }
      }
    } catch { Log "Legacy shortcut cleanup skipped: $($_.Exception.Message)" }
    # Remove obsolete intermediate Electron bundles, never touch AppData or valid rollback.
    try { $obsoleteDist=Join-Path $target 'Lib\Source\dist'; if(Test-Path -LiteralPath $obsoleteDist){Remove-Item -LiteralPath $obsoleteDist -Recurse -Force -ErrorAction Stop} } catch { Log "Obsolete build cache cleanup skipped: $($_.Exception.Message)" }

    # If a portable/old install was migrated elsewhere, detach the obsolete executable and mark the migration.
    if($script:OldRoot -and ([IO.Path]::GetFullPath($script:OldRoot).TrimEnd('\') -ine $target) -and ([IO.Path]::GetFullPath($script:OldRoot).TrimEnd('\') -ine [IO.Path]::GetFullPath($PackageRoot).TrimEnd('\'))) {
      try{Remove-Item -LiteralPath (Join-Path $script:OldRoot 'EXDEV RGB.exe') -Force -ErrorAction SilentlyContinue;[IO.File]::WriteAllText((Join-Path $script:OldRoot 'MIGRATED_TO.txt'),$target,[Text.UTF8Encoding]::new($false))}catch{}
    }
    Set-Progress 100 'Terminé' "EXDEV RGB $AppVersion installé" "Installation : $target`nLa prochaine mise à jour retrouvera cette installation via Windows, même si le ZIP est sur un autre disque."
    Start-Sleep -Milliseconds 450
    $app=Join-Path $target 'EXDEV RGB.exe';if(Test-Path $app){Start-Process -FilePath $app -WorkingDirectory $target}
    Start-Sleep -Milliseconds 650
    $window.Close()
  } catch {
    Log ('ERROR '+$_.Exception.ToString());$Progress.IsIndeterminate=$false;$Progress.Value=100;$Progress.Foreground='#FF6475';$StageText.Text='Échec';$StatusText.Text='Erreur';$InfoText.Text=$_.Exception.Message
    $InstallButton.Content='Réessayer'
    $script:Busy=$false;$InstallButton.IsEnabled=$true;$BrowseButton.IsEnabled=$true;$CancelButton.IsEnabled=$true
  }
})

$window.Add_ContentRendered({
  $Progress.IsIndeterminate=$false;$Progress.Value=5;$ProgressText.Text='5%';$StageText.Text='Recherche rapide';$StatusText.Text='Initialisation...';$InfoText.Text='Recherche EXDEV RGB par Windows, registre, raccourcis et emplacements connus. Aucun scan complet des disques.'

  # FIX4: no nested PowerShell process. The previous helper process could remain at 5% on some systems.
  # Scan is split into tiny deterministic phases executed by the UI dispatcher.
  $script:ScanList=New-Object System.Collections.Generic.List[object]
  $script:ScanSeen=@{}
  $script:ScanPhase=0
  $script:ScanDrives=@()

  $script:ScanTimer=New-Object System.Windows.Threading.DispatcherTimer
  $script:ScanTimer.Interval=[TimeSpan]::FromMilliseconds(90)
  $script:ScanTimer.Add_Tick({
    try {
      switch($script:ScanPhase) {
        0 {
          $Progress.Value=12;$ProgressText.Text='12%';$StatusText.Text='Application en cours...';$DetectDetail.Text='Recherche d une instance EXDEV RGB déjà lancée.'
          foreach($r in (Get-RunningInstallRoots)){Add-Install $script:ScanList $script:ScanSeen $r.path $r.source}
          $script:ScanPhase=1;break
        }
        1 {
          $Progress.Value=30;$ProgressText.Text='30%';$StatusText.Text='Registre Windows...';$DetectDetail.Text='Recherche EXDEV RGB dans le registre et les applications installées.'
          foreach($r in (Get-RegistryInstallRoots)){Add-Install $script:ScanList $script:ScanSeen $r.path $r.source}
          foreach($r in (Get-UninstallDisplayNameRoots)){Add-Install $script:ScanList $script:ScanSeen $r.path $r.source}
          $script:ScanPhase=2;break
        }
        2 {
          $Progress.Value=52;$ProgressText.Text='52%';$StatusText.Text='Raccourcis...';$DetectDetail.Text='Vérification du Bureau et du menu Démarrer.'
          foreach($exe in (Get-ShortcutTargets)){Add-ExeCandidate $script:ScanList $script:ScanSeen $exe 'raccourci'}
          $script:ScanPhase=3;break
        }
        3 {
          $Progress.Value=72;$ProgressText.Text='72%';$StatusText.Text='Dossiers standards...';$DetectDetail.Text='Vérification des emplacements EXDEV RGB connus sur les disques locaux.'
          $script:ScanDrives=@(Get-FixedDrives)
          foreach($drive in $script:ScanDrives) {
            foreach($rel in @('EXDEV RGB','Program Files\EXDEV RGB','Program Files (x86)\EXDEV RGB','Apps\EXDEV RGB','Applications\EXDEV RGB','Games\EXDEV RGB')) {
              Add-Install $script:ScanList $script:ScanSeen (Join-Path $drive $rel) 'emplacement-standard'
            }
          }
          $script:ScanPhase=4;break
        }
        4 {
          $Progress.Value=88;$ProgressText.Text='88%';$StatusText.Text='Anciennes versions...';$DetectDetail.Text='Vérification rapide du profil Windows courant uniquement.'
          Add-CurrentUserLegacyCandidates $script:ScanList $script:ScanSeen
          $script:ScanPhase=5;break
        }
        default {
          $script:ScanTimer.Stop()
          $items=@($script:ScanList | Sort-Object @{Expression={
            switch -Regex ($_.source) {
              '^processus$' {0;break}
              '^exdev-registry$' {1;break}
              '^registre$' {2;break}
              '^registre-nom$' {3;break}
              '^app-path$' {4;break}
              '^raccourci$' {5;break}
              '^emplacement-standard$' {6;break}
              default {7}
            }
          }}, @{Expression={ try {[version]$_.version}catch{[version]'0.0.0'} };Descending=$true}, path)
          $Progress.Value=100;$ProgressText.Text='100%';$StatusText.Text='Recherche terminée';$DetectDetail.Text=if($items.Count -gt 0){"$($items.Count) installation(s) trouvée(s)."}else{'Aucune installation existante trouvée.'}
          Apply-Detected $items
          if($Mode -eq 'uninstall'){$InstallButton.Content='Désinstaller EXDEV RGB';$PathBox.IsReadOnly=$true;$BrowseButton.IsEnabled=$false}
          if($AutoStart -and $Mode -in @('install','update') -and $InstallButton.IsEnabled) {
            $InfoText.Text='Mise à jour automatique EXDEV RGB : préparation de l installation...'
            $script:AutoStartTimer=New-Object System.Windows.Threading.DispatcherTimer
            $script:AutoStartTimer.Interval=[TimeSpan]::FromMilliseconds(650)
            $script:AutoStartTimer.Add_Tick({
              $script:AutoStartTimer.Stop()
              if(-not $script:Busy -and $InstallButton.IsEnabled) {
                $args=New-Object System.Windows.RoutedEventArgs([System.Windows.Controls.Button]::ClickEvent)
                $InstallButton.RaiseEvent($args)
              }
            })
            $script:AutoStartTimer.Start()
          }
        }
      }
    } catch {
      $script:ScanTimer.Stop()
      Log ('SCAN ERROR '+$_.Exception.ToString())
      Apply-Detected @()
      $DetectDetail.Text='Recherche rapide terminée avec une erreur non bloquante. Vous pouvez choisir le dossier manuellement.'
    }
  })
  $script:ScanTimer.Start()
})

[void]$window.ShowDialog()
