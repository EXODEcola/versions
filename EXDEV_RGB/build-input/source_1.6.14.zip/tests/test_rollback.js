'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');const os=require('node:os');const path=require('node:path');const crypto=require('node:crypto');const vm=require('node:vm');
const source=process.argv[2]||path.join(__dirname,'base','EXDEV RGB','Lib','Source');
const main=fs.readFileSync(path.join(source,'main.js'),'utf8');
const bootstrap=fs.readFileSync(path.join(source,'..','..','..','build','EXDEV_RGB_1611_BOOTSTRAP.go'),'utf8');
const script=fs.readFileSync(path.join(source,'..','Installer','installer-ui.ps1'),'utf8');
const restore=fs.readFileSync(path.join(source,'..','Installer','rollback.ps1'),'utf8');
assert(bootstrap.includes('case "/rollback":kind="rollback"'));assert(bootstrap.includes('args[0]=="/rollback"'));
assert(script.includes('Save-VerifiedRollback $script:OldRoot $target'));assert(restore.includes('Get-FileHash -LiteralPath $source -Algorithm SHA256'));
assert(restore.includes('HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\EXDEV RGB'));
assert(!restore.includes('Remove-Item -LiteralPath $root -Recurse'));
const code=main.slice(main.indexOf('function rollbackSnapshotInfo(){'),main.indexOf('async function requestPreviousVersionRestore()'));
assert(code.includes('snapshot.json'));
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'exdev-rollback-fixture-'));
const base=path.join(temp,'Lib','Rollback','previous');
const paths={rootExe:'EXDEV RGB.exe',appRuntime:'Lib/AppRuntime/EXDEV RGB.exe',nativeBridge:'Lib/Native/EXDEV_RGB_BRIDGE.exe',installer:'EXDEV_RGB_INSTALLER.exe',versionMarker:'Lib/version.txt',sourcePackage:'Lib/Source/package.json',sourceMain:'Lib/Source/main.js',sourceRenderer:'Lib/Source/renderer/app.js',sourcePreload:'Lib/Source/preload.js',installerUi:'Lib/Installer/installer-ui.ps1',prepareRuntime:'Lib/Installer/prepare-runtime.ps1',hardwarePrep:'Lib/Installer/ensure-hardware.ps1'};
try{
  const hashes={};
  for(const [key,rel] of Object.entries(paths)){
    const file=path.join(base,rel);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,'EXDEV:'+key+':1.6.13');
    hashes[key]=crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex').toUpperCase();
  }
  fs.writeFileSync(path.join(base,'snapshot.json'),JSON.stringify({schema:1,version:'1.6.13',settingsSchema:1,createdUtc:'2026-10-28T12:00:00Z',files:hashes}));
  const context=vm.createContext({fs,path,crypto,app:{getVersion:()=> '1.6.14'},distributionRoot:()=>temp,
    semverParts:v=>v.split('.').map(Number), semverCompare:(a,b)=>{const aa=a.split('.').map(Number),bb=b.split('.').map(Number);for(let i=0;i<3;i++)if(aa[i]!==bb[i])return aa[i]>bb[i]?1:-1;return 0;}});
  vm.runInContext(code,context);
  let result=vm.runInContext('rollbackSnapshotInfo()',context);
  assert.equal(result.available,true);assert.equal(result.version,'1.6.13');
  fs.writeFileSync(path.join(base,paths.nativeBridge),'tampered');
  result=vm.runInContext('rollbackSnapshotInfo()',context);assert.equal(result.available,false,'tampered native engine must block restore');
  fs.writeFileSync(path.join(base,paths.nativeBridge),'EXDEV:nativeBridge:1.6.13');
  result=vm.runInContext('rollbackSnapshotInfo()',context);assert.equal(result.available,true);
  fs.writeFileSync(path.join(base,'snapshot.json'),JSON.stringify({schema:1,version:'1.7.1',settingsSchema:1,files:hashes}));
  result=vm.runInContext('rollbackSnapshotInfo()',context);assert.equal(result.available,false,'different version family must block restore');
  fs.writeFileSync(path.join(base,'snapshot.json'),JSON.stringify({schema:1,version:'1.6.14',settingsSchema:1,files:hashes}));
  result=vm.runInContext('rollbackSnapshotInfo()',context);assert.equal(result.available,false,'same version must block restore');
  fs.writeFileSync(path.join(base,'snapshot.json'),JSON.stringify({schema:1,version:'1.6.13',settingsSchema:2,files:hashes}));
  result=vm.runInContext('rollbackSnapshotInfo()',context);assert.equal(result.available,false,'settings schema mismatch must block restore');
  console.log('PASS: rollback gate accepts a valid 1.6.13 snapshot, rejects tampered binaries, incompatible versions and settings schemas.');
} finally {fs.rmSync(temp,{recursive:true,force:true});}
