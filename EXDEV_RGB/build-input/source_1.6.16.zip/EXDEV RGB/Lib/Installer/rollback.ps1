#requires -Version 5.1
# Launched ONLY by the embedded EXDEV RGB installer via /rollback, after UAC elevation.
# No externally supplied install path / commands / device controls are accepted.
param()
Add-Type -AssemblyName System.Windows.Forms
$ErrorActionPreference='Stop'
$reg='Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB'
$install=[string](Get-ItemProperty -LiteralPath $reg -ErrorAction Stop).InstallLocation
if(-not $install){throw 'Installation registered in Windows not found.'}
$root=[IO.Path]::GetFullPath($install).TrimEnd('\')
$allowed=@([Environment]::GetFolderPath('ProgramFiles'),[Environment]::GetFolderPath('ProgramFilesX86')) | Where-Object {$_}
if(-not (@($allowed | Where-Object {$root.StartsWith(([IO.Path]::GetFullPath($_).TrimEnd('\')+'\'),[StringComparison]::OrdinalIgnoreCase)}).Count -gt 0)){
  throw 'For security, only protected Program Files installations can be restored.'
}
$rollback=Join-Path $root 'Lib\Rollback\previous'
$recordPath=Join-Path $rollback 'snapshot.json'
if(-not (Test-Path -LiteralPath $recordPath -PathType Leaf)){throw 'No validated rollback snapshot is available.'}
$record=Get-Content -LiteralPath $recordPath -Raw -Encoding UTF8|ConvertFrom-Json
if($record.schema -ne 1 -or [string]$record.version -notmatch '^\d+\.\d+\.\d+$' -or $record.settingsSchema -ne 1){throw 'Unsupported snapshot schema/version.'}
$paths=@{rootExe='EXDEV RGB.exe';appRuntime='Lib\AppRuntime\EXDEV RGB.exe';nativeBridge='Lib\Native\EXDEV_RGB_BRIDGE.exe';installer='EXDEV_RGB_INSTALLER.exe';versionMarker='Lib\version.txt';sourcePackage='Lib\Source\package.json';sourceMain='Lib\Source\main.js';sourceRenderer='Lib\Source\renderer\app.js';sourcePreload='Lib\Source\preload.js';installerUi='Lib\Installer\installer-ui.ps1';prepareRuntime='Lib\Installer\prepare-runtime.ps1';hardwarePrep='Lib\Installer\ensure-hardware.ps1'}
foreach($key in $paths.Keys){
  $source=Join-Path $rollback $paths[$key]
  $expected=[string]$record.files.$key
  if(-not ($expected -match '^[A-Fa-f0-9]{64}$') -or -not (Test-Path -LiteralPath $source -PathType Leaf)){throw "Missing snapshot component $key"}
  if((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ine $expected){throw "Rollback checksum mismatch: $key"}
}
$oldPE=[string](Get-Item -LiteralPath (Join-Path $rollback $paths.rootExe)).VersionInfo.ProductVersion
if($oldPE -notmatch '^\d+\.\d+\.\d+' -or $Matches[0] -ne [string]$record.version){throw 'Snapshot executable version does not match.'}
$currentPE=[string](Get-Item -LiteralPath (Join-Path $root $paths.rootExe)).VersionInfo.ProductVersion
if($currentPE -notmatch '^\d+\.\d+\.\d+'){throw 'Current EXDEV executable version is unknown.'}
$currentVersion=$Matches[0]
$vOld=[version]$record.version
$vCurrent=[version]$currentVersion
if($vOld -ge $vCurrent -or $vOld.Major -ne $vCurrent.Major -or $vOld.Minor -ne $vCurrent.Minor){throw 'Rollback must be to an older compatible version only.'}
$answer=[System.Windows.Forms.MessageBox]::Show("Restaurer EXDEV RGB $($record.version) depuis $currentVersion ?`n`nLes profils RGB seront conserves. Windows peut demander une elevation.", 'EXDEV RGB - Retour arriere',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Warning)
if($answer -ne [System.Windows.Forms.DialogResult]::Yes){exit 2}
# Prepare a complete forward copy BEFORE touching installed files.
$guard=Join-Path $root 'Lib\Rollback\forward-guard'
if(Test-Path -LiteralPath $guard){Remove-Item -LiteralPath $guard -Recurse -Force -ErrorAction Stop}
New-Item -ItemType Directory -Path $guard -Force | Out-Null
foreach($key in $paths.Keys){
  $src=Join-Path $root $paths[$key]
  $dst=Join-Path $guard $paths[$key]
  if(-not (Test-Path -LiteralPath $src -PathType Leaf)){throw "Installed component missing: $key"}
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst)|Out-Null
  Copy-Item -LiteralPath $src -Destination $dst -Force -ErrorAction Stop
  if((Get-FileHash $src -Algorithm SHA256).Hash -ne (Get-FileHash $dst -Algorithm SHA256).Hash){throw "Forward backup invalid: $key"}
}
try{
  Get-Process -Name 'EXDEV RGB' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
  Get-Process -Name 'EXDEV_RGB_BRIDGE' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
  Start-Sleep -Milliseconds 700
  foreach($key in $paths.Keys){
    $src=Join-Path $rollback $paths[$key]
    $dst=Join-Path $root $paths[$key]
    Copy-Item -LiteralPath $src -Destination $dst -Force -ErrorAction Stop
    if((Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash -ine [string]$record.files.$key){throw "Restore failed checksum: $key"}
  }
  [IO.File]::WriteAllText((Join-Path $root 'Lib\AppRuntime\version.txt'),([string]$record.version+"`r`n"),[Text.UTF8Encoding]::new($false))
  [IO.File]::WriteAllText((Join-Path $root 'Lib\installed-version.txt'),([string]$record.version+"`r`n"),[Text.UTF8Encoding]::new($false))
  $uninstall='HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB'
  Set-ItemProperty -Path $uninstall -Name DisplayVersion -Value ([string]$record.version) -ErrorAction Stop
  Set-ItemProperty -Path 'HKLM:\Software\EXDEV\EXDEV RGB' -Name Version -Value ([string]$record.version) -ErrorAction Stop
  try { schtasks.exe /Run /TN 'EXDEV RGB Native Engine' | Out-Null } catch {}
  [System.Windows.Forms.MessageBox]::Show("EXDEV RGB $($record.version) est restaure. Les profils ont ete preserves. Redemarrez EXDEV RGB normalement depuis votre raccourci.",'EXDEV RGB')|Out-Null
} catch {
  # Recover the exact prior files rather than leaving mixed app/native versions.
  foreach($key in $paths.Keys){
    try{Copy-Item -LiteralPath (Join-Path $guard $paths[$key]) -Destination (Join-Path $root $paths[$key]) -Force -ErrorAction Stop}catch{}
  }
  [IO.File]::WriteAllText((Join-Path $root 'Lib\AppRuntime\version.txt'),($currentVersion+"`r`n"),[Text.UTF8Encoding]::new($false))
  [IO.File]::WriteAllText((Join-Path $root 'Lib\installed-version.txt'),($currentVersion+"`r`n"),[Text.UTF8Encoding]::new($false))
  try { Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB' -Name DisplayVersion -Value $currentVersion -ErrorAction Stop } catch {}
  try { Set-ItemProperty -Path 'HKLM:\Software\EXDEV\EXDEV RGB' -Name Version -Value $currentVersion -ErrorAction Stop } catch {}
  try { schtasks.exe /Run /TN 'EXDEV RGB Native Engine' | Out-Null } catch {}
  throw "Rollback aborted; previous version reinstated: $($_.Exception.Message)"
}
