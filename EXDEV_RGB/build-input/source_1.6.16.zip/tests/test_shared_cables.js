'use strict';
const assert=require('node:assert/strict'),fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.join(__dirname,'..','EXDEV RGB','Lib','Source');
const main=fs.readFileSync(path.join(root,'main.js'),'utf8');
const ui=fs.readFileSync(path.join(root,'renderer','app.js'),'utf8');
const a=main.indexOf('function cleanCableLayouts(value) {');
const b=main.indexOf('function sanitizeStatePatch(',a);
assert(a>0&&b>a,'Cannot isolate RGB cable routines');
const source=main.slice(a,b);
const ctx=vm.createContext({HEX_COLOR:/^#[0-9A-F]{6}$/i,cleanText:(s,n)=>String(s??'').slice(0,n)});
vm.runInContext(source+`function hexToRgbLocal(h){const n=parseInt(h.slice(1),16);return[(n>>16)&255,(n>>8)&255,n&255]}`,ctx);
const run=src=>vm.runInContext(src,ctx);
const dev='argb:gigabyte:B650:D_LED2';
const colors=['#0000FF','#FFFFFF','#FF0000'];
const c={mode:'triple',colors,ledCount:60,enabled:true,shared:{enabled:true,primaryCount:7,secondaryCount:3}};
const cfg=run(`cleanCableLayouts(${JSON.stringify({[dev]:c})})`);
assert.equal(cfg[dev].shared.enabled,true);
assert.equal(cfg[dev].ledCount,7);
assert.equal(cfg[dev].shared.primaryCount,7);
assert.equal(cfg[dev].shared.secondaryCount,3);
const shared=run(`sharedCablePixels(${JSON.stringify(cfg[dev])})`);
assert.deepEqual([...shared],['#0000FF','#FFFFFF','#FF0000','#0000FF','#FFFFFF','#FF0000','#0000FF']);
assert.deepEqual([...shared.slice(0,3)],colors,'3-zone CPU must show all three colors with common signal');
// Normal D_LED2 layout still uses legacy 60-zone distribution when shared mode off.
const plain=run(`cleanCableLayouts(${JSON.stringify({[dev]:{...c,shared:{...c.shared,enabled:false}}})})`)[dev];
assert.equal(plain.ledCount,60);
assert.equal(run(`rgbLedColors(${JSON.stringify(plain)},60)`).length,60);
// Shared option must not be enableable on another physical header.
const dev1='argb:gigabyte:B650:D_LED1';
const other=run(`cleanCableLayouts(${JSON.stringify({[dev1]:c})})`)[dev1];
assert.equal(other.shared.enabled,false);
// Clamp physical frame to a valid safe count for Go native driver (> 5).
let invalid={...c,shared:{enabled:true,primaryCount:1,secondaryCount:3}};
const sanitized=run(`cleanCableLayouts(${JSON.stringify({[dev]:invalid})})`)[dev];
assert.equal(sanitized.shared.primaryCount,6);
assert.equal(sanitized.shared.secondaryCount,3);
assert.equal(run(`sharedCablePixels(${JSON.stringify(sanitized)})`).length,6);
const long=run(`cleanCableLayouts(${JSON.stringify({[dev]:{...c,shared:{enabled:true,primaryCount:999,secondaryCount:999}}})})`)[dev];
assert.equal(long.shared.primaryCount,120);
assert.equal(long.shared.secondaryCount,120);
for (const mode of ['uniform','triple','gradient']){
 const pixels=run(`sharedCablePixels(${JSON.stringify({...cfg[dev],mode})})`);
 assert.equal(pixels.length,7);assert.ok(pixels.every(x=>/^#[0-9A-F]{6}$/.test(x)));
}
assert(ui.includes('Deux câbles sur D_LED2'));
assert(ui.includes('Un signal ARGB commun'));
assert(ui.includes('pixels.slice(0,x.shared.secondaryCount)'));
assert(ui.includes('commande envoyée (rendu physique à vérifier)'));
console.log('PASS: D_LED2 7+3 virtual cables share 7-pixel B/W/R/B/W/R/B frame, CPU receives B/W/R, no false independent control, legacy respected.');
