//go:build windows

package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

var (
	user32      = syscall.NewLazyDLL("user32.dll")
	messageBoxW = user32.NewProc("MessageBoxW")
)

const (
	MB_OK              = 0
	MB_YESNO           = 4
	MB_ICONINFORMATION = 0x40
	MB_ICONQUESTION    = 0x20
	MB_ICONERROR       = 0x10
	MB_ICONWARNING     = 0x30
	IDYES              = 6
	version            = "1.6.17"
)

type hardwareStatus struct {
	DriverInstalled     bool   `json:"driverInstalled"`
	ModuleInstalled     bool   `json:"moduleInstalled"`
	EngineTaskInstalled bool   `json:"engineTaskInstalled"`
	EngineReachable     bool   `json:"engineReachable"`
	RebootRequired      bool   `json:"rebootRequired"`
	Ready               bool   `json:"ready"`
	Error               string `json:"error"`
}

func readHardwareStatus(root string) hardwareStatus {
	var hs hardwareStatus
	b, err := os.ReadFile(filepath.Join(root, "Lib", "Native", "hardware-status.json"))
	if err == nil {
		_ = json.Unmarshal(b, &hs)
	}
	return hs
}

func wptr(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func msg(text, title string, flags uintptr) int {
	r, _, _ := messageBoxW.Call(0, uintptr(unsafe.Pointer(wptr(text))), uintptr(unsafe.Pointer(wptr(title))), flags)
	return int(r)
}
func quotePS(s string) string { return strings.ReplaceAll(s, "'", "''") }
func runHidden(name string, args []string, dir string, log *os.File) error {
	c := exec.Command(name, args...)
	c.Dir = dir
	c.Stdout = log
	c.Stderr = log
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	return c.Run()
}
func copyFile(src, dst string) error {
	in, e := os.Open(src)
	if e != nil {
		return e
	}
	defer in.Close()
	if e = os.MkdirAll(filepath.Dir(dst), 0755); e != nil {
		return e
	}
	out, e := os.Create(dst)
	if e != nil {
		return e
	}
	defer out.Close()
	_, e = io.Copy(out, bufio.NewReader(in))
	if e != nil {
		return e
	}
	return out.Sync()
}
func copyTree(src, dst string, skip map[string]bool) error {
	return filepath.Walk(src, func(p string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		rel, e := filepath.Rel(src, p)
		if e != nil {
			return e
		}
		if rel == "." {
			return os.MkdirAll(dst, 0755)
		}
		top := strings.Split(rel, string(os.PathSeparator))[0]
		if skip[top] {
			if info.IsDir() {
				return filepath.SkipDir
			}
			return nil
		}
		target := filepath.Join(dst, rel)
		if info.IsDir() {
			return os.MkdirAll(target, 0755)
		}
		return copyFile(p, target)
	})
}
func regAdd(args ...string) {
	c := exec.Command("reg.exe", args...)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	_ = c.Run()
}
func regRead(name string) string {
	c := exec.Command("reg.exe", "query", `HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB`, "/v", name)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	b, e := c.Output()
	if e != nil {
		return ""
	}
	for _, line := range strings.Split(string(b), "\n") {
		if strings.Contains(line, name) && strings.Contains(line, "REG_SZ") {
			parts := strings.SplitN(line, "REG_SZ", 2)
			if len(parts) == 2 {
				return strings.TrimSpace(parts[1])
			}
		}
	}
	return ""
}
func parseVersion(s string) [3]int {
	var v [3]int
	parts := strings.Split(strings.TrimSpace(s), ".")
	for i := 0; i < 3 && i < len(parts); i++ {
		n, _ := strconv.Atoi(strings.TrimLeftFunc(parts[i], func(r rune) bool { return r < '0' || r > '9' }))
		v[i] = n
	}
	return v
}
func compareVersion(a, b string) int {
	aa, bb := parseVersion(a), parseVersion(b)
	for i := 0; i < 3; i++ {
		if aa[i] < bb[i] {
			return -1
		}
		if aa[i] > bb[i] {
			return 1
		}
	}
	return 0
}
func readTrim(path string) string {
	b, e := os.ReadFile(path)
	if e != nil {
		return ""
	}
	return strings.TrimSpace(string(b))
}
func removeStaleLock(lockPath string) {
	if st, e := os.Stat(lockPath); e == nil && time.Since(st.ModTime()) > 20*time.Minute {
		_ = os.Remove(lockPath)
	}
}
func acquireLock(lockPath string) (*os.File, error) {
	removeStaleLock(lockPath)
	return os.OpenFile(lockPath, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
}

func createShortcuts(root string, log *os.File) {
	app := filepath.Join(root, "EXDEV RGB.exe")
	icon := filepath.Join(root, "Lib", "Assets", "EXDEV_RGB.ico")
	if _, e := os.Stat(icon); e != nil {
		icon = app
	}
	ps := fmt.Sprintf(`$ws=New-Object -ComObject WScript.Shell;$d=[Environment]::GetFolderPath('Desktop');$lnk=(Join-Path $d 'EXDEV RGB.lnk');Remove-Item -LiteralPath $lnk -Force -ErrorAction SilentlyContinue;$s=$ws.CreateShortcut($lnk);$s.TargetPath='%s';$s.WorkingDirectory='%s';$s.IconLocation='%s,0';$s.Description='EXDEV RGB - Native Lighting Engine';$s.Save();$sm=[Environment]::GetFolderPath('Programs');$dir=Join-Path $sm 'EXDEV RGB';New-Item -ItemType Directory -Force -Path $dir|Out-Null;$sml=(Join-Path $dir 'EXDEV RGB.lnk');Remove-Item -LiteralPath $sml -Force -ErrorAction SilentlyContinue;$s2=$ws.CreateShortcut($sml);$s2.TargetPath='%s';$s2.WorkingDirectory='%s';$s2.IconLocation='%s,0';$s2.Description='EXDEV RGB - Native Lighting Engine';$s2.Save();Start-Process ie4uinit.exe -ArgumentList '-show' -WindowStyle Hidden -ErrorAction SilentlyContinue`, quotePS(app), quotePS(root), quotePS(icon), quotePS(app), quotePS(root), quotePS(icon))
	_ = runHidden("powershell.exe", []string{"-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps}, root, log)
}

func uninstall(root string) {
	if msg("Désinstaller EXDEV RGB ?\n\nLes paramètres utilisateur seront conservés. Le dossier Lib et l’installateur resteront disponibles pour une réinstallation.", "EXDEV RGB", MB_YESNO|MB_ICONQUESTION) != IDYES {
		return
	}
	_ = exec.Command("taskkill.exe", "/IM", "EXDEV RGB.exe", "/F").Run()
	_ = exec.Command("taskkill.exe", "/IM", "EXDEV_RGB_BRIDGE.exe", "/F").Run()
	_ = exec.Command("schtasks.exe", "/Delete", "/TN", "EXDEV RGB Native Engine", "/F").Run()
	time.Sleep(350 * time.Millisecond)
	ps := `$d=[Environment]::GetFolderPath('Desktop');Remove-Item -LiteralPath (Join-Path $d 'EXDEV RGB.lnk') -Force -ErrorAction SilentlyContinue;$sm=[Environment]::GetFolderPath('Programs');Remove-Item -LiteralPath (Join-Path $sm 'EXDEV RGB') -Recurse -Force -ErrorAction SilentlyContinue`
	_ = runHidden("powershell.exe", []string{"-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps}, root, nil)
	regAdd("delete", `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`, "/v", "EXDEV RGB", "/f")
	regAdd("delete", `HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB`, "/f")
	_ = os.Remove(filepath.Join(root, "EXDEV RGB.exe"))
	msg("EXDEV RGB a été désinstallé.\n\nLib et l’installateur sont conservés.", "EXDEV RGB", MB_OK|MB_ICONINFORMATION)
}

func runtimeCurrent(root string) bool {
	runtime := filepath.Join(root, "Lib", "AppRuntime", "EXDEV RGB.exe")
	marker := filepath.Join(root, "Lib", "AppRuntime", "version.txt")
	if _, e := os.Stat(runtime); e != nil {
		return false
	}
	return readTrim(marker) == version
}
func prepare(root string, skipRuntime bool, log *os.File) error {
	logs := filepath.Join(root, "Lib", "Logs")
	source := filepath.Join(root, "Lib", "Source")
	script := filepath.Join(root, "Lib", "Installer", "prepare-runtime.ps1")
	if _, e := os.Stat(script); e != nil {
		return fmt.Errorf("module de préparation absent")
	}
	_ = os.MkdirAll(logs, 0755)
	args := []string{"-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-STA", "-File", script, "-RootDir", root, "-SourceDir", source, "-LogFile", filepath.Join(logs, "installer.log")}
	if skipRuntime {
		args = append(args, "-SkipRuntime")
	}
	if log != nil {
		fmt.Fprintln(log, "[EXDEV] Preparation", time.Now(), "skipRuntime=", skipRuntime)
	}
	return runHidden("powershell.exe", args, root, log)
}
func finalizeRuntime(root string) error {
	built := filepath.Join(root, "Lib", "Source", "dist", "EXDEV RGB.exe")
	if _, e := os.Stat(built); e != nil {
		return fmt.Errorf("EXDEV RGB.exe compilé introuvable")
	}
	runtime := filepath.Join(root, "Lib", "AppRuntime", "EXDEV RGB.exe")
	if e := copyFile(built, runtime); e != nil {
		return e
	}
	return os.WriteFile(filepath.Join(root, "Lib", "AppRuntime", "version.txt"), []byte(version+"\r\n"), 0644)
}

func migrateIfNeeded(currentRoot, self string, forceRepair bool) (string, string, error) {
	installedRoot := strings.TrimSpace(regRead("InstallLocation"))
	installedVersion := strings.TrimSpace(regRead("DisplayVersion"))
	// Compatibility with early portable EXDEV builds that did not register cleanly.
	if installedRoot == "" {
		localVersion := readTrim(filepath.Join(currentRoot, "Lib", "installed-version.txt"))
		if localVersion != "" {
			if _, err := os.Stat(filepath.Join(currentRoot, "EXDEV RGB.exe")); err == nil {
				installedRoot = currentRoot
				installedVersion = localVersion
			}
		}
	}
	if installedRoot == "" {
		return currentRoot, "", nil
	}
	if _, e := os.Stat(installedRoot); e != nil {
		return currentRoot, "", nil
	}
	cmp := compareVersion(installedVersion, version)
	action := "mise à jour"
	if cmp == 0 {
		action = "réparation"
	}
	if cmp > 0 {
		action = "rétrogradation"
	}
	if !forceRepair {
		question := fmt.Sprintf("EXDEV RGB %s est déjà détecté dans :\n%s\n\nL’installateur %s va effectuer une %s vers la version %s en conservant tes paramètres.\n\nContinuer ?", installedVersion, installedRoot, version, action, version)
		if msg(question, "EXDEV RGB - Mise à jour", MB_YESNO|MB_ICONQUESTION) != IDYES {
			return "", "", fmt.Errorf("annulé")
		}
	}
	if filepath.Clean(installedRoot) != filepath.Clean(currentRoot) {
		_ = exec.Command("taskkill.exe", "/IM", "EXDEV RGB.exe", "/F").Run()
		time.Sleep(300 * time.Millisecond)
		if e := copyTree(filepath.Join(currentRoot, "Lib"), filepath.Join(installedRoot, "Lib"), map[string]bool{"Logs": true, "AppRuntime": true, "Rollback": true}); e != nil {
			return "", "", e
		}
		targetInstaller := filepath.Join(installedRoot, "EXDEV_RGB_INSTALLER.exe")
		_ = copyFile(self, targetInstaller)
	}
	return installedRoot, installedVersion, nil
}

func main() {
	self, e := os.Executable()
	if e != nil {
		return
	}
	currentRoot := filepath.Dir(self)
	forceRepair := false
	for _, a := range os.Args[1:] {
		if strings.EqualFold(a, "/uninstall") {
			root := regRead("InstallLocation")
			if root == "" {
				root = currentRoot
			}
			uninstall(root)
			return
		}
		if strings.EqualFold(a, "/repair") || strings.EqualFold(a, "/update") {
			forceRepair = true
		}
	}
	root, oldVersion, e := migrateIfNeeded(currentRoot, self, forceRepair)
	if e != nil || root == "" {
		return
	}
	logs := filepath.Join(root, "Lib", "Logs")
	_ = os.MkdirAll(logs, 0755)
	lockPath := filepath.Join(logs, "install.lock")
	lock, e := acquireLock(lockPath)
	if e != nil {
		msg("Une installation ou mise à jour EXDEV RGB est déjà en cours.\n\nAttends la fin de la fenêtre de progression.", "EXDEV RGB", MB_OK|MB_ICONWARNING)
		return
	}
	lock.Close()
	defer os.Remove(lockPath)
	log, _ := os.OpenFile(filepath.Join(logs, "installer.log"), os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if log != nil {
		defer log.Close()
		fmt.Fprintln(log, "\n[EXDEV] Installer", version, time.Now(), "old=", oldVersion, "root=", root)
	}
	needRuntime := !runtimeCurrent(root)
	// Backup the last working root executable before an update.
	rootApp := filepath.Join(root, "EXDEV RGB.exe")
	if _, e := os.Stat(rootApp); e == nil {
		rb := filepath.Join(root, "Lib", "Rollback")
		_ = os.MkdirAll(rb, 0755)
		_ = copyFile(rootApp, filepath.Join(rb, "EXDEV RGB.exe"))
		_ = os.WriteFile(filepath.Join(rb, "version.txt"), []byte(oldVersion+"\r\n"), 0644)
	}
	if e := prepare(root, !needRuntime, log); e != nil {
		msg("La préparation de EXDEV RGB a échoué.\n\nConsulte Lib\\Logs\\installer.log.", "EXDEV RGB - Erreur", MB_OK|MB_ICONERROR)
		return
	}
	if needRuntime {
		if e := finalizeRuntime(root); e != nil {
			msg("Le moteur Windows n’a pas pu être finalisé.\n\n"+e.Error(), "EXDEV RGB - Erreur", MB_OK|MB_ICONERROR)
			return
		}
	}
	runtime := filepath.Join(root, "Lib", "AppRuntime", "EXDEV RGB.exe")
	if _, e := os.Stat(runtime); e != nil {
		msg("Le moteur EXDEV RGB est introuvable après préparation.", "EXDEV RGB - Erreur", MB_OK|MB_ICONERROR)
		return
	}
	_ = exec.Command("taskkill.exe", "/IM", "EXDEV RGB.exe", "/F").Run()
	time.Sleep(350 * time.Millisecond)
	if e := copyFile(runtime, rootApp); e != nil {
		msg("Impossible de créer EXDEV RGB.exe à la racine du dossier.", "EXDEV RGB - Erreur", MB_OK|MB_ICONERROR)
		return
	}
	targetInstaller := filepath.Join(root, "EXDEV_RGB_INSTALLER.exe")
	if filepath.Clean(self) != filepath.Clean(targetInstaller) {
		_ = copyFile(self, targetInstaller)
	}
	createShortcuts(root, log)
	icon := filepath.Join(root, "Lib", "Assets", "EXDEV_RGB.ico")
	if _, e := os.Stat(icon); e != nil {
		icon = rootApp
	}
	key := `HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\EXDEV RGB`
	regAdd("add", key, "/v", "DisplayName", "/t", "REG_SZ", "/d", "EXDEV RGB", "/f")
	regAdd("add", key, "/v", "DisplayVersion", "/t", "REG_SZ", "/d", version, "/f")
	regAdd("add", key, "/v", "Publisher", "/t", "REG_SZ", "/d", "EXDEV", "/f")
	regAdd("add", key, "/v", "InstallLocation", "/t", "REG_SZ", "/d", root, "/f")
	regAdd("add", key, "/v", "DisplayIcon", "/t", "REG_SZ", "/d", icon, "/f")
	regAdd("add", key, "/v", "UninstallString", "/t", "REG_SZ", "/d", fmt.Sprintf(`"%s" /uninstall`, targetInstaller), "/f")
	_ = os.WriteFile(filepath.Join(root, "Lib", "installed-version.txt"), []byte(version+"\r\n"), 0644)
	c := exec.Command(rootApp)
	c.Dir = root
	c.Env = append(os.Environ(), "PORTABLE_EXECUTABLE_DIR="+root, "EXDEV_RGB_ROOT="+root)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: false}
	_ = c.Start()
	hs := readHardwareStatus(root)
	text := "EXDEV RGB " + version + " Stable est installé."
	if oldVersion != "" && oldVersion != version {
		text = "EXDEV RGB a été mis à jour de " + oldVersion + " vers " + version + " Stable.\n\nLes paramètres ont été conservés."
	} else if oldVersion == version {
		text = "EXDEV RGB " + version + " Stable a été réparé et vérifié."
	}
	if hs.Ready {
		text += "\n\nPilote SMBus : PRÊT\nNative Bridge : PRÊT\nMoteur élevé au démarrage : PRÊT"
	} else if hs.RebootRequired {
		text += "\n\nLe pilote SMBus a été installé. Un redémarrage Windows est requis avant de contrôler la RAM."
	} else if hs.Error != "" {
		text += "\n\nL'application est installée, mais le pilote SMBus n'est pas encore prêt. Tu peux relancer Réparer depuis les Réglages.\n\nDétail : " + hs.Error
	}
	msg(text, "EXDEV RGB", MB_OK|MB_ICONINFORMATION)
}
