# EXDEV RGB Studio — refonte visuelle 1.6.17 (Bêta)

Cette version adapte une direction UI/UX de console de monitoring (captures SignalRGB fournies par le propriétaire), tout en conservant le **branding EXDEV** et la palette violet / bleu nuit / cyan.

## Changements

- Navigation plus précise, regroupée par fonctions, header de contexte et statut RGB ; dock inférieur du profil actif donnant accès à Profils, Studio d'éclairage et Surveillance.
- Tableau de bord dans une hiérarchie de cartes, luminosité, périphériques et sécurité avec palette revue.
- Nouvel écran **Surveillance** : trois jauges (charge CPU, mémoire RAM, appareils RGB prêts), deux graphiques réels (CPU/RAM et mémoire du processus EXDEV) avec historique max 60 points à cadence 2 secondes, état du matériel et statut FAN LOCK.
- Bouton **Personnaliser les widgets** pour afficher/masquer les graphiques et la santé système. Choix persistés dans `settings.json`, normalisés en booléens et limités aux clés `usage`, `process`, `health`.
- Studio d'éclairage en deux colonnes adaptées aux fenêtres 1080–1560px ; cartes RAM et Asiahorse plus larges ; correction des textes coupés dans la barre de synchronisation globale.
- Les changements de page remettent le défilement en haut.

## Sources de données et limites

- CPU %, RAM %, Go utilisés et mémoire du processus viennent exclusivement de `systemTelemetry()` (IPC `system:telemetry`) ; les couleurs et graphiques reflètent les mesures réellement reçues.
- GPU RGB est un indicateur de disponibilité de pilote/cible, **pas** une mesure de tension ou de température GPU.
- Pas de capteurs de température CPU/GPU, RPM, fréquence GPU ou courbes de ventilateur fictifs.
- FAN LOCK demeure impératif : aucune commande PWM, pompe, fréquence GPU, refroidissement ou tension ajoutée.
- Les contrôles Corsair RAM, AORUS GPU RGB, Gigabyte D_LED1/D_LED2, deux câbles 7+3 et la mise à jour Stable/Bêta sont conservés sans modifier leur protocole.

## Validation

- `node --check` des scripts Electron et du renderer.
- `node tests/updater.test.js` ; `node tests/test_shared_cables.js` ; `node tests/test_rollback.js <source>` ; `node tests/test_studio_ui.js`.
- Test visuel avec navigateur Chromium et API de prévisualisation embarquée (aucune écriture matérielle).
- Build Windows Electron + Native Bridge à réaliser via GitHub Actions avant publication.
- Version Bêta non signée ; ne pas modifier le canal Stable sans essais sur vrai matériel.
